# Real-task manager temperature matrix — redacted visible projection

Execution `43b43157718eeb5172888af75963d8ba0dd3e631`; prompt baseline `e3e6cb42cdcfd010c4b5285108c045359adb6209`; dataset `2fd12b88aafdd04a52c298e3940bcb189f9766d6`; Harbor `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`.

Sixteen independent completed Task runs, with native evaluation and owned-resource cleanup checked after each. Five original slots completed; the original sixth slot was interrupted by loss of its host runner and has no native evaluation. It remains a separate unscored diagnostic record. A newly prepared sixth run with a new run ID completed, followed by the ten previously unstarted slots. No prior partial memory was reused.

Each run's manager HTTP audit retains the final outbound model, temperature, thinking/output configuration, tool names/choice, attempts and status, without request bodies. Full visible Task and manager request/response structures are projected separately. The presence of an outbound temperature and HTTP 200 does not verify server-side sampling.

This ZIP is a redacted visible projection, not raw HTTP bytes or a restorable private runtime. Originals remain local. Excluded: credentials, private endpoints/profile bodies, provider-private thinking/signatures, hidden verifier bodies and source/runtime bundles. Some raw text response sections with private provider blocks are replaced; structured visible response records remain. The external index maps each local source hash to its public member hash. Missing usage, costs or provider retry data are not inferred.
