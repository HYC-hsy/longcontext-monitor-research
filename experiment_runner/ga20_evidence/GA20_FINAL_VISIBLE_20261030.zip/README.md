# GA20 final visible trajectories

Twenty selected GA-only real episodes in the frozen task order. All reached native evaluation; reward 0 is a valid result. The selected episodes span multiple fixed production commits and separate recovery batches, so this is not one same-code, same-time run. Agent time and task turns were uncapped; the verifier retained official limits.

Each numbered directory has events.jsonl, task_turns.jsonl, evaluation.jsonl, and INDEX.json. These are redacted, re-encoded visible-content projections, not original HTTP bytes. The per-run INDEX maps public rows to private original line and file hashes. Provider retry attempts remain in events.jsonl and are linked from task_turns.jsonl. Hidden reasoning, credentials and URLs are excluded. The private originals remain local pending the separately requested cleanup of superseded failed attempts only. No hidden verifier tests or private model profiles are included.
