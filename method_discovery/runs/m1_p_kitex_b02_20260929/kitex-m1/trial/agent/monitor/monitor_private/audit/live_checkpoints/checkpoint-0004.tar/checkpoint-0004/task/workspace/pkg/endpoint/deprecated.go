/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package endpoint

// Deprecated: RecvEndpoint is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamRecvEndpoint
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamRecvEndpoint
//
// The original RecvEndpoint was ambiguous about whether it represents client or server context.
// The new packages (cep for client, sep for server) provide clear separation and better type safety.

// Deprecated: RecvMiddleware is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamRecvMiddleware
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamRecvMiddleware

// Deprecated: RecvMiddlewareBuilder is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamRecvMiddlewareBuilder
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamRecvMiddlewareBuilder

// Deprecated: RecvChain is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamRecvChain
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamRecvChain

// Deprecated: SendEndpoint is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamSendEndpoint
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamSendEndpoint
//
// The original SendEndpoint was ambiguous about whether it represents client or server context.
// The new packages (cep for client, sep for server) provide clear separation and better type safety.

// Deprecated: SendMiddleware is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamSendMiddleware
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamSendMiddleware

// Deprecated: SendMiddlewareBuilder is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamSendMiddlewareBuilder
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamSendMiddlewareBuilder

// Deprecated: SendChain is deprecated.
// For client-side operations, use github.com/cloudwego/kitex/pkg/endpoint/cep.StreamSendChain
// For server-side operations, use github.com/cloudwego/kitex/pkg/endpoint/sep.StreamSendChain
