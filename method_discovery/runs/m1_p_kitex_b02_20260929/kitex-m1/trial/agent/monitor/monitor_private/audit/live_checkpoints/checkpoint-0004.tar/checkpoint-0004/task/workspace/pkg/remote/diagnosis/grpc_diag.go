/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an
...[Truncated]...
Error: %v", err)
	}
	
	return &Report{
		ConnectionState:  connState,
		StreamHealth:     streamHealth,
		ErrorCategories:  errorCat,
		PerformanceStats: perfStats,
		Recommendations:  generateRecommendations(connState, streamHealth, errorCat, perfStats),
	}
}

// generateRecommendations provides actionable recommendations based on diagnostic data
func generateRecommendations(conn *ConnectionState, health *StreamHealth, errors *ErrorCategories, perf *PerformanceStats) []string {
	var recs []string
	
	if conn != nil && !conn.IsHealthy {
		recs = append(recs, "Connection unhealthy - check network connectivity and server availability")
	}
	
	if health != nil && health.ActiveStreams > 100 {
		recs = append(recs, "High number of active streams detected - consider implementing stream pooling or backpressure")
	}
	
	if errors != nil && errors.TransportErrors > 10 {
		recs = append(recs, "High transport error rate - verify network stability and server capacity")
	}
	
	if perf != nil && perf.AvgLatency > 1000*time.Millisecond {
		recs = append(recs, "High average latency detected - check server performance and network conditions")
	}
	
	if len(recs) == 0 {
		recs = append(recs, "All metrics within normal ranges")
	}
	
	return recs
}
