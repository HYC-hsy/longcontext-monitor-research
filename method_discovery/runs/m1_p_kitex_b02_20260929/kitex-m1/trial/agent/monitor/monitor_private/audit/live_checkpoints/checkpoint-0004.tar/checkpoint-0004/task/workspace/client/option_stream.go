/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an
...[Truncated]...
g/kitex/pkg/endpoint/cep"
	"github.com/cloudwego/kitex/pkg/utils"
)

// WithStreamOptions combines multiple StreamOption values into a single StreamOption.
// This is useful for grouping related streaming options together.
func WithStreamOptions(opts ...StreamOption) StreamOption {
	return StreamOption{F: func(o *client.Options, di *utils.Slice) {
		for _, opt := range opts {
			opt.F(o, di)
		}
	}}
}

// WithStreamRecvTimeout sets the maximum time allowed to receive a single message in a streaming call.
// This timeout applies per-message, not for the entire stream duration.
func WithStreamRecvTimeout(timeout time.Duration) StreamOption {
	return StreamOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamRecvTimeout(%s)", timeout))
		o.Configs.Set("stream_recv_timeout", timeout)
	}}
}

// WithStreamMiddleware adds middleware specifically for streaming RPC calls.
// The middleware wraps the StreamEndpoint to intercept and process streaming operations.
func WithStreamMiddleware(mw cep.StreamMiddleware) StreamOption {
	return StreamOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamMiddleware(%+v)", utils.GetFuncName(mw)))
		o.Configs.Set("stream_middlewares", append(
			o.Configs.Get("stream_middlewares", []cep.StreamMiddleware{}).([]cep.StreamMiddleware),
			mw,
		))
	}}
}

// WithStreamMiddlewareBuilder adds a context-dependent middleware builder for streaming calls.
// The builder function receives the context and returns a StreamMiddleware.
func WithStreamMiddlewareBuilder(mwb cep.StreamMiddlewareBuilder) StreamOption {
	return StreamOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamMiddlewareBuilder(%+v)", utils.GetFuncName(mwb)))
		o.Configs.Set("stream_middleware_builders", append(
			o.Configs.Get("stream_middleware_builders", []cep.StreamMiddlewareBuilder{}).([]cep.StreamMiddlewareBuilder),
			mwb,
		))
	}}
}

// WithStreamSendMiddleware adds middleware specifically for the send path of streaming calls.
// This allows separate handling of send operations in bidirectional streams.
func WithStreamSendMiddleware(mw cep.StreamSendMiddleware) StreamOption {
	return StreamOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamSendMiddleware(%+v)", utils.GetFuncName(mw)))
		o.Configs.Set("stream_send_middlewares", append(
			o.Configs.Get("stream_send_middlewares", []cep.StreamSendMiddleware{}).([]cep.StreamSendMiddleware),
			mw,
		))
	}}
}

// WithStreamRecvMiddleware adds middleware specifically for the receive path of streaming calls.
// This allows separate handling of receive operations in bidirectional streams.
func WithStreamRecvMiddleware(mw cep.StreamRecvMiddleware) StreamOption {
	return StreamOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamRecvMiddleware(%+v)", utils.GetFuncName(mw)))
		o.Configs.Set("stream_recv_middlewares", append(
			o.Configs.Get("stream_recv_middlewares", []cep.StreamRecvMiddleware{}).([]cep.StreamRecvMiddleware),
			mw,
		))
	}}
}
