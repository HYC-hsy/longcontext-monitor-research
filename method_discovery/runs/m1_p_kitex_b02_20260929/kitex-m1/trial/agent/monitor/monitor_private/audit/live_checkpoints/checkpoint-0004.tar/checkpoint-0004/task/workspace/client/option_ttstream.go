/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an
...[Truncated]...
opts ...TTHeaderStreamingOption) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{F: func(o *client.Options, di *utils.Slice) {
		for _, opt := range opts {
			opt.F(o, di)
		}
	}}
}

// WithTTHeaderStreamingMetadata adds custom TTHeader metadata for streaming calls.
// This metadata is sent as part of the TTHeader protocol headers.
func WithTTHeaderStreamingMetadata(key, value string) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTHeaderStreamingMetadata(%s=%s)", key, value))
		meta := o.Configs.Get("ttheader_stream_metadata", map[string]string{}).(map[string]string)
		if meta == nil {
			meta = make(map[string]string)
		}
		meta[key] = value
		o.Configs.Set("ttheader_stream_metadata", meta)
	}}
}

// WithTTHeaderStreamingTimeout sets the overall timeout for a TTHeader streaming operation.
// Unlike per-message timeouts, this applies to the entire stream lifecycle.
func WithTTHeaderStreamingTimeout(timeout time.Duration) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTHeaderStreamingTimeout(%s)", timeout))
		o.Configs.Set("ttheader_stream_timeout", timeout)
	}}
}

// WithTTHeaderStreamingProtocolVersion sets the TTHeader protocol version for streaming.
// This allows explicit control over protocol negotiation.
func WithTTHeaderStreamingProtocolVersion(version uint16) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTHeaderStreamingProtocolVersion(%d)", version))
		o.Configs.Set("ttheader_stream_protocol_version", version)
	}}
}
