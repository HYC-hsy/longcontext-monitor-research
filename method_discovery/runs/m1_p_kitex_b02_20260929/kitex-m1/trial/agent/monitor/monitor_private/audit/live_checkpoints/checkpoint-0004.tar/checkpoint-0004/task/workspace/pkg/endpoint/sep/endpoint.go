/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Package sep provides server endpoint types and middleware for streaming RPC
package sep

import (
	"context"

	"github.com/cloudwego/kitex/pkg/streaming"
)

// StreamEndpoint represents a server-side streaming endpoint that handles bidirectional streaming
// It receives a ServerStream from the request and returns a modified ServerStream in the response
type StreamEndpoint func(ctx context.Context, stream streaming.ServerStream) (streaming.ServerStream, error)

// StreamMiddleware wraps a StreamEndpoint to add additional behavior
type StreamMiddleware func(next StreamEndpoint) StreamEndpoint

// StreamMiddlewareBuilder builds a StreamMiddleware with information from a context
type StreamMiddlewareBuilder func(ctx context.Context) StreamMiddleware

// StreamChain connects multiple stream middlewares into one (applied right-to-left)
func StreamChain(mws ...StreamMiddleware) StreamMiddleware {
	return func(next StreamEndpoint) StreamEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// StreamRecvEndpoint represents a server-side endpoint that only receives messages from the client
// Used for server-side unary and client-streaming patterns
type StreamRecvEndpoint func(ctx context.Context, stream streaming.ServerStream) error

// StreamRecvMiddleware wraps a StreamRecvEndpoint
type StreamRecvMiddleware func(next StreamRecvEndpoint) StreamRecvEndpoint

// StreamRecvMiddlewareBuilder builds a StreamRecvMiddleware with information from a context
type StreamRecvMiddlewareBuilder func(ctx context.Context) StreamRecvMiddleware

// StreamRecvChain connects multiple recv middlewares into one (applied right-to-left)
func StreamRecvChain(mws ...StreamRecvMiddleware) StreamRecvMiddleware {
	return func(next StreamRecvEndpoint) StreamRecvEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// StreamSendEndpoint represents a server-side endpoint that only sends messages to the client
// Used for server-streaming pattern
type StreamSendEndpoint func(ctx context.Context, stream streaming.ServerStream) error

// StreamSendMiddleware wraps a StreamSendEndpoint
type StreamSendMiddleware func(next StreamSendEndpoint) StreamSendEndpoint

// StreamSendMiddlewareBuilder builds a StreamSendMiddleware with information from a context
type StreamSendMiddlewareBuilder func(ctx context.Context) StreamSendMiddleware

// StreamSendChain connects multiple send middlewares into one (applied right-to-left)
func StreamSendChain(mws ...StreamSendMiddleware) StreamSendMiddleware {
	return func(next StreamSendEndpoint) StreamSendEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// DummyDummyMiddleware returns the next endpoint unchanged (note the double "Dummy")
func DummyDummyMiddleware(next StreamEndpoint) StreamEndpoint {
	return next
}
