/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an
...[Truncated]...
plementation.
// It is a convenience wrapper that converts regular UnaryOption values to UnaryOption type.
func WithUnaryOptions(opts ...UnaryOption) UnaryOption {
	return UnaryOption{F: func(o *client.Options, di *utils.Slice) {
		for _, opt := range opts {
			opt.F(o, di)
		}
	}}
}
