/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/utils"
)

// StreamOption is a typed option for streaming RPC calls (gRPC, TTHeader streaming)
type StreamOption struct {
	F func(o *client.Options, di *utils.Slice)
}

// Apply applies the option to client options
func (so StreamOption) Apply(o *client.Options, di *utils.Slice) {
	so.F(o, di)
}

// ToOption converts StreamOption to generic Option
func (so StreamOption) ToOption() Option {
	return Option{F: so.F}
}

// FromOptionForStream converts generic Option to StreamOption (unchecked)
func FromOptionForStream(opt Option) StreamOption {
	return StreamOption{F: opt.F}
}
