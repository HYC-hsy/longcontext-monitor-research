/*
 * Copyright 2023 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package endpoint

// Deprecated: Use cep.StreamRecvEndpoint or sep.StreamRecvEndpoint instead.
// RecvEndpoint represents one Recv call using the legacy streaming.Stream interface.
type DeprecatedRecvEndpoint = RecvEndpoint

// Deprecated: Use cep middleware types instead.
// RecvMiddleware deals with input Endpoint and output Endpoint.
type DeprecatedRecvMiddleware = RecvMiddleware

// Deprecated: Use cep middleware builder types instead.
// RecvMiddlewareBuilder builds a middleware with information from a context.
type DeprecatedRecvMiddlewareBuilder = RecvMiddlewareBuilder

// Deprecated: Use cep.RecvChain instead.
// RecvChain connects middlewares into one middleware.
var DeprecatedRecvChain = RecvChain

// Deprecated: Use cep.StreamSendEndpoint or sep.StreamSendEndpoint instead.
// SendEndpoint represents one Send call using the legacy streaming.Stream interface.
type DeprecatedSendEndpoint = SendEndpoint

// Deprecated: Use cep middleware types instead.
// SendMiddleware deals with input Endpoint and output Endpoint.
type DeprecatedSendMiddleware = SendMiddleware

// Deprecated: Use cep middleware builder types instead.
// SendMiddlewareBuilder builds a middleware with information from a context.
type DeprecatedSendMiddlewareBuilder = SendMiddlewareBuilder

// Deprecated: Use cep.SendChain instead.
// SendChain connects middlewares into one middleware.
var DeprecatedSendChain = SendChain
