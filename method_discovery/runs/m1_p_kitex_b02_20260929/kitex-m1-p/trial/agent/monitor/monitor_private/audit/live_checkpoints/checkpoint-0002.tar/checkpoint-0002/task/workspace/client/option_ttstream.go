/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/utils"
)

// TTHeaderStreamingOption is a typed option specifically for TTHeader streaming protocol
type TTHeaderStreamingOption struct {
	F func(o *client.Options, di *utils.Slice)
}

// Apply applies the option to client options
func (tso TTHeaderStreamingOption) Apply(o *client.Options, di *utils.Slice) {
	tso.F(o, di)
}

// ToOption converts TTHeaderStreamingOption to generic Option
func (tso TTHeaderStreamingOption) ToOption() Option {
	return Option{F: tso.F}
}

// ToStreamOption converts TTHeaderStreamingOption to StreamOption
func (tso TTHeaderStreamingOption) ToStreamOption() StreamOption {
	return StreamOption{F: tso.F}
}

// FromOptionForTTHeaderStreaming converts generic Option to TTHeaderStreamingOption (unchecked)
func FromOptionForTTHeaderStreaming(opt Option) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{F: opt.F}
}
