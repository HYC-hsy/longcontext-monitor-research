/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/utils"
)

// UnaryOption is a typed option for unary RPC calls
type UnaryOption struct {
	F func(o *client.Options, di *utils.Slice)
}

// Apply applies the option to client options
func (uo UnaryOption) Apply(o *client.Options, di *utils.Slice) {
	uo.F(o, di)
}

// ToOption converts UnaryOption to generic Option
func (uo UnaryOption) ToOption() Option {
	return Option{F: uo.F}
}

// FromOption converts generic Option to UnaryOption (unchecked)
func FromOption(opt Option) UnaryOption {
	return UnaryOption{F: opt.F}
}

// TailOption is an interface for options that must be applied last
// Examples: timeout settings, deadline configurations
type TailOption interface {
	IsTailOption() bool
}

// tailOptionMarker is a helper to embed in options that should be applied last
type tailOptionMarker struct{}

func (tailOptionMarker) IsTailOption() bool { return true }
