
# Check frame_reader.go for the required readAndCheckFrameHeader method
grep -n "readAndCheckFrameHeader\|readFrameHeader" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go | head -10
