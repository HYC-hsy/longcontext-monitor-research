
# Verify Target 6 requirement 1: connPool.Dump() method
echo "=== Checking for Dump() method in conn_pool.go ==="
grep -n "func.*Dump()" /app/pkg/remote/trans/nphttp2/conn_pool.go

# Verify Target 6 requirement 2: readAndCheckFrameHeader method
echo -e "\n=== Checking for readAndCheckFrameHeader in frame_reader.go ==="
grep -n "readAndCheckFrameHeader" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go | head -5
