
# Check for Target 2 remaining items
echo "=== Checking for UnaryEndpoint types in pkg/endpoint ==="
grep -n "UnaryEndpoint\|UnaryMiddleware\|UnaryChain" /app/pkg/endpoint/endpoint.go 2>&1 | head -20

echo -e "\n=== Checking for deprecated.go in pkg/endpoint ==="
ls -la /app/pkg/endpoint/deprecated.go 2>&1
