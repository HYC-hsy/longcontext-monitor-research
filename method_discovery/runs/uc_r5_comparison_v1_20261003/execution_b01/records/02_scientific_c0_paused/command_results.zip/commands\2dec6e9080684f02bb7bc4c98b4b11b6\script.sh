
# Check transport package structure
echo "=== Transport package ==="
ls -la /app/transport 2>&1 | head -20

echo -e "\n=== Checking pkg/remote/codec/thrift ==="
ls -la /app/pkg/remote/codec/thrift 2>&1 | head -20

echo -e "\n=== Checking pkg/remote/trans/nphttp2 ==="
ls -la /app/pkg/remote/trans/nphttp2 2>&1 | head -20
