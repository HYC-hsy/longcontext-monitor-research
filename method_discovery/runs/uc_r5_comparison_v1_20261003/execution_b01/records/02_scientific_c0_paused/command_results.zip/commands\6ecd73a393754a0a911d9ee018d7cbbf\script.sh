
# Check previously noted violation 1: deprecated.go signatures
echo "=== Checking deprecated.go RecvEndpoint/SendEndpoint signatures ==="
grep -A 1 "type RecvEndpoint\|type SendEndpoint" /app/pkg/endpoint/deprecated.go | head -6

# Check previously noted violation 2: HESSIAN2 casing in composites
echo -e "\n=== Checking transport/keys.go HESSIAN2 casing in composites ==="
grep -n "HESSIAN2\|Hessian2" /app/transport/keys.go | grep -v "case HESSIAN2"
