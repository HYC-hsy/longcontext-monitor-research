
# Check Target 6 specific requirements
echo "=== Checking for connPool.Dump() method ==="
grep -n "func.*Dump()" /app/pkg/remote/trans/nphttp2/conn_pool.go 2>&1 | head -5

echo -e "\n=== Checking for frame_reader.go and readAndCheckFrameHeader ==="
find /app -path "*/grpc/grpcframe/frame_reader.go" 2>/dev/null
grep -n "readAndCheckFrameHeader" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go 2>&1 | head -5
