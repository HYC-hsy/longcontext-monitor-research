
# Search for Dump method in entire conn_pool.go
grep -n "Dump" /app/pkg/remote/trans/nphttp2/conn_pool.go

# Check the connPool type definition and its methods
grep -n "type connPool" /app/pkg/remote/trans/nphttp2/conn_pool.go
grep -n "^func.*connPool" /app/pkg/remote/trans/nphttp2/conn_pool.go | head -20
