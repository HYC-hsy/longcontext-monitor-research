
# Verify Target 6 requirement 2: readAndCheckFrameHeader with hex error formatting
echo "=== Target 6 Requirement 2: readAndCheckFrameHeader hex errors ==="
grep -A 15 "func.*readAndCheckFrameHeader" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go | grep -A 10 "ErrFrameTooLarge\|invalid frame"
