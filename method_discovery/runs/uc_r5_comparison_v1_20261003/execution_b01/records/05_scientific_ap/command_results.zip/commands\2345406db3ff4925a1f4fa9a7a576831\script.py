
import subprocess

# Check the current Protocol constants in keys.go
result = subprocess.run(
    ['grep', '-A', '15', 'const (', '/app/transport/keys.go'],
    capture_output=True, text=True
)
print("Protocol constants in keys.go:")
print(result.stdout[:800])
