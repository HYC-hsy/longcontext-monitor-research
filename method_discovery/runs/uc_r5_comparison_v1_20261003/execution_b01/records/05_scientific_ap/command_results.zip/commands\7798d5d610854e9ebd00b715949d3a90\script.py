
import os

# Check all possible locations
locations = [
    "/app/cep.go",
    "/app/sep.go", 
    "/opt/genericagent/temp/cep.go",
    "/opt/genericagent/temp/sep.go",
    "/app/pkg/endpoint/cep/cep.go",
    "/app/pkg/endpoint/sep/sep.go"
]

print("File locations:")
for loc in locations:
    exists = os.path.exists(loc)
    print(f"  {loc}: {'EXISTS' if exists else 'NOT FOUND'}")

print("\nDirectory status:")
print(f"  /app/pkg/endpoint/cep: {'EXISTS' if os.path.exists('/app/pkg/endpoint/cep') else 'NOT FOUND'}")
print(f"  /app/pkg/endpoint/sep: {'EXISTS' if os.path.exists('/app/pkg/endpoint/sep') else 'NOT FOUND'}")
