
import os

# Check for key directories mentioned in the task
key_paths = [
    "/app/pkg/streaming",
    "/app/pkg/endpoint/cep",
    "/app/pkg/endpoint/sep",
    "/app/pkg/endpoint",
    "/app/transport",
    "/app/pkg/remote/codec/thrift",
    "/app/client",
    "/app/pkg/remote/trans/nphttp2"
]

for path in key_paths:
    exists = os.path.exists(path)
    is_dir = os.path.isdir(path) if exists else False
    print(f"{path}: {'EXISTS (dir)' if is_dir else 'EXISTS (file)' if exists else 'DOES NOT EXIST'}")
