
import os
import subprocess

# Check Target 2 completeness
print("Target 2 verification:")
print(f"  deprecated.go exists: {os.path.exists('/app/pkg/endpoint/deprecated.go')}")
print(f"  cep/cep.go exists: {os.path.exists('/app/pkg/endpoint/cep/cep.go')}")
print(f"  sep/sep.go exists: {os.path.exists('/app/pkg/endpoint/sep/sep.go')}")

# Check if UnaryEndpoint was added to endpoint.go
result = subprocess.run(['grep', '-E', 'type UnaryEndpoint|UnaryMiddleware', '/app/pkg/endpoint/endpoint.go'],
                       capture_output=True, text=True)
print(f"\nUnaryEndpoint in endpoint.go:")
print(result.stdout if result.stdout else "  NOT FOUND")

# Check what's in transport package
result = subprocess.run(['grep', '-r', 'type Protocol', '/app/transport/'],
                       capture_output=True, text=True)
print(f"\nProtocol type in /app/transport:")
print(result.stdout if result.stdout else "  NOT FOUND")
