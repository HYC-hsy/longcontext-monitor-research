
import os
import subprocess

# Check current state
cep = os.path.exists("/app/pkg/endpoint/cep")
sep = os.path.exists("/app/pkg/endpoint/sep")

print(f"cep exists: {cep}")
print(f"sep exists: {sep}")

# List endpoint directory
result = subprocess.run(['ls', '-la', '/app/pkg/endpoint/'], 
                       capture_output=True, text=True)
print("\npkg/endpoint:")
print(result.stdout)

# Check if there are any new Go files in streaming
result = subprocess.run(['ls', '-la', '/app/pkg/streaming/'], 
                       capture_output=True, text=True)
print("\npkg/streaming:")
print(result.stdout)
