
import os
import subprocess

# Check if Target 5 required files exist
files = {
    "/app/client/option.go": "type aliases and TailOption",
    "/app/client/option_unary.go": "unary option functions",
    "/app/client/option_stream.go": "stream option functions", 
    "/app/client/option_ttstream.go": "TTHeader streaming option functions",
    "/app/client/callopt/streamcall": "WithRecvTimeout call option"
}

print("Target 5 required files check:")
for path, desc in files.items():
    if os.path.isfile(path):
        print(f"✓ {path} ({desc})")
    elif os.path.isdir(path):
        print(f"? {path} is directory")
    else:
        print(f"✗ {path} MISSING ({desc})")
