
import subprocess

# Quick check Target 6 Dump() method exists
print("Target 6a: Dump() method in conn_pool.go")
result = subprocess.run(
    ['grep', '-n', 'func.*Dump()', '/app/pkg/remote/trans/nphttp2/conn_pool.go'],
    capture_output=True, text=True
)
print(result.stdout if result.stdout else "NOT FOUND")

# Quick check Target 6b frame error enhancements
print("\nTarget 6b: Frame error enhancements in frame_reader.go")
result = subprocess.run(
    ['grep', '-n', 'frame type\|frameType', '/app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go'],
    capture_output=True, text=True
)
print(result.stdout[:300] if result.stdout else "NOT FOUND")
