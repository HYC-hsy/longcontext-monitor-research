
import os
import subprocess

# Quick verification of Target 5 key files and functions
print("Target 5 verification:\n")

files_to_check = {
    "/app/client/option_unary.go": ["WithUnaryOptions", "WithUnaryRPCTimeout", "WithUnaryMiddleware"],
    "/app/client/option_stream.go": ["WithStreamOptions", "WithStreamRecvTimeout", "WithStreamMiddleware"],
    "/app/client/option_ttstream.go": ["WithTTHeaderStreamingOptions"],
    "/app/client/option.go": ["TailOption"],
    "/app/client/callopt/streamcall/call_options.go": ["WithRecvTimeout"]
}

for filepath, required_funcs in files_to_check.items():
    if not os.path.exists(filepath):
        print(f"✗ {filepath} MISSING")
        continue
    
    print(f"✓ {filepath} exists")
    for func in required_funcs:
        result = subprocess.run(['grep', '-c', func, filepath], capture_output=True, text=True)
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        status = "✓" if count > 0 else "✗"
        print(f"  {status} {func}: {count} occurrence(s)")
