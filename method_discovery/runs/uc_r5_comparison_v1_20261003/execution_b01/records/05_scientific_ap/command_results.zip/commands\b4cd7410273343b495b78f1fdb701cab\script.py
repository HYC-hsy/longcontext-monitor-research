
# Quick verification that files have correct structure
import subprocess

# Check cep.go has required elements
result = subprocess.run(
    ['grep', '-E', 'package cep|StreamRecvEndpoint.*EqualsTo|StreamSendEndpoint.*EqualsTo|DummyDummyMiddleware', 
     '/app/pkg/endpoint/cep/cep.go'],
    capture_output=True, text=True
)
print("cep.go key elements:")
print(result.stdout[:500] if result.stdout else "NOT FOUND")

# Check sep.go has package and StreamEndpoint
result = subprocess.run(
    ['grep', '-E', 'package sep|type StreamEndpoint|StreamChain',
     '/app/pkg/endpoint/sep/sep.go'],
    capture_output=True, text=True
)
print("\nsep.go key elements:")
print(result.stdout[:500] if result.stdout else "NOT FOUND")
