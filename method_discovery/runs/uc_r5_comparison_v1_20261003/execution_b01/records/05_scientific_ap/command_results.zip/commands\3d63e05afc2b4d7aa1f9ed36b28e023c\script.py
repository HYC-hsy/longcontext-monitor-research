
import os

# Check file locations and sizes
files = {
    "/app/cep.go": None,
    "/app/sep.go": None,
    "/app/pkg/endpoint/cep/cep.go": None,
    "/app/pkg/endpoint/sep/sep.go": None
}

for path in files:
    if os.path.exists(path):
        size = os.path.getsize(path)
        files[path] = f"{size} bytes"
    else:
        files[path] = "NOT FOUND"

for path, status in files.items():
    print(f"{path}: {status}")
