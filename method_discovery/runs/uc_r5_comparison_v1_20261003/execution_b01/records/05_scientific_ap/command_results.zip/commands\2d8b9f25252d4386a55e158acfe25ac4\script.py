
import os

# Check file sizes
files = {
    "/app/pkg/endpoint/cep/cep.go": os.path.getsize("/app/pkg/endpoint/cep/cep.go") if os.path.exists("/app/pkg/endpoint/cep/cep.go") else "NOT FOUND",
    "/app/pkg/endpoint/sep/sep.go": os.path.getsize("/app/pkg/endpoint/sep/sep.go") if os.path.exists("/app/pkg/endpoint/sep/sep.go") else "NOT FOUND"
}

print("File sizes:")
for path, size in files.items():
    print(f"  {path}: {size} bytes")

# Expected: cep.go ~3574, sep.go ~3046
print("\nExpected sizes: cep.go=3574, sep.go=3046")
