
import os

# Check current state
locations = {
    "/app/cep.go": os.path.exists("/app/cep.go"),
    "/app/sep.go": os.path.exists("/app/sep.go"),
    "/app/pkg/endpoint/cep/cep.go": os.path.exists("/app/pkg/endpoint/cep/cep.go"),
    "/app/pkg/endpoint/sep/sep.go": os.path.exists("/app/pkg/endpoint/sep/sep.go"),
    "/app/pkg/endpoint/cep (dir)": os.path.exists("/app/pkg/endpoint/cep"),
    "/app/pkg/endpoint/sep (dir)": os.path.exists("/app/pkg/endpoint/sep")
}

for loc, exists in locations.items():
    print(f"{loc}: {'✓' if exists else '✗'}")
