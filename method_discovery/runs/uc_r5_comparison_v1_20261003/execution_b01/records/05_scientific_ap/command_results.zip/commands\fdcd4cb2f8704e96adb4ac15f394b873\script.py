
import subprocess

# Verify Target 5: OptionCategory enum in client/callopt/options.go
print("Target 5 verification: OptionCategory enum")
result = subprocess.run(
    ['grep', '-A', '10', 'type OptionCategory', '/app/client/callopt/options.go'],
    capture_output=True, text=True
)
print(result.stdout[:600] if result.stdout else "NOT FOUND")

# Check for String() method
result2 = subprocess.run(
    ['grep', '-A', '3', 'func (c OptionCategory) String()', '/app/client/callopt/options.go'],
    capture_output=True, text=True
)
print("\nString() method:")
print(result2.stdout[:300] if result2.stdout else "NOT FOUND")
