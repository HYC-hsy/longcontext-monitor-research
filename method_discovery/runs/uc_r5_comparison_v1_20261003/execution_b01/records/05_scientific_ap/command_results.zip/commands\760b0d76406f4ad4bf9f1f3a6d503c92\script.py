
import os
import subprocess

# List files in pkg/streaming to see what exists
result = subprocess.run(['ls', '-la', '/app/pkg/streaming/'], 
                       capture_output=True, text=True)
print("pkg/streaming contents:")
print(result.stdout)

# Check what's in pkg/endpoint
result = subprocess.run(['ls', '-la', '/app/pkg/endpoint/'], 
                       capture_output=True, text=True)
print("\npkg/endpoint contents:")
print(result.stdout)
