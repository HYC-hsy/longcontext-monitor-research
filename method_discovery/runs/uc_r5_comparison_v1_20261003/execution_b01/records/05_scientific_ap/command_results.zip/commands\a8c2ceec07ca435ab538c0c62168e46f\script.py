
import os

# Check file status
files = {
    "/app/cep.go": None,
    "/app/sep.go": None,
    "/app/pkg/endpoint/cep/cep.go": None,
    "/app/pkg/endpoint/sep/sep.go": None
}

for path in files:
    if os.path.exists(path):
        size = os.path.getsize(path)
        files[path] = f"{size} bytes"
    else:
        files[path] = "NOT FOUND"

print("File status:")
for path, status in files.items():
    print(f"  {path}: {status}")

# Expected sizes from originals
print("\nComparison:")
print("  cep.go: actual at /app/pkg/endpoint/cep = %s, original at /app = %s" % 
      (files["/app/pkg/endpoint/cep/cep.go"], files["/app/cep.go"]))
print("  sep.go: actual at /app/pkg/endpoint/sep = %s, original at /app = %s" % 
      (files["/app/pkg/endpoint/sep/sep.go"], files["/app/sep.go"]))
