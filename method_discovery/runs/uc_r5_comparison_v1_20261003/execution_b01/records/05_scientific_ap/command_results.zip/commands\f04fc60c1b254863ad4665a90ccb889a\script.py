
import subprocess

# Get all OptionCategory constants
result = subprocess.run(
    ['grep', '-E', 'Category OptionCategory|Category$', '/app/client/callopt/options.go'],
    capture_output=True, text=True
)
lines = result.stdout.strip().split('\n')
categories = [line.strip() for line in lines if 'Category' in line and '=' not in line and '//' not in line]

print(f"Found {len(categories)} OptionCategory constants:")
for cat in categories[:10]:
    print(f"  {cat}")
