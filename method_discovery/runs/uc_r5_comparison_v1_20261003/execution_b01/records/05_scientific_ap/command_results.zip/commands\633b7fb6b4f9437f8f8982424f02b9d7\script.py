
import os
import subprocess

# Check if cep and sep directories exist
cep_path = "/app/pkg/endpoint/cep"
sep_path = "/app/pkg/endpoint/sep"

print(f"cep exists: {os.path.exists(cep_path)}")
print(f"sep exists: {os.path.exists(sep_path)}")

# Check what's in pkg/endpoint
result = subprocess.run(['ls', '-la', '/app/pkg/endpoint/'], 
                       capture_output=True, text=True)
print("\npkg/endpoint contents:")
print(result.stdout)
