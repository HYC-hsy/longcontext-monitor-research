
import os
import subprocess

# Check where files are
locations = [
    "/app/cep.go",
    "/app/sep.go",
    "/app/pkg/endpoint/cep/cep.go",
    "/app/pkg/endpoint/sep/sep.go"
]

for loc in locations:
    exists = os.path.exists(loc)
    print(f"{loc}: {'EXISTS' if exists else 'NOT FOUND'}")

# Check if directories exist
print("\nDirectories:")
print(f"/app/pkg/endpoint/cep: {'EXISTS' if os.path.exists('/app/pkg/endpoint/cep') else 'NOT FOUND'}")
print(f"/app/pkg/endpoint/sep: {'EXISTS' if os.path.exists('/app/pkg/endpoint/sep') else 'NOT FOUND'}")

# List /app/pkg/endpoint
result = subprocess.run(['ls', '-la', '/app/pkg/endpoint/'], 
                       capture_output=True, text=True)
print("\n/app/pkg/endpoint contents:")
print(result.stdout)
