
import os

# Check final file status
files = {
    "/app/cep.go": None,
    "/app/sep.go": None,
    "/app/pkg/endpoint/cep/cep.go": None,
    "/app/pkg/endpoint/sep/sep.go": None
}

for path in files:
    if os.path.exists(path):
        size = os.path.getsize(path)
        files[path] = size
    else:
        files[path] = "NOT FOUND"

print("File status:")
for path, status in files.items():
    marker = "✓" if isinstance(status, int) and status > 3000 else ""
    print(f"  {path}: {status} {marker}")

# Check if files at correct paths are complete enough
target_cep = files["/app/pkg/endpoint/cep/cep.go"]
target_sep = files["/app/pkg/endpoint/sep/sep.go"]

print(f"\nTarget files complete enough? (>3000 bytes as heuristic)")
print(f"  cep.go: {target_cep if isinstance(target_cep, int) else 'MISSING'} - {'✓' if isinstance(target_cep, int) and target_cep > 3000 else 'truncated'}")
print(f"  sep.go: {target_sep if isinstance(target_sep, int) else 'MISSING'} - {'✓' if isinstance(target_sep, int) and target_sep > 3000 else 'truncated/missing'}")
