
import subprocess

# Verify cep.go has required elements
print("Checking /app/pkg/endpoint/cep/cep.go:")
result = subprocess.run(
    ['grep', '-E', 'stream streaming.ClientStream|EqualsTo.*bool|DummyDummyMiddleware',
     '/app/pkg/endpoint/cep/cep.go'],
    capture_output=True, text=True
)
lines = result.stdout.strip().split('\n') if result.stdout else []
print(f"  Found {len(lines)} matching lines")
for line in lines[:5]:
    print(f"    {line[:80]}")

# Verify sep.go has ServerStream
print("\nChecking /app/pkg/endpoint/sep/sep.go:")
result = subprocess.run(
    ['grep', '-E', 'stream streaming.ServerStream',
     '/app/pkg/endpoint/sep/sep.go'],
    capture_output=True, text=True
)
lines = result.stdout.strip().split('\n') if result.stdout else []
print(f"  Found {len(lines)} matching lines with ServerStream")
for line in lines[:3]:
    print(f"    {line[:80]}")
