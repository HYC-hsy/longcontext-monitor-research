
# Check what directory structure was actually created for Target 2
ls -la /app/pkg/endpoint/
echo "---"
ls -la /app/pkg/endpoint/cep/ 2>/dev/null || echo "cep/ directory does not exist"
echo "---"
ls -la /app/pkg/endpoint/sep/ 2>/dev/null || echo "sep/ directory does not exist"
