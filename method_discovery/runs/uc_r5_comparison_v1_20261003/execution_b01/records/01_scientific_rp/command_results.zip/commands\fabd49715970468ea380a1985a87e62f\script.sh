
# Target 5 migration requirement: find WHERE WithFailureRetry is defined
find /app -name "*.go" -type f -exec grep -l "func WithFailureRetry" {} \; 2>/dev/null | head -5

echo "---"

# Target 6: Search for hex dump error format more broadly
grep -r "invalid frame.*#x\|ErrFrameTooLarge" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/ 2>/dev/null | head -5
