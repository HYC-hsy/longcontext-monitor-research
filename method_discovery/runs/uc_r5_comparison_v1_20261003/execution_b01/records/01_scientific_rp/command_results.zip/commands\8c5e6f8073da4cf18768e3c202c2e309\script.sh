
# Target 2: Check for EqualsTo methods on StreamRecvEndpoint in cep
grep -A 5 "func.*EqualsTo" /app/pkg/endpoint/cep/cep.go

echo "---"

# Target 4: Check thrift_data.go for Basic codec fallback
grep -n "Basic\|fallback\|FastCodec\|Frugal" /app/pkg/remote/codec/thrift/thrift_data.go | head -10
