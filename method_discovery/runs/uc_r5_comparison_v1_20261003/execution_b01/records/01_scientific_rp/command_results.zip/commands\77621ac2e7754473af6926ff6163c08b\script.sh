
# Target 5: Check for TailOption
grep -n "TailOption\|TailHook" /app/client/option_unary.go | head -5

echo "---"

# Target 5: Check WithFailureRetry uses UnaryOptions.RetryMethodPolicies
grep -A 3 "WithFailureRetry" /app/client/option_unary.go | head -10

echo "---"

# Target 6: Check connPool.Dump method
grep -n "func.*Dump" /app/pkg/remote/trans/nphttp2/conn_pool.go
