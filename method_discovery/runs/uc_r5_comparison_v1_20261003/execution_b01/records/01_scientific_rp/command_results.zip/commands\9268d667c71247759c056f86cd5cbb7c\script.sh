
# Target 5: Check if WithFailureRetry stores in UnaryOptions.RetryMethodPolicies
grep -A 10 "func WithFailureRetry" /app/client/option_unary.go | grep -E "RetryMethodPolicies|UnaryOptions"

echo "---"

# Target 6: Check readAndCheckFrameHeader method with hex dump in error
grep -A 10 "readAndCheckFrameHeader\|invalid frame" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go | head -20
