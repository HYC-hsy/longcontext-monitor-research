
# Check what already exists in the key packages
ls -la /app/pkg/streaming/
echo "---"
ls -la /app/pkg/endpoint/
echo "---"
find /app/pkg/remote -name "*thrift*" -type f | head -10
