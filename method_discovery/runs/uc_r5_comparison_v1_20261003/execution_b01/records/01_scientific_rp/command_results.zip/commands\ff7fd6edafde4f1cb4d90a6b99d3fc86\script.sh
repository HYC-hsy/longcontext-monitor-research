
# Target 5: More precise check - look at WithFailureRetry implementation
grep -B 2 -A 15 "^func WithFailureRetry" /app/client/option_unary.go

echo "==="

# Target 6: Look for the actual method name from task requirements
grep -n "readAndCheckFrameHeader" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go
