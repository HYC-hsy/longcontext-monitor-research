
# Check if any of the target packages already exist
ls -la /app/pkg/ | grep -E "streaming|endpoint"
ls -la /app/client/ 2>/dev/null | head -10
