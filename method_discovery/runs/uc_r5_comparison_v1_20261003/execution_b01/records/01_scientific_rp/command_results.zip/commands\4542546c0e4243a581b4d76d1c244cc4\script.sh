
# Search for default protocol or transport references in rpcconfig.go
grep -n -i "transport\|protocol\|framed\|purepayload" /app/pkg/rpcinfo/rpcconfig.go | head -20
