
# Check what files exist in pkg/streaming
ls -la /app/pkg/streaming/
