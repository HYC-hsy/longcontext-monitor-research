
# Target 2: Check for DummyDummyMiddleware (unique requirement - double "Dummy")
grep -n "DummyDummyMiddleware" /app/pkg/endpoint/cep/cep.go
