
# Check transport package
ls -la /app/transport/ 2>/dev/null || ls -la /app/pkg/remote/trans* 2>/dev/null | head -20
