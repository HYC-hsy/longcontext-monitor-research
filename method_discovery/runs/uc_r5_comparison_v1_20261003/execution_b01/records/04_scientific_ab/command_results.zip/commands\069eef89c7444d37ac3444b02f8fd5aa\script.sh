
# Check if Dump was added to the interface in pkg/remote/connpool.go
grep -B 2 -A 2 "Dump" /app/pkg/remote/connpool.go 2>&1
