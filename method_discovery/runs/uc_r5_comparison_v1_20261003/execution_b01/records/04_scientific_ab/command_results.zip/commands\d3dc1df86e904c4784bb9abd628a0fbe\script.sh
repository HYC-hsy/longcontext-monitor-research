
# Check if WithRecvTimeout exists in streamcall package
grep -r "WithRecvTimeout" /app/client/callopt/streamcall/ 2>&1 || echo "WithRecvTimeout not found in streamcall"
