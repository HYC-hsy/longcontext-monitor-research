
# Check if WithFailureRetry now stores in o.UnaryOptions.RetryMethodPolicies
grep -A 10 "func WithFailureRetry" /app/client/option.go | head -15
