
# Check if frame_reader connError was enhanced with frame details
grep -A 5 "connError" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go | head -10
