
# Check if WithFailureRetry, WithBackupRequest, WithRetryContainer, WithFallback exist in client/ and if they were modified recently
find /app/client -name "*.go" -exec grep -l "WithFailureRetry\|WithBackupRequest\|WithRetryContainer\|WithFallback" {} \; | head -5
