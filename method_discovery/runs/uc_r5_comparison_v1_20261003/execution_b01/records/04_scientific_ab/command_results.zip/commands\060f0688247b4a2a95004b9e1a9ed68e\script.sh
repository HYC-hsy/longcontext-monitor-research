
# Check if callopt/streamcall package exists and has WithRecvTimeout
find /app/client/callopt -name "*.go" 2>/dev/null | head -10
ls -la /app/client/callopt/streamcall/ 2>&1 || echo "streamcall directory not found"
