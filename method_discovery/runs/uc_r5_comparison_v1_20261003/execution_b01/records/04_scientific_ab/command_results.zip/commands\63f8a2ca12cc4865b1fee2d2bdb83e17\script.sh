
# Find the connError function implementation to see if it includes frame details
grep -n "func.*connError" /app/pkg/remote/trans/nphttp2/grpc/grpcframe/frame_reader.go
