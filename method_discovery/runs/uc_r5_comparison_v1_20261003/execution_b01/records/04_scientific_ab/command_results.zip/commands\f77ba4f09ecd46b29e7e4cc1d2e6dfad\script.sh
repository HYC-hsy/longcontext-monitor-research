
# Find transport protocol definitions
find /app/pkg/remote -name "*.go" | xargs grep -l "type Protocol" | head -5
