
# Find and read the thrift_data.go file to verify the Agent's claim
find /app -name "thrift_data.go" -path "*/codec/thrift/*"
