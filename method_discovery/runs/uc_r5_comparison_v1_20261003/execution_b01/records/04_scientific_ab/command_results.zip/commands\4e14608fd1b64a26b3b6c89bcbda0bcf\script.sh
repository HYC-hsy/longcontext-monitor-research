
# Check the correct file from Target 6 requirement
grep -n "Dump" /app/pkg/remote/trans/nphttp2/conn_pool.go 2>&1 | head -5
