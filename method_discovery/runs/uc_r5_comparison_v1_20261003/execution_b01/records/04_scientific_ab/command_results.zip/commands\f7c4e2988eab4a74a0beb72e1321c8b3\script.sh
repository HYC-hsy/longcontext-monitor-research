
# Check if frame_reader.go was enhanced with frame details in error messages
find /app -path "*/nphttp2/grpc*/frame_reader.go" | head -3
