
# Check endpoint package structure
ls -la /app/pkg/endpoint/ 2>&1
echo "---"
# Check if transport protocol constants exist
find /app -name "protocol.go" -o -name "transport.go" | grep -E "(pkg/remote|transport)" | head -5
