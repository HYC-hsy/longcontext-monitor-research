
# Verify Dump() method exists in connpool
grep -n "func.*Dump" /app/pkg/remote/connpool.go 2>&1 | head -3
