
# Verify WithRetryContainer now stores in o.UnaryOptions.RetryContainer
grep -A 10 "func WithRetryContainer" /app/client/option_advanced.go
