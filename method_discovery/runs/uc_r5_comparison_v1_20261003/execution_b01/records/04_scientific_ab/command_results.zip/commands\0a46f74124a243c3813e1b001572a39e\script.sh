
# Check if WithFailureRetry stores in o.UnaryOptions.RetryMethodPolicies or old o.RetryMethodPolicies
grep -A 10 "func WithFailureRetry" /app/client/option.go | head -15
