
# Check transport package for Protocol type
grep -A 30 "type Protocol" /app/transport/*.go 2>/dev/null || echo "Not in /app/transport"
find /app -path "*/transport/*.go" -exec grep -l "type Protocol" {} \; | head -3
