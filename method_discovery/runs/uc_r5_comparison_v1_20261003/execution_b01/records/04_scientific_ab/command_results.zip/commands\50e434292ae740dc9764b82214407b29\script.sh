
# Find the connpool file and check for Dump method
find /app -name "connpool.go" -o -name "conn_pool.go" | head -5
