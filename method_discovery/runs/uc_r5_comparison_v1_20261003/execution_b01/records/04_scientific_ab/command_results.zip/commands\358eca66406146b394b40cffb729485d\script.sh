
# Check if client_streaming.go and bidi_streaming.go exist
ls -la /app/pkg/streaming/*.go
