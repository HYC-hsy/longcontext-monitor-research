
# Check if WithRecvTimeout exists in streamcall and what field it sets
grep -A 5 "WithRecvTimeout" /app/client/callopt/streamcall/call_options.go
