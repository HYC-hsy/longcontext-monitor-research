
# Check for the key packages mentioned in the task
echo "=== Checking pkg/streaming ==="
ls -la /app/pkg/streaming/ 2>&1 | head -20

echo -e "\n=== Checking pkg/endpoint ==="
ls -la /app/pkg/endpoint/ 2>&1 | head -20

echo -e "\n=== Checking pkg/endpoint/cep ==="
ls -la /app/pkg/endpoint/cep/ 2>&1 | head -20

echo -e "\n=== Checking pkg/endpoint/sep ==="
ls -la /app/pkg/endpoint/sep/ 2>&1 | head -20

echo -e "\n=== Checking transport package ==="
ls -la /app/transport/ 2>&1 | head -20

echo -e "\n=== Checking client package ==="
ls -la /app/client/ 2>&1 | head -20
