
# Check the actual field assignment in WithFallback
grep -A 5 "func WithFallback" /app/client/option.go | grep -E "o\.|Fallback"
