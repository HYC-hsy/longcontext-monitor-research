
ls -la /app/client/callopt/streamcall/ 2>&1
