
# Check for transport protocol definitions
find /app -name "*.go" -type f | xargs grep -l "type Protocol" | head -5
