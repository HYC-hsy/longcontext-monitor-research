
ls -la /app/client/*.go 2>&1 | grep -E "option_unary|option_stream|option_ttstream"
echo "---"
ls -la /app/client/callopt/ 2>&1
