
# Check if WithFallback stores to UnaryOptions.Fallback
grep -A 3 "func WithFallback" /app/client/option.go | head -10
