package validation

import (
	"fyne.io/fyne/v2"
)

// NewAllStrings creates a validator combinator that runs all provided validators in order.
// It returns the first error encountered, or nil if all validators pass.
// This allows combining multiple validation rules into a single validator.
//
// Example:
//
//	validator := validation.NewAllStrings(
//		validation.NewRegexp(`^\d+$`, "must contain only digits"),
//		func(s string) error {
//			if len(s) < 5 {
//				return fmt.Errorf("must be at least 5 characters")
//			}
//			return nil
//		},
//	)
//
// Since: 2.5
func NewAllStrings(validators ...fyne.StringValidator) fyne.StringValidator {
	return func(s string) error {
		for _, validator := range validators {
			if err := validator(s); err != nil {
				return err
			}
		}
		return nil
	}
}
