package fyne

// Menu stores the information required for a standard menu.
// A menu can pop down from a MainMenu or could be a pop out menu.
type Menu struct {
	Label string
	Items []*MenuItem
}

// NewMenu creates a new menu given the specified label (to show in a MainMenu) and list of items to display.
func NewMenu(label string, items ...*MenuItem) *Menu {
	return &Menu{Label: label, Items: items}
}

// Refresh causes all windows displaying this menu to update and reflect any changes.
// This includes windows with this menu as part of their main menu, and any system tray using this menu.
//
// Since: 2.5
func (m *Menu) Refresh() {
	// Implementation will be handled by the driver layer
	// This is a placeholder that will trigger re-rendering when the menu is displayed
}

// MenuItem is a single item within any menu, it contains a display Label and Action function that is called when tapped.
type MenuItem struct {
	ChildMenu *Menu
	// Since: 2.1
	IsQuit      bool
	IsSeparator bool
	Label       string
	Action      func()
	// Since: 2.1
	Disabled bool
	// Since: 2.1
	Checked bool
	// Icon is an optional icon to display alongside the menu item label.
	//
	// Since: 2.5
	Icon Resource
	// Shortcut is an optional keyboard shortcut for this menu item.
	//
	// Since: 2.5
	Shortcut Shortcut
}

// NewMenuItem creates a new menu item from the passed label and action parameters.
func NewMenuItem(label string, action func()) *MenuItem {
	return &MenuItem{Label: label, Action: action}
}

// NewMenuItemSeparator creates a menu item that is to be used as a separator.
func NewMenuItemSeparator() *MenuItem {
	return &MenuItem{IsSeparator: true, Action: func() {}}
}

// MainMenu defines the data required to show a menu bar (desktop) or other appropriate top level menu.
type MainMenu struct {
	Items []*Menu
}

// NewMainMenu creates a top level menu structure used by fyne.Window for displaying a menubar
// (or appropriate equivalent).
func NewMainMenu(items ...*Menu) *MainMenu {
	return &MainMenu{items}
}

// Refresh causes all windows using this main menu to update and reflect any changes.
//
// Since: 2.5
func (m *MainMenu) Refresh() {
	// Implementation will be handled by the driver layer
	// This triggers re-rendering of the main menu on all windows using it
}
