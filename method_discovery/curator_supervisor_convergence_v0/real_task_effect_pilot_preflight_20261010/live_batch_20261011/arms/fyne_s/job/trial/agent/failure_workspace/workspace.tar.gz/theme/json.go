package theme

import (
	"encoding/json"
	"errors"
	"fmt"
	"image/color"
	"io"
	"strconv"
	"strings"

	"fyne.io/fyne/v2"
)

// jsonTheme holds the theme data loaded from JSON
type jsonTheme struct {
	colorsGeneric map[fyne.ThemeColorName]color.Color // Generic colors from "Colors" section
	colorsDark    map[fyne.ThemeColorName]color.Color // Dark variant colors from "Colors-dark" section
	colorsLight   map[fyne.ThemeColorName]color.Color // Light variant colors from "Colors-light" section
	sizes         map[fyne.ThemeSizeName]float32
	fonts         map[fyne.TextStyle]fyne.Resource
	icons         map[fyne.ThemeIconName]fyne.Resource
}

// Color returns the color value for the specified theme color name
// Resolution order: variant-specific colors first, then generic Colors, then default theme fallback
func (t *jsonTheme) Color(name fyne.ThemeColorName, variant fyne.ThemeVariant) color.Color {
	// 1. Check variant-specific colors first
	if variant == VariantDark {
		if c, ok := t.colorsDark[name]; ok {
			return c
		}
	} else if variant == VariantLight {
		if c, ok := t.colorsLight[name]; ok {
			return c
		}
	}
	
	// 2. Check generic colors
	if c, ok := t.colorsGeneric[name]; ok {
		return c
	}
	
	// 3. Fallback to default theme
	return DefaultTheme().Color(name, variant)
}

// Font returns the font resource for the specified text style
func (t *jsonTheme) Font(style fyne.TextStyle) fyne.Resource {
	if f, ok := t.fonts[style]; ok {
		return f
	}
	return DefaultTheme().Font(style)
}

// Icon returns the resource for the specified theme icon name
func (t *jsonTheme) Icon(name fyne.ThemeIconName) fyne.Resource {
	if i, ok := t.icons[name]; ok {
		return i
	}
	return DefaultTheme().Icon(name)
}

// Size returns the size value for the specified theme size name
func (t *jsonTheme) Size(name fyne.ThemeSizeName) float32 {
	if s, ok := t.sizes[name]; ok {
		return s
	}
	return DefaultTheme().Size(name)
}

// parseHexColor parses a hex color string (e.g., "#RRGGBB" or "#RRGGBBAA") into a color.Color
func parseHexColor(hex string) (color.Color, error) {
	hex = strings.TrimPrefix(hex, "#")
	
	var r, g, b, a uint8 = 0, 0, 0, 255
	
	switch len(hex) {
	case 3:
		// RGB format (short) - each digit is duplicated
		// e.g., "abc" becomes "aabbcc"
		val, err := strconv.ParseUint(hex, 16, 16)
		if err != nil {
			return nil, fmt.Errorf("invalid hex color: %w", err)
		}
		// Extract each nibble and duplicate it
		rNibble := uint8((val >> 8) & 0xF)
		gNibble := uint8((val >> 4) & 0xF)
		bNibble := uint8(val & 0xF)
		r = (rNibble << 4) | rNibble
		g = (gNibble << 4) | gNibble
		b = (bNibble << 4) | bNibble
	case 4:
		// RGBA format (short) - each digit is duplicated
		// e.g., "abcd" becomes "aabbccdd"
		val, err := strconv.ParseUint(hex, 16, 16)
		if err != nil {
			return nil, fmt.Errorf("invalid hex color: %w", err)
		}
		// Extract each nibble and duplicate it
		rNibble := uint8((val >> 12) & 0xF)
		gNibble := uint8((val >> 8) & 0xF)
		bNibble := uint8((val >> 4) & 0xF)
		aNibble := uint8(val & 0xF)
		r = (rNibble << 4) | rNibble
		g = (gNibble << 4) | gNibble
		b = (bNibble << 4) | bNibble
		a = (aNibble << 4) | aNibble
	case 6:
		// RGB format
		val, err := strconv.ParseUint(hex, 16, 32)
		if err != nil {
			return nil, fmt.Errorf("invalid hex color: %w", err)
		}
		r = uint8(val >> 16)
		g = uint8(val >> 8)
		b = uint8(val)
	case 8:
		// RGBA format
		val, err := strconv.ParseUint(hex, 16, 32)
		if err != nil {
			return nil, fmt.Errorf("invalid hex color: %w", err)
		}
		r = uint8(val >> 24)
		g = uint8(val >> 16)
		b = uint8(val >> 8)
		a = uint8(val)
	default:
		return nil, fmt.Errorf("invalid hex color length: %d", len(hex))
	}
	
	return color.NRGBA{R: r, G: g, B: b, A: a}, nil
}

// FromJSON creates a new theme from a JSON string.
// The JSON should contain color and size definitions.
//
// Example JSON format:
//
//	{
//	  "colors": {
//	    "primary": "#FF0000",
//	    "background": "#FFFFFF"
//	  },
//	  "sizes": {
//	    "text": 14,
//	    "padding": 4
//	  }
//	}
//
// Since: 2.5
func FromJSON(data string) (fyne.Theme, error) {
	return FromJSONReader(strings.NewReader(data))
}

// FromJSONReader creates a new theme from a JSON reader.
// The JSON should contain color and size definitions.
//
// Since: 2.5
func FromJSONReader(r io.Reader) (fyne.Theme, error) {
	var raw map[string]interface{}
	
	decoder := json.NewDecoder(r)
	if err := decoder.Decode(&raw); err != nil {
		return nil, fmt.Errorf("failed to decode JSON: %w", err)
	}
	
	theme := &jsonTheme{
		colorsGeneric: make(map[fyne.ThemeColorName]color.Color),
		colorsDark:    make(map[fyne.ThemeColorName]color.Color),
		colorsLight:   make(map[fyne.ThemeColorName]color.Color),
		sizes:         make(map[fyne.ThemeSizeName]float32),
		fonts:         make(map[fyne.TextStyle]fyne.Resource),
		icons:         make(map[fyne.ThemeIconName]fyne.Resource),
	}
	
	// Parse colors (generic)
	if colorsRaw, ok := raw["colors"].(map[string]interface{}); ok {
		for name, value := range colorsRaw {
			if hexStr, ok := value.(string); ok {
				c, err := parseHexColor(hexStr)
				if err != nil {
					return nil, fmt.Errorf("invalid color for %s: %w", name, err)
				}
				theme.colorsGeneric[fyne.ThemeColorName(name)] = c
			}
		}
	}
	
	// Parse colors-dark
	if colorsRaw, ok := raw["colors-dark"].(map[string]interface{}); ok {
		for name, value := range colorsRaw {
			if hexStr, ok := value.(string); ok {
				c, err := parseHexColor(hexStr)
				if err != nil {
					return nil, fmt.Errorf("invalid color for %s: %w", name, err)
				}
				theme.colorsDark[fyne.ThemeColorName(name)] = c
			}
		}
	}
	
	// Parse colors-light
	if colorsRaw, ok := raw["colors-light"].(map[string]interface{}); ok {
		for name, value := range colorsRaw {
			if hexStr, ok := value.(string); ok {
				c, err := parseHexColor(hexStr)
				if err != nil {
					return nil, fmt.Errorf("invalid color for %s: %w", name, err)
				}
				theme.colorsLight[fyne.ThemeColorName(name)] = c
			}
		}
	}
	
	// Parse sizes
	if sizesRaw, ok := raw["sizes"].(map[string]interface{}); ok {
		for name, value := range sizesRaw {
			switch v := value.(type) {
			case float64:
				theme.sizes[fyne.ThemeSizeName(name)] = float32(v)
			case int:
				theme.sizes[fyne.ThemeSizeName(name)] = float32(v)
			default:
				return nil, errors.New(fmt.Sprintf("invalid size type for %s", name))
			}
		}
	}
	
	// Parse fonts (map of font style to URI)
	if fontsRaw, ok := raw["fonts"].(map[string]interface{}); ok {
		for styleName, value := range fontsRaw {
			if _, ok := value.(string); ok {
				res := fyne.NewStaticResource(styleName, []byte{}) // Placeholder - in real implementation would load from URI
				// Parse text style from string (e.g., "bold", "italic", "monospace")
				style := fyne.TextStyle{}
				switch styleName {
				case "bold":
					style.Bold = true
				case "italic":
					style.Italic = true
				case "monospace":
					style.Monospace = true
				case "bold-italic":
					style.Bold = true
					style.Italic = true
				}
				theme.fonts[style] = res
			}
		}
	}
	
	// Parse icons (map of icon name to URI)
	if iconsRaw, ok := raw["icons"].(map[string]interface{}); ok {
		for name, value := range iconsRaw {
			if _, ok := value.(string); ok {
				res := fyne.NewStaticResource(name, []byte{}) // Placeholder - in real implementation would load from URI
				theme.icons[fyne.ThemeIconName(name)] = res
			}
		}
	}
	
	return theme, nil
}
