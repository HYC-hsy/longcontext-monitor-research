package binding

import (
	"fmt"
	"sync"
	
	"fyne.io/fyne/v2/storage"
)

// sprintfBinding is a String binding that formats multiple source values using a format string
type sprintfBinding struct {
	base

	format  string
	sources []DataItem
	mu      sync.RWMutex
}

// Get returns the formatted string value
func (s *sprintfBinding) Get() (string, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	// Collect values from all sources with type switches
	values := make([]interface{}, len(s.sources))
	for i, source := range s.sources {
		switch src := source.(type) {
		case Bool:
			val, err := src.Get()
			if err != nil {
				return "", err
			}
			values[i] = val
		case Float:
			val, err := src.Get()
			if err != nil {
				return "", err
			}
			values[i] = val
		case Int:
			val, err := src.Get()
			if err != nil {
				return "", err
			}
			values[i] = val
		case Rune:
			val, err := src.Get()
			if err != nil {
				return "", err
			}
			values[i] = val
		case String:
			val, err := src.Get()
			if err != nil {
				return "", err
			}
			values[i] = val
		case URI:
			val, err := src.Get()
			if err != nil {
				return "", err
			}
			values[i] = val.String()
		case Untyped:
			// Untyped might be Bytes or other types
			val, err := src.Get()
			if err != nil {
				return "", err
			}
			values[i] = val
		default:
			return "", fmt.Errorf("unsupported source type: %T", source)
		}
	}

	return fmt.Sprintf(s.format, values...), nil
}

// Set parses the string using Sscanf and updates each source binding
func (s *sprintfBinding) Set(str string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	// Create scan targets for each source type
	targets := make([]interface{}, len(s.sources))
	for i, source := range s.sources {
		switch source.(type) {
		case Bool:
			var v bool
			targets[i] = &v
		case Float:
			var v float64
			targets[i] = &v
		case Int:
			var v int
			targets[i] = &v
		case Rune:
			var v rune
			targets[i] = &v
		case String:
			var v string
			targets[i] = &v
		case URI:
			var v string
			targets[i] = &v
		case Untyped:
			// Bytes cannot round-trip
			return fmt.Errorf("sprintf binding with Bytes/Untyped cannot be set (no round-trip support)")
		default:
			return fmt.Errorf("unsupported source type for Set: %T", source)
		}
	}

	// Parse the string
	n, err := fmt.Sscanf(str, s.format, targets...)
	if err != nil {
		return fmt.Errorf("failed to parse string: %w", err)
	}
	if n != len(s.sources) {
		return fmt.Errorf("format matched %d values but expected %d", n, len(s.sources))
	}

	// Apply parsed values to sources
	for i, source := range s.sources {
		switch src := source.(type) {
		case Bool:
			if err := src.Set(*targets[i].(*bool)); err != nil {
				return err
			}
		case Float:
			if err := src.Set(*targets[i].(*float64)); err != nil {
				return err
			}
		case Int:
			if err := src.Set(*targets[i].(*int)); err != nil {
				return err
			}
		case Rune:
			if err := src.Set(*targets[i].(*rune)); err != nil {
				return err
			}
		case String:
			if err := src.Set(*targets[i].(*string)); err != nil {
				return err
			}
		case URI:
			// Parse URI using storage.ParseURI
			uriStr := *targets[i].(*string)
			uri, err := storage.ParseURI(uriStr)
			if err != nil {
				return fmt.Errorf("failed to parse URI: %w", err)
			}
			if err := src.Set(uri); err != nil {
				return err
			}
		}
	}

	return nil
}

// NewSprintf returns a new String binding that formats one or more source bindings using the specified format string.
// The format string follows fmt.Sprintf conventions. Sources may be Bool, Float, Int, Rune, String, URI, or Untyped (Bytes) bindings.
//
// The resulting binding supports bidirectional updates:
//   - Get() formats the source values using fmt.Sprintf
//   - Set() parses the string using fmt.Sscanf and updates each source (except Bytes, which returns an error)
//
// Example:
//
//	firstName := binding.NewString()
//	lastName := binding.NewString()
//	fullName := binding.NewSprintf("%s %s", firstName, lastName)
//	firstName.Set("John")
//	lastName.Set("Doe")
//	// fullName.Get() returns "John Doe"
//	fullName.Set("Jane Smith")
//	// firstName.Get() returns "Jane", lastName.Get() returns "Smith"
//
// Since: 2.5
func NewSprintf(format string, sources ...DataItem) String {
	s := &sprintfBinding{
		format:  format,
		sources: sources,
	}

	// Setup listeners on all sources to trigger updates
	for _, source := range sources {
		source.AddListener(NewDataListener(func() {
			s.trigger()
		}))
	}

	return s
}

// stringToStringWithFormatBinding wraps a String binding with a format string
type stringToStringWithFormatBinding struct {
	base
	format string
	source String
}

// Get returns the formatted string value
func (s *stringToStringWithFormatBinding) Get() (string, error) {
	val, err := s.source.Get()
	if err != nil {
		return "", err
	}
	return fmt.Sprintf(s.format, val), nil
}

// Set parses the formatted string and updates the source
func (s *stringToStringWithFormatBinding) Set(str string) error {
	var val string
	n, err := fmt.Sscanf(str, s.format, &val)
	if err != nil {
		return fmt.Errorf("failed to parse string: %w", err)
	}
	if n != 1 {
		return fmt.Errorf("format matched %d values but expected 1", n)
	}
	return s.source.Set(val)
}

// StringToStringWithFormat returns a new String binding that formats a source String binding using the specified format.
// If the format is "%s" (identity), the original binding is returned directly without wrapping.
//
// Example:
//
//	name := binding.NewString()
//	name.Set("Alice")
//	greeting := binding.StringToStringWithFormat(name, "Hello, %s!")
//	// greeting.Get() returns "Hello, Alice!"
//
// Since: 2.5
func StringToStringWithFormat(source String, format string) String {
	// Optimization: return source directly for identity format
	if format == "%s" {
		return source
	}

	s := &stringToStringWithFormatBinding{
		format: format,
		source: source,
	}

	// Listen to source changes
	source.AddListener(NewDataListener(func() {
		s.trigger()
	}))

	return s
}
