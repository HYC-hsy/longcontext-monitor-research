# Target 3 sprintf Binding - Contract Violation Fix

## Problem
Current implementation violates behavioral contract:
1. Set() returns error instead of parsing with fmt.Sscanf
2. Get() assumes all sources are String type
3. StringToStringWithFormat doesn't optimize "%s" identity case

## Required Behavior (from task requirements)
1. **NewSprintf**: variadic DataItem sources (Bool, Bytes?, Float, Int, Rune, String, URI)
2. **Get()**: Format sources using fmt.Sprintf with type switches
3. **Set()**: Parse string with fmt.Sscanf and update each source
   - Special: Bytes cannot round-trip (return error)
   - Special: URI parsed via storage.ParseURI
4. **StringToStringWithFormat**: If format == "%s", return source directly (no wrapper)

## Binding Type Interfaces Found
- Bool: Get() (bool, error), Set(bool) error
- Float: Get() (float64, error), Set(float64) error
- Int: Get() (int, error), Set(int) error
- Rune: Get() (rune, error), Set(rune) error
- String: Get() (string, error), Set(string) error
- URI: Get() (fyne.URI, error), Set(fyne.URI) error
- Bytes: NOT FOUND in binditems.go (may be Untyped or special type)

## Implementation Strategy
1. Rewrite Get() with type switch for each source type
2. Rewrite Set() with fmt.Sscanf reverse parsing
3. Add "%s" optimization to StringToStringWithFormat
4. Handle Bytes/URI special cases
