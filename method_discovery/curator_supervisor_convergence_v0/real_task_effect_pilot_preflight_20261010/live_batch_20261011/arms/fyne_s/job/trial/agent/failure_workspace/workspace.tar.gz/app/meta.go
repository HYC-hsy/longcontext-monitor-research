package app

import "fyne.io/fyne/v2"

var appMetadata = fyne.AppMetadata{
	ID:      "com.example",
	Name:    "Fyne App",
	Version: "1.0.0",
	Build:   1,
}

// SetMetadata allows an application to override its metadata at runtime.
// This is typically called early in main() to set application identity information.
//
// Since: 2.5
func SetMetadata(meta fyne.AppMetadata) {
	appMetadata = meta
}
