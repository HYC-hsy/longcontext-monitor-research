package desktop

import "fyne.io/fyne/v2"

// App represents a desktop application with additional capabilities beyond the standard fyne.App interface.
// This interface extends the base App functionality with desktop-specific features.
//
// Since: 2.5
type App interface {
	fyne.App

	// SetSystemTrayMenu sets a menu to be displayed when the system tray icon is right-clicked.
	// The system tray icon must be enabled for this to have an effect.
	SetSystemTrayMenu(menu *fyne.Menu)

	// SetSystemTrayIcon sets the icon to be displayed in the system tray.
	// This icon represents the application in the system notification area.
	SetSystemTrayIcon(icon fyne.Resource)
}
