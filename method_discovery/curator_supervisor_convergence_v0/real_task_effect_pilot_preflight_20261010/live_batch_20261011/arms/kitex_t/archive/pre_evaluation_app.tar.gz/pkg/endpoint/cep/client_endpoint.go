/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cep

import (
	"context"
)

// SendEndpoint represents the send-side endpoint on the client.
// It processes outgoing requests before they are sent to the server.
type SendEndpoint func(ctx context.Context, req interface{}) (err error)

// SendMiddleware is a chainable send-side middleware.
type SendMiddleware func(next SendEndpoint) SendEndpoint

// SendMiddlewareBuilder builds a middleware with information from a context.
type SendMiddlewareBuilder func(ctx context.Context) SendMiddleware

// SendChain connects middlewares into one middleware.
func SendChain(mws ...SendMiddleware) SendMiddleware {
	return func(next SendEndpoint) SendEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// RecvEndpoint represents the receive-side endpoint on the client.
// It processes incoming responses after they are received from the server.
type RecvEndpoint func(ctx context.Context, resp interface{}) (err error)

// RecvMiddleware is a chainable receive-side middleware.
type RecvMiddleware func(next RecvEndpoint) RecvEndpoint

// RecvMiddlewareBuilder builds a middleware with information from a context.
type RecvMiddlewareBuilder func(ctx context.Context) RecvMiddleware

// RecvChain connects middlewares into one middleware.
func RecvChain(mws ...RecvMiddleware) RecvMiddleware {
	return func(next RecvEndpoint) RecvEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}
