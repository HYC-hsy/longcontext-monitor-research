/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"fmt"
	"time"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/rpcinfo"
	"github.com/cloudwego/kitex/pkg/utils"
)

// UnaryOption provides configuration specific to unary RPC calls.
// These options only apply to traditional request-response RPC patterns.

// WithUnaryTimeout sets the timeout for unary RPC calls.
// This timeout applies to the entire unary call lifecycle including encoding, network transmission, and decoding.
func WithUnaryTimeout(d time.Duration) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithUnaryTimeout(%s)", d))
		rpcinfo.AsMutableRPCConfig(o.Configs).SetRPCTimeout(d)
		o.Locks.Bits |= rpcinfo.BitRPCTimeout
	}}
}

// WithUnaryConnectTimeout sets the connection establishment timeout for unary RPC calls.
func WithUnaryConnectTimeout(d time.Duration) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithUnaryConnectTimeout(%s)", d))
		rpcinfo.AsMutableRPCConfig(o.Configs).SetConnectTimeout(d)
		o.Locks.Bits |= rpcinfo.BitConnectTimeout
	}}
}

// WithUnaryRetryPolicy configures retry behavior for unary RPC calls.
// Streaming RPCs typically do not support retry due to their stateful nature.
func WithUnaryRetryPolicy(p interface{}) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithUnaryRetryPolicy(%T)", p))
		// Implementation would set retry policy on o.RetryPolicy
		// This is a placeholder showing the categorization structure
	}}
}

// WithUnaryCircuitBreaker configures circuit breaker for unary RPC calls.
func WithUnaryCircuitBreaker(cb interface{}) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithUnaryCircuitBreaker(%T)", cb))
		// Implementation would set circuit breaker configuration
		// This is a placeholder showing the categorization structure
	}}
}
