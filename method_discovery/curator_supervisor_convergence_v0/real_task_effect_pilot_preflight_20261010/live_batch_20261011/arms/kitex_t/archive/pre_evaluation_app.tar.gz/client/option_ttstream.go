/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"fmt"
	"time"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/rpcinfo"
	"github.com/cloudwego/kitex/pkg/utils"
)

// TTStreamOption provides configuration specific to TTHeader streaming protocol.
// These options apply to Thrift streaming with TTHeader protocol.

// WithTTStreamTimeout sets the timeout for TTHeader streaming RPC sessions.
func WithTTStreamTimeout(d time.Duration) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTStreamTimeout(%s)", d))
		// TTStream-specific timeout configuration
		rpcinfo.AsMutableRPCConfig(o.Configs).SetRPCTimeout(d)
		o.Locks.Bits |= rpcinfo.BitRPCTimeout
	}}
}

// WithTTStreamMetadataSize configures the maximum metadata size for TTHeader streaming.
func WithTTStreamMetadataSize(size int) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTStreamMetadataSize(%d)", size))
		// Implementation would configure TTHeader metadata limits
	}}
}

// WithTTStreamFrameSize sets the frame size for TTHeader streaming protocol.
func WithTTStreamFrameSize(size int) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTStreamFrameSize(%d)", size))
		// Implementation would set TTHeader frame size
	}}
}

// WithTTStreamCompression enables compression for TTHeader streaming.
func WithTTStreamCompression(enabled bool) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTStreamCompression(%v)", enabled))
		// Implementation would configure TTHeader compression
	}}
}

// WithTTStreamHeaderKeys configures custom header keys for TTHeader streaming.
func WithTTStreamHeaderKeys(keys []string) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTStreamHeaderKeys(%v)", keys))
		// Implementation would set allowed header keys
	}}
}

// WithTTStreamBackpressure configures backpressure handling for TTHeader streaming.
func WithTTStreamBackpressure(threshold int) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithTTStreamBackpressure(%d)", threshold))
		// Implementation would configure backpressure threshold
	}}
}
