/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"fmt"
	"time"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/rpcinfo"
	"github.com/cloudwego/kitex/pkg/utils"
)

// StreamOption provides configuration specific to bidirectional streaming RPC (gRPC-style).
// These options apply to full-duplex streaming communication patterns.

// WithStreamTimeout sets the overall timeout for a streaming RPC session.
// Unlike unary calls, this applies to the entire stream lifetime, not individual messages.
func WithStreamTimeout(d time.Duration) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamTimeout(%s)", d))
		// Stream-specific timeout configuration
		rpcinfo.AsMutableRPCConfig(o.Configs).SetRPCTimeout(d)
		o.Locks.Bits |= rpcinfo.BitRPCTimeout
	}}
}

// WithStreamMaxConcurrent sets the maximum number of concurrent streams allowed.
func WithStreamMaxConcurrent(n int) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamMaxConcurrent(%d)", n))
		// Implementation would configure max concurrent streams
		// This is a placeholder showing the categorization structure
	}}
}

// WithStreamRecvBufferSize configures the receive buffer size for streaming RPCs.
func WithStreamRecvBufferSize(size int) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamRecvBufferSize(%d)", size))
		// Implementation would set stream receive buffer size
	}}
}

// WithStreamSendBufferSize configures the send buffer size for streaming RPCs.
func WithStreamSendBufferSize(size int) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamSendBufferSize(%d)", size))
		// Implementation would set stream send buffer size
	}}
}

// WithStreamFlowControl enables or disables flow control for streaming RPCs.
func WithStreamFlowControl(enabled bool) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamFlowControl(%v)", enabled))
		// Implementation would configure flow control settings
	}}
}

// WithStreamKeepalive configures keepalive settings for streaming connections.
func WithStreamKeepalive(interval, timeout time.Duration) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push(fmt.Sprintf("WithStreamKeepalive(interval=%s,timeout=%s)", interval, timeout))
		// Implementation would set keepalive parameters
	}}
}
