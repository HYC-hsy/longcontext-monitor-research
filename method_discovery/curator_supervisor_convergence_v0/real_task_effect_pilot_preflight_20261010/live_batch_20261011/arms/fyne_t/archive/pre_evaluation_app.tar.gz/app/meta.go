package app

import "fyne.io/fyne/v2"

var appMetadata = fyne.AppMetadata{
	ID:      "com.example",
	Name:    "Fyne App",
	Version: "1.0.0",
	Build:   1,
}

// SetMetadata sets the application metadata that will be returned by App.Metadata().
// This should be called before the app starts if you want to override the default values.
//
// Since: 2.5
func SetMetadata(m fyne.AppMetadata) {
	appMetadata = m
}
