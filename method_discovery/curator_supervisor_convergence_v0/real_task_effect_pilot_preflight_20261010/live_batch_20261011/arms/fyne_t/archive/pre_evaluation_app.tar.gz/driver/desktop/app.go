package desktop

import "fyne.io/fyne/v2"

// App defines desktop-specific app functionality.
// Desktop apps can have unique behavior like system tray integration,
// custom menus, and window management features.
//
// Since: 2.5
type App interface {
	fyne.App

	// SetSystemTrayMenu sets a custom menu to be displayed in the system tray.
	// If the icon parameter is nil, a default icon will be used.
	SetSystemTrayMenu(menu *fyne.Menu)

	// SetSystemTrayIcon sets the icon to display in the system tray.
	SetSystemTrayIcon(icon fyne.Resource)
}
