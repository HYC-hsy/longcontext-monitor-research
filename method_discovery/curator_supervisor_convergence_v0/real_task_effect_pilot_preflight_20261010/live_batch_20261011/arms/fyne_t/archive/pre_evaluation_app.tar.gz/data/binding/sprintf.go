package binding

import (
	"fmt"

	"fyne.io/fyne/v2/storage"
)

// NewSprintf creates a formatted string binding that combines multiple data sources.
// When any source binding changes, the formatted string is automatically updated.
// The format string follows fmt.Sprintf syntax.
//
// Since: 2.5
func NewSprintf(format string, bindings ...DataItem) String {
	result := &sprintfBinding{
		format:   format,
		bindings: bindings,
	}
	
	// Listen to all source bindings
	for _, b := range bindings {
		b.AddListener(result)
	}
	
	// Initial format
	result.updateValue()
	
	return result
}

type sprintfBinding struct {
	base
	format   string
	bindings []DataItem
	value    string
	err      error
}

func (s *sprintfBinding) Get() (string, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()
	
	return s.value, s.err
}

func (s *sprintfBinding) Set(str string) error {
	// Parse back using fmt.Sscanf
	values := make([]interface{}, len(s.bindings))
	for i := range s.bindings {
		switch s.bindings[i].(type) {
		case Bool:
			var v bool
			values[i] = &v
		case Int:
			var v int
			values[i] = &v
		case Float:
			var v float64
			values[i] = &v
		case String:
			var v string
			values[i] = &v
		case Rune:
			var v rune
			values[i] = &v
		case URI:
			var v string
			values[i] = &v
		default:
			return fmt.Errorf("unsupported binding type for parsing")
			return fmt.Errorf("unsupported binding type for parsing")
		}
	}
	
	n, err := fmt.Sscanf(str, s.format, values...)
	if err != nil {
		return err
	}
	if n != len(s.bindings) {
		return fmt.Errorf("parsed %d values, expected %d", n, len(s.bindings))
	}
	
	// Set each binding
	for i, b := range s.bindings {
		switch binding := b.(type) {
		case Bool:
			if err := binding.Set(*values[i].(*bool)); err != nil {
				return err
			}
		case Int:
			if err := binding.Set(*values[i].(*int)); err != nil {
				return err
			}
		case Float:
			if err := binding.Set(*values[i].(*float64)); err != nil {
				return err
			}
		case String:
			if err := binding.Set(*values[i].(*string)); err != nil {
				return err
			}
		case Rune:
			if err := binding.Set(*values[i].(*rune)); err != nil {
				return err
			}
		case URI:
			uri, err := storage.ParseURI(*values[i].(*string))
			if err != nil {
				return err
			}
			if err := binding.Set(uri); err != nil {
				return err
			}
		}
	}
	
	return nil
}

func (s *sprintfBinding) DataChanged() {
	s.updateValue()
	s.trigger()
}

func (s *sprintfBinding) updateValue() {
	s.lock.Lock()
	defer s.lock.Unlock()
	
	// Read all binding values
	values := make([]interface{}, len(s.bindings))
	for i, b := range s.bindings {
		var err error
		switch binding := b.(type) {
		case Bool:
			values[i], err = binding.Get()
		case Float:
			values[i], err = binding.Get()
		case Int:
			values[i], err = binding.Get()
		case Rune:
			values[i], err = binding.Get()
		case String:
			values[i], err = binding.Get()
		case URI:
			values[i], err = binding.Get()
		default:
			err = fmt.Errorf("unsupported binding type")
		}
		
		if err != nil {
			s.err = err
			return
		}
	}
	
	s.value = fmt.Sprintf(s.format, values...)
	s.err = nil
}

// StringToStringWithFormat wraps a String binding with a format.
// If the format is "%s" (identity), returns the original binding directly.
//
// Since: 2.5
func StringToStringWithFormat(str String, format string) String {
	if format == "%s" {
		return str
	}
	return NewSprintf(format, str)
}
