/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Package transport provides predefined transport protocol.
package transport

// Protocol indicates the transport protocol.
type Protocol int

// Predefined transport protocols.
const (
	PurePayload Protocol = 0

	TTHeader  Protocol = 1 << iota // 1
	Framed                         // 2
	HTTP                           // 4
	GRPC                           // 8
	HESSIAN2                       // 16
	STREAMING                      // 32

	TTHeaderFramed    = TTHeader | Framed // 3
	TTHeaderStreaming Protocol = 64       // Dedicated flag
	GRPCStreaming     Protocol = 128      // Dedicated flag
)

// Default returns the default protocol
func Default() Protocol {
	return Framed
}

// Unknown indicates the protocol is unknown.
const Unknown = "Unknown"

// String prints human readable information.
func (tp Protocol) String() string {
	switch tp {
	case PurePayload:
		return "PurePayload"
	case TTHeader:
		return "TTHeader"
	case Framed:
		return "Framed"
	case HTTP:
		return "HTTP"
	case TTHeaderFramed:
		return "TTHeaderFramed"
	case GRPC:
		return "GRPC"
	case HESSIAN2:
		return "Hessian2"
	case TTHeaderStreaming:
		return "TTHeaderStreaming"
	case GRPCStreaming:
		return "GRPCStreaming"
	}

	// Handle composite protocols by building pipe-separated names in ascending bit order
	if tp != 0 {
		var parts []string
		bitNames := []struct {
			bit  Protocol
			name string
		}{
			{TTHeader, "TTHeader"},
			{Framed, "Framed"},
			{HTTP, "HTTP"},
			{GRPC, "GRPC"},
			{HESSIAN2, "Hessian2"},
		}
		
		for _, bn := range bitNames {
			if tp&bn.bit == bn.bit && tp&bn.bit != 0 {
				parts = append(parts, bn.name)
			}
		}
		
		if len(parts) > 0 {
			result := parts[0]
			for i := 1; i < len(parts); i++ {
				result += "|" + parts[i]
			}
			return result
		}
	}

	return Unknown
}
