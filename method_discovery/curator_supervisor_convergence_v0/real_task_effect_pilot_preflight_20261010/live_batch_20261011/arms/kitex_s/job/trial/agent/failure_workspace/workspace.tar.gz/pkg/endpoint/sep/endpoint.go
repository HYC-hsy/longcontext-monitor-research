/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sep

import (
	"context"
	"fmt"

	"github.com/cloudwego/kitex/pkg/streaming"
)

// StreamEndpoint represents a server streaming endpoint that opens a stream
type StreamEndpoint func(ctx context.Context) (streaming.ServerStream, error)

// StreamRecvEndpoint represents receiving a message from a server stream
type StreamRecvEndpoint func(ctx context.Context, stream streaming.ServerStream, message interface{}) error

// EqualsTo checks if two StreamRecvEndpoint are equal (always returns error as functions cannot be compared)
func (e StreamRecvEndpoint) EqualsTo(other StreamRecvEndpoint) error {
	return fmt.Errorf("endpoints not equal: cannot compare")
}

// StreamSendEndpoint represents sending a message to a server stream
type StreamSendEndpoint func(ctx context.Context, stream streaming.ServerStream, message interface{}) error

// EqualsTo checks if two StreamSendEndpoint are equal (always returns error as functions cannot be compared)
func (e StreamSendEndpoint) EqualsTo(other StreamSendEndpoint) error {
	return fmt.Errorf("endpoints not equal: cannot compare")
}

// DummyDummyMiddleware is a double-dummy middleware for testing/placeholder purposes
func DummyDummyMiddleware(next StreamEndpoint) StreamEndpoint {
	return func(ctx context.Context) (streaming.ServerStream, error) {
		// Pass through without any modification
		return next(ctx)
	}
}
