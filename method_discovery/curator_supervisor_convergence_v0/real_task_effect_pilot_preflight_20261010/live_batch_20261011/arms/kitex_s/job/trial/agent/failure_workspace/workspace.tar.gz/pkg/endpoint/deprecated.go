/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package endpoint

import "context"

// DeprecatedEndpoint is a deprecated endpoint type
//
// Deprecated: Use UnaryEndpoint instead for unary calls, or streaming endpoints for streaming
func DeprecatedEndpoint(ctx context.Context, req, resp interface{}) error {
	return nil
}

// DeprecatedRecvEndpoint is a deprecated receive endpoint type
//
// Deprecated: Use cep.StreamRecvEndpoint or sep.StreamRecvEndpoint instead
type DeprecatedRecvEndpoint func(ctx context.Context, message interface{}) error

// DeprecatedSendEndpoint is a deprecated send endpoint type
//
// Deprecated: Use cep.StreamSendEndpoint or sep.StreamSendEndpoint instead
type DeprecatedSendEndpoint func(ctx context.Context, message interface{}) error
