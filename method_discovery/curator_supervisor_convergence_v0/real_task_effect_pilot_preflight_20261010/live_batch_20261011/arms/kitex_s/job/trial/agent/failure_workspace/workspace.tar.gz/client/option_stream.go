/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"fmt"
	"time"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/endpoint"
	"github.com/cloudwego/kitex/pkg/utils"
)

// WithStreamOptions wraps multiple StreamOptions into a single Option
func WithStreamOptions(opts ...StreamOption) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push("WithStreamOptions")
		for _, opt := range opts {
			opt.F(o, di)
		}
	}}
}

// WithStreamMiddleware adds middleware for streaming client calls
func WithStreamMiddleware(mw endpoint.Middleware) StreamOption {
	return StreamOption{
		Option: WithMiddleware(mw),
	}
}

// WithStreamTimeout sets the timeout for streaming RPC calls
func WithStreamTimeout(timeout time.Duration) StreamOption {
	return StreamOption{
		Option: WithRPCTimeout(timeout),
	}
}

// WithStreamRecvTimeout sets the receive timeout for streaming calls
func WithStreamRecvTimeout(timeout time.Duration) StreamOption {
	return StreamOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithStreamRecvTimeout(%v)", timeout))
			// Stream receive timeout would be configured through streaming config
		}},
	}
}

// WithStreamSendTimeout sets the send timeout for streaming calls
func WithStreamSendTimeout(timeout time.Duration) StreamOption {
	return StreamOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithStreamSendTimeout(%v)", timeout))
			// Stream send timeout would be configured through streaming config
		}},
	}
}

// WithStreamBufferSize sets the buffer size for streaming calls
func WithStreamBufferSize(size int) StreamOption {
	return StreamOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithStreamBufferSize(%d)", size))
			// Buffer size configuration would be applied through streaming config
		}},
	}
}

// WithStreamMaxConcurrency sets maximum concurrent streams
func WithStreamMaxConcurrency(max int) StreamOption {
	return StreamOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithStreamMaxConcurrency(%d)", max))
			// Max concurrency configuration would be applied through streaming config
		}},
	}
}

// WithStreamFlowControl enables flow control for streaming
func WithStreamFlowControl(enabled bool) StreamOption {
	return StreamOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithStreamFlowControl(%v)", enabled))
			// Flow control configuration would be applied through streaming config
		}},
	}
}
