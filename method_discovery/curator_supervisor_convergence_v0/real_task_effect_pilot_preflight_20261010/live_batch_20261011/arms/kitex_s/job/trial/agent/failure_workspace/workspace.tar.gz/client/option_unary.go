/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"fmt"
	"time"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/endpoint"
	"github.com/cloudwego/kitex/pkg/utils"
)

// WithUnaryOptions wraps multiple UnaryOptions into a single Option
func WithUnaryOptions(opts ...UnaryOption) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push("WithUnaryOptions")
		for _, opt := range opts {
			opt.F(o, di)
		}
	}}
}

// WithUnaryMiddleware adds middleware for unary client calls
func WithUnaryMiddleware(mw endpoint.UnaryMiddleware) UnaryOption {
	return UnaryOption{
		Option: WithMiddleware(mw.ToMiddleware()),
	}
}

// WithUnaryRPCTimeout sets the RPC timeout for unary calls
func WithUnaryRPCTimeout(timeout time.Duration) UnaryOption {
	return UnaryOption{
		Option: WithRPCTimeout(timeout),
	}
}

// WithUnaryConnTimeout sets the connection timeout for unary calls
func WithUnaryConnTimeout(timeout time.Duration) UnaryOption {
	return UnaryOption{
		Option: WithConnectTimeout(timeout),
	}
}

// WithUnaryRetry enables retry for unary calls
func WithUnaryRetry(maxRetries int) UnaryOption {
	return UnaryOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithUnaryRetry(%d)", maxRetries))
			// Retry policy would be configured through existing retry mechanisms
		}},
	}
}

// WithUnaryCircuitBreaker enables circuit breaker for unary calls
func WithUnaryCircuitBreaker(enabled bool) UnaryOption {
	return UnaryOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithUnaryCircuitBreaker(%v)", enabled))
			// Circuit breaker configuration through existing mechanisms
		}},
	}
}
