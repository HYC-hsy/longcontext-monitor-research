/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"fmt"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/utils"
	"github.com/cloudwego/kitex/transport"
)

// WithTTHeaderStreamingOptions wraps multiple TTHeaderStreamingOptions into a single Option
func WithTTHeaderStreamingOptions(opts ...TTHeaderStreamingOption) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push("WithTTHeaderStreamingOptions")
		for _, opt := range opts {
			opt.F(o, di)
		}
	}}
}

// WithTTHeaderStreamingProtocol sets the transport protocol to TTHeaderStreaming
func WithTTHeaderStreamingProtocol() TTHeaderStreamingOption {
	return TTHeaderStreamingOption{
		Option: WithTransportProtocol(transport.TTHeaderStreaming),
	}
}

// WithTTHeaderStreamingMaxFrameSize sets max frame size for TTHeader streaming
func WithTTHeaderStreamingMaxFrameSize(size int) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithTTHeaderStreamingMaxFrameSize(%d)", size))
			// Max frame size would be configured through transport options
		}},
	}
}

// WithTTHeaderStreamingCompression enables compression for TTHeader streaming
func WithTTHeaderStreamingCompression(enabled bool) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{
		Option: Option{F: func(o *client.Options, di *utils.Slice) {
			di.Push(fmt.Sprintf("WithTTHeaderStreamingCompression(%v)", enabled))
			// Compression would be configured through transport options
		}},
	}
}

// WithGRPCStreamingOptions wraps multiple GRPCStreamingOptions into a single Option
func WithGRPCStreamingOptions(opts ...GRPCStreamingOption) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		di.Push("WithGRPCStreamingOptions")
		for _, opt := range opts {
			opt.F(o, di)
		}
	}}
}

// WithGRPCStreamingProtocol sets the transport protocol to GRPC streaming
func WithGRPCStreamingProtocol() GRPCStreamingOption {
	return GRPCStreamingOption{
		Option: WithTransportProtocol(transport.GRPCStreaming),
	}
}
