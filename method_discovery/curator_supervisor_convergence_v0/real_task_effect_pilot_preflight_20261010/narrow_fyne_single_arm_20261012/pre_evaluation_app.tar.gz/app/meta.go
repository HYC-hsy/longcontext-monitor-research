package app

import (
	"sync"

	"fyne.io/fyne/v2"
)

var (
	appMetadata      fyne.AppMetadata
	appMetadataLock  sync.RWMutex
	metadataSet      bool
)

// SetMetadata allows an application to override its build metadata at runtime.
// This sets the global metadata that will be returned by any App's Metadata() method.
func SetMetadata(m fyne.AppMetadata) {
	appMetadataLock.Lock()
	defer appMetadataLock.Unlock()

	appMetadata = m
	metadataSet = true
}

func getMetadata() fyne.AppMetadata {
	appMetadataLock.RLock()
	defer appMetadataLock.RUnlock()

	if metadataSet {
		return appMetadata
	}

	// Return default metadata if none has been set
	return fyne.AppMetadata{
		ID:      "com.example",
		Name:    "Fyne App",
		Version: "1.0.0",
		Build:   1,
	}
}
