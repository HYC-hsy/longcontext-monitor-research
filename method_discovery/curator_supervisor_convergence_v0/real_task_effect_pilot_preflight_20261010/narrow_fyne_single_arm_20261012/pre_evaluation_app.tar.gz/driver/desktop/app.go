package desktop

import (
	"fyne.io/fyne/v2"
)

// App interface extends the standard fyne.App interface with desktop-specific capabilities.
// Desktop applications that want system tray support should implement this interface.
//
// Since: 2.5
type App interface {
	fyne.App

	// SetSystemTrayMenu sets the system tray menu for this application.
	// Pass nil to remove the system tray menu.
	SetSystemTrayMenu(menu *fyne.Menu)

	// SetSystemTrayIcon sets the system tray icon for this application.
	// Pass nil to remove the system tray icon.
	SetSystemTrayIcon(icon fyne.Resource)
}
