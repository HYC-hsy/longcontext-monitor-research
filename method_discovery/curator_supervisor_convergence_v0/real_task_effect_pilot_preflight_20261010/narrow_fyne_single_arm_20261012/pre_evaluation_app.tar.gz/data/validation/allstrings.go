package validation

import (
	"fyne.io/fyne/v2/data/binding"
)

// NewAllStrings creates a validator that runs the provided validator on all strings in a StringList binding.
// The returned validator will check each item in the list and return the first error encountered, or nil if all items are valid.
//
// Since: 2.5
func NewAllStrings(itemValidator func(string) error) func(binding.StringList) error {
	return func(list binding.StringList) error {
		items, err := list.Get()
		if err != nil {
			return err
		}

		for _, item := range items {
			if err := itemValidator(item); err != nil {
				return err
			}
		}

		return nil
	}
}
