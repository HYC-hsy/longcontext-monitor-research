package binding

import (
	"fmt"
	"sync"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/storage"
)

// NewSprintf creates a String binding that formats multiple DataItems using fmt.Sprintf.
// The format string follows fmt.Sprintf conventions. The binding updates automatically
// when any of the source DataItems change.
//
// Example:
//
//	name := binding.NewString()
//	age := binding.NewInt()
//	result := binding.NewSprintf("Name: %s, Age: %d", name, age)
//
// Since: 2.5
func NewSprintf(format string, b ...DataItem) String {
	if len(b) == 0 {
		// No bindings, just return static string
		s := NewString()
		s.Set(format)
		return s
	}

	result := &sprintfBinding{
		format:  format,
		sources: b,
		val:     "",
	}

	// Initialize with current values
	result.update()

	// Listen to all source bindings
	listener := NewDataListener(func() {
		result.update()
	})

	for _, item := range b {
		if item != nil {
			item.AddListener(listener)
		}
	}

	return result
}

// sprintfBinding combines multiple DataItems using fmt.Sprintf
type sprintfBinding struct {
	base

	format  string
	sources []DataItem
	val     string
	lock    sync.RWMutex
}

// Get returns the formatted string value
func (s *sprintfBinding) Get() (string, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	return s.val, nil
}

// Set parses the input string using fmt.Sscanf and sets each source binding
func (s *sprintfBinding) Set(str string) error {
	if len(s.sources) == 0 {
		return fmt.Errorf("no source bindings to set")
	}

	// Create pointers to hold parsed values
	args := make([]interface{}, len(s.sources))
	
	for i, item := range s.sources {
		if item == nil {
			return fmt.Errorf("source binding %d is nil", i)
		}

		// Create appropriate type for Sscanf based on binding type
		switch item.(type) {
		case String:
			var strVal string
			args[i] = &strVal
		case Int:
			var intVal int
			args[i] = &intVal
		case Float:
			var floatVal float64
			args[i] = &floatVal
		case Bool:
			var boolVal bool
			args[i] = &boolVal
		case URI:
			var uriVal string
			args[i] = &uriVal
		default:
			// For Untyped or unknown types, use interface{}
			var val interface{}
			args[i] = &val
		}
	}

	// Parse the string using fmt.Sscanf
	n, err := fmt.Sscanf(str, s.format, args...)
	if err != nil {
		return fmt.Errorf("failed to parse string: %w", err)
	}
	if n != len(s.sources) {
		return fmt.Errorf("expected %d values, parsed %d", len(s.sources), n)
	}

	// Set each source binding with the parsed value
	for i, item := range s.sources {
		switch v := item.(type) {
		case String:
			strVal := *(args[i].(*string))
			if err := v.Set(strVal); err != nil {
				return fmt.Errorf("failed to set string binding %d: %w", i, err)
			}
		case Int:
			intVal := *(args[i].(*int))
			if err := v.Set(intVal); err != nil {
				return fmt.Errorf("failed to set int binding %d: %w", i, err)
			}
		case Float:
			floatVal := *(args[i].(*float64))
			if err := v.Set(floatVal); err != nil {
				return fmt.Errorf("failed to set float binding %d: %w", i, err)
			}
		case Bool:
			boolVal := *(args[i].(*bool))
			if err := v.Set(boolVal); err != nil {
				return fmt.Errorf("failed to set bool binding %d: %w", i, err)
			}
		case URI:
			// Special case: parse URI using storage.ParseURI
			uriStr := *(args[i].(*string))
			uri, err := parseURIString(uriStr)
			if err != nil {
				return fmt.Errorf("failed to parse URI %d: %w", i, err)
			}
			if err := v.Set(uri); err != nil {
				return fmt.Errorf("failed to set URI binding %d: %w", i, err)
			}
		case Untyped:
			val := *(args[i].(*interface{}))
			if err := v.Set(val); err != nil {
				return fmt.Errorf("failed to set untyped binding %d: %w", i, err)
			}
		}
	}

	return nil
}

// parseURIString is a helper to parse URI strings using storage.ParseURI
func parseURIString(uriStr string) (fyne.URI, error) {
	// Import is at package level: "fyne.io/fyne/v2/storage"
	uri, err := storage.ParseURI(uriStr)
	if err != nil {
		return nil, err
	}
	return uri, nil
}

// update recalculates the formatted string from source bindings
func (s *sprintfBinding) update() {
	values := make([]interface{}, len(s.sources))

	for i, item := range s.sources {
		if item == nil {
			values[i] = nil
			continue
		}

		// Extract the actual value from the DataItem
		switch v := item.(type) {
		case String:
			if val, err := v.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = ""
			}
		case Int:
			if val, err := v.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = 0
			}
		case Float:
			if val, err := v.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = 0.0
			}
		case Bool:
			if val, err := v.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = false
			}
		case Untyped:
			if val, err := v.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = nil
			}
		default:
			// For any other type, try to get as Untyped
			if untyped, ok := item.(Untyped); ok {
				if val, err := untyped.Get(); err == nil {
					values[i] = val
				} else {
					values[i] = nil
				}
			} else {
				values[i] = nil
			}
		}
	}

	newVal := fmt.Sprintf(s.format, values...)

	s.lock.Lock()
	changed := s.val != newVal
	s.val = newVal
	s.lock.Unlock()

	if changed {
		s.trigger()
	}
}

// StringToStringWithFormat creates a String binding that formats another String binding.
// The format string should contain a single %s placeholder for the source string value.
// Changes to the source String binding automatically update the formatted result.
//
// Example:
//
//	username := binding.NewString()
//	formatted := binding.StringToStringWithFormat(username, "User: %s")
//
// Since: 2.5
func StringToStringWithFormat(str String, format string) String {
	if str == nil {
		return NewString()
	}

	result := &stringFormatBinding{
		format: format,
		source: str,
		val:    "",
	}

	// Initialize with current value
	result.update()

	// Listen for changes
	str.AddListener(NewDataListener(func() {
		result.update()
	}))

	return result
}

// stringFormatBinding formats a String binding
type stringFormatBinding struct {
	base

	format string
	source String
	val    string
	lock   sync.RWMutex
}

// Get returns the formatted string value
func (s *stringFormatBinding) Get() (string, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	return s.val, nil
}

// Set is not supported for format bindings (read-only)
func (s *stringFormatBinding) Set(string) error {
	return fmt.Errorf("cannot set value on format binding")
}

// update recalculates the formatted string
func (s *stringFormatBinding) update() {
	val, err := s.source.Get()
	if err != nil {
		val = ""
	}

	newVal := fmt.Sprintf(s.format, val)

	s.lock.Lock()
	changed := s.val != newVal
	s.val = newVal
	s.lock.Unlock()

	if changed {
		s.trigger()
	}
}
