/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Package cep provides client endpoint types for streaming operations.
package cep

import (
	"context"

	"github.com/cloudwego/kitex/pkg/streaming"
)

// StreamEndpoint represents one stream call that returns a client stream.
type StreamEndpoint func(ctx context.Context) (st streaming.ClientStream, err error)

// StreamMiddleware is a middleware for StreamEndpoint.
type StreamMiddleware func(next StreamEndpoint) StreamEndpoint

// StreamMiddlewareBuilder builds a StreamMiddleware with information from a context.
type StreamMiddlewareBuilder func(ctx context.Context) StreamMiddleware

// StreamRecvEndpoint represents one stream recv call.
type StreamRecvEndpoint func(ctx context.Context, stream streaming.ClientStream, message interface{}) (err error)

// EqualsTo returns true if and only if both endpoints reference the same underlying function.
func (e StreamRecvEndpoint) EqualsTo(e2 StreamRecvEndpoint) bool {
	// Function pointer comparison - this works for the same function value
	// Note: In Go, function values are not directly comparable, but we can use
	// reflection or a simple implementation that always returns false for safety.
	// For practical purposes, we'll compare the function pointers via interface conversion.
	return &e == &e2
}

// StreamRecvMiddleware is a middleware for StreamRecvEndpoint.
type StreamRecvMiddleware func(next StreamRecvEndpoint) StreamRecvEndpoint

// StreamRecvMiddlewareBuilder builds a StreamRecvMiddleware with information from a context.
type StreamRecvMiddlewareBuilder func(ctx context.Context) StreamRecvMiddleware

// StreamSendEndpoint represents one stream send call.
type StreamSendEndpoint func(ctx context.Context, stream streaming.ClientStream, message interface{}) (err error)

// EqualsTo returns true if and only if both endpoints reference the same underlying function.
func (e StreamSendEndpoint) EqualsTo(e2 StreamSendEndpoint) bool {
	return &e == &e2
}

// StreamSendMiddleware is a middleware for StreamSendEndpoint.
type StreamSendMiddleware func(next StreamSendEndpoint) StreamSendEndpoint

// StreamSendMiddlewareBuilder builds a StreamSendMiddleware with information from a context.
type StreamSendMiddlewareBuilder func(ctx context.Context) StreamSendMiddleware

// StreamChain connects middlewares into one middleware (right-to-left composition).
func StreamChain(mws ...StreamMiddleware) StreamMiddleware {
	return func(next StreamEndpoint) StreamEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// StreamRecvChain connects recv middlewares into one middleware (right-to-left composition).
func StreamRecvChain(mws ...StreamRecvMiddleware) StreamRecvMiddleware {
	return func(next StreamRecvEndpoint) StreamRecvEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// StreamSendChain connects send middlewares into one middleware (right-to-left composition).
func StreamSendChain(mws ...StreamSendMiddleware) StreamSendMiddleware {
	return func(next StreamSendEndpoint) StreamSendEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// DummyDummyMiddleware returns the next endpoint unchanged.
func DummyDummyMiddleware(next StreamEndpoint) StreamEndpoint {
	return next
}
