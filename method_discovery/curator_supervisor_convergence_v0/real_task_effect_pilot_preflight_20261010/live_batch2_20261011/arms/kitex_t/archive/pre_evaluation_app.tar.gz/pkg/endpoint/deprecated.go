/*
 * Copyright 2023 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package endpoint

import "context"

// Deprecated: Use pkg/endpoint/cep.StreamRecvEndpoint or pkg/endpoint/sep.StreamRecvEndpoint instead.
// RecvEndpoint is a legacy streaming receive endpoint type.
type RecvEndpoint func(ctx context.Context, req interface{}, recvr interface{}) (err error)

// Deprecated: Use pkg/endpoint/cep.StreamRecvMiddleware or pkg/endpoint/sep.StreamRecvMiddleware instead.
// RecvMiddleware is a legacy middleware for RecvEndpoint.
type RecvMiddleware func(next RecvEndpoint) RecvEndpoint

// Deprecated: Use pkg/endpoint/cep.StreamRecvMiddlewareBuilder or pkg/endpoint/sep.StreamRecvMiddlewareBuilder instead.
// RecvMiddlewareBuilder builds a RecvMiddleware with information from a context.
type RecvMiddlewareBuilder func(ctx context.Context) RecvMiddleware

// Deprecated: Use pkg/endpoint/cep.StreamRecvChain or pkg/endpoint/sep.StreamRecvChain instead.
// RecvChain connect middlewares into one middleware.
func RecvChain(mws ...RecvMiddleware) RecvMiddleware {
	return func(next RecvEndpoint) RecvEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// Deprecated: Use pkg/endpoint/cep.StreamSendEndpoint or pkg/endpoint/sep.StreamSendEndpoint instead.
// SendEndpoint is a legacy streaming send endpoint type.
type SendEndpoint func(ctx context.Context, sender interface{}) (err error)

// Deprecated: Use pkg/endpoint/cep.StreamSendMiddleware or pkg/endpoint/sep.StreamSendMiddleware instead.
// SendMiddleware is a middleware for SendEndpoint.
type SendMiddleware func(next SendEndpoint) SendEndpoint

// Deprecated: Use pkg/endpoint/cep.StreamSendMiddlewareBuilder or pkg/endpoint/sep.StreamSendMiddlewareBuilder instead.
// SendMiddlewareBuilder builds a middleware with information from a context.
type SendMiddlewareBuilder func(ctx context.Context) SendMiddleware

// Deprecated: Use pkg/endpoint/cep.StreamSendChain or pkg/endpoint/sep.StreamSendChain instead.
// SendChain connect middlewares into one middleware.
func SendChain(mws ...SendMiddleware) SendMiddleware {
	return func(next SendEndpoint) SendEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}
