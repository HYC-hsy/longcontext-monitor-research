/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"fmt"
	"time"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/endpoint"
	"github.com/cloudwego/kitex/pkg/rpcinfo"
	"github.com/cloudwego/kitex/pkg/utils"
)

// WithUnaryRPCTimeout sets RPC timeout for unary calls.
func WithUnaryRPCTimeout(d time.Duration) UnaryOption {
	return UnaryOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				di.Push(fmt.Sprintf("WithUnaryRPCTimeout(%dms)", d.Milliseconds()))
				rpcinfo.AsMutableRPCConfig(o.Configs).SetRPCTimeout(d)
				o.Locks.Bits |= rpcinfo.BitRPCTimeout
			},
		},
	}
}

// WithUnaryMiddleware adds a unary middleware to the client.
func WithUnaryMiddleware(mw endpoint.UnaryMiddleware) UnaryOption {
	return UnaryOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.UnaryOptions.UnaryMiddlewares == nil {
					o.UnaryOptions.UnaryMiddlewares = make([]endpoint.UnaryMiddleware, 0, 4)
				}
				o.UnaryOptions.UnaryMiddlewares = append(o.UnaryOptions.UnaryMiddlewares, mw)
			},
		},
	}
}

// WithUnaryMiddlewareBuilder adds a unary middleware builder to the client.
func WithUnaryMiddlewareBuilder(mwb endpoint.UnaryMiddlewareBuilder) UnaryOption {
	return UnaryOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.UnaryOptions.UnaryMiddlewareBuilders == nil {
					o.UnaryOptions.UnaryMiddlewareBuilders = make([]endpoint.UnaryMiddlewareBuilder, 0, 4)
				}
				o.UnaryOptions.UnaryMiddlewareBuilders = append(o.UnaryOptions.UnaryMiddlewareBuilders, mwb)
			},
		},
	}
}
