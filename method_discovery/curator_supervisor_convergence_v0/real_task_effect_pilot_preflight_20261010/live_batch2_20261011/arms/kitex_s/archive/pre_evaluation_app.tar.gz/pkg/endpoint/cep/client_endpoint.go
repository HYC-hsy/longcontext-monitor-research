/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cep

import (
	"context"

	"github.com/cloudwego/kitex/pkg/endpoint"
)

// UnaryChain connects multiple unary middlewares into a single middleware.
func UnaryChain(mws ...endpoint.UnaryMiddleware) endpoint.UnaryMiddleware {
	return func(next endpoint.UnaryEndpoint) endpoint.UnaryEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// FromGenericEndpoint converts a generic endpoint.Endpoint to UnaryEndpoint.
func FromGenericEndpoint(ep endpoint.Endpoint) endpoint.UnaryEndpoint {
	return func(ctx context.Context, req, resp interface{}) error {
		return ep(ctx, req, resp)
	}
}

// ToGenericEndpoint converts a UnaryEndpoint to generic endpoint.Endpoint.
func ToGenericEndpoint(ep endpoint.UnaryEndpoint) endpoint.Endpoint {
	return func(ctx context.Context, req, resp interface{}) error {
		return ep(ctx, req, resp)
	}
}

// StreamEndpoint is a function type for client-side streaming RPC endpoints.
// It handles the streaming communication with the server.
type StreamEndpoint func(ctx context.Context, args interface{}) (result interface{}, err error)

// StreamMiddleware is a function type for client-side streaming middleware.
type StreamMiddleware func(next StreamEndpoint) StreamEndpoint

// StreamMiddlewareBuilder builds a StreamMiddleware with information from a context.
type StreamMiddlewareBuilder func(ctx context.Context) StreamMiddleware

// StreamChain connects multiple streaming middlewares into a single middleware.
func StreamChain(mws ...StreamMiddleware) StreamMiddleware {
	return func(next StreamEndpoint) StreamEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}
