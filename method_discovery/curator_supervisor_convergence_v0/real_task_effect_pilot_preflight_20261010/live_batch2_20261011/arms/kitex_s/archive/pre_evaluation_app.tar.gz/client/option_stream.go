/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"time"

	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/endpoint"
	"github.com/cloudwego/kitex/pkg/endpoint/cep"
	"github.com/cloudwego/kitex/pkg/utils"
)

// WithStreamRecvTimeout sets receive timeout for streaming calls.
func WithStreamRecvTimeout(d time.Duration) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				o.StreamOptions.RecvTimeout = d
			},
		},
	}
}

// WithStreamSendTimeout sets send timeout for streaming calls.
func WithStreamSendTimeout(d time.Duration) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				o.StreamOptions.SendTimeout = d
			},
		},
	}
}

// WithStreamMiddleware adds a streaming middleware to the client.
func WithStreamMiddleware(mw cep.StreamMiddleware) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.StreamOptions.StreamMiddlewares == nil {
					o.StreamOptions.StreamMiddlewares = make([]cep.StreamMiddleware, 0, 4)
				}
				o.StreamOptions.StreamMiddlewares = append(o.StreamOptions.StreamMiddlewares, mw)
			},
		},
	}
}

// WithStreamMiddlewareBuilder adds a streaming middleware builder to the client.
func WithStreamMiddlewareBuilder(mwb cep.StreamMiddlewareBuilder) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.StreamOptions.StreamMiddlewareBuilders == nil {
					o.StreamOptions.StreamMiddlewareBuilders = make([]cep.StreamMiddlewareBuilder, 0, 4)
				}
				o.StreamOptions.StreamMiddlewareBuilders = append(o.StreamOptions.StreamMiddlewareBuilders, mwb)
			},
		},
	}
}

// WithStreamRecvMiddleware adds a streaming receive middleware to the client.
func WithStreamRecvMiddleware(mw endpoint.RecvMiddleware) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.StreamOptions.RecvMiddlewares == nil {
					o.StreamOptions.RecvMiddlewares = make([]endpoint.RecvMiddleware, 0, 4)
				}
				o.StreamOptions.RecvMiddlewares = append(o.StreamOptions.RecvMiddlewares, mw)
			},
		},
	}
}

// WithStreamRecvMiddlewareBuilder adds a streaming receive middleware builder to the client.
func WithStreamRecvMiddlewareBuilder(mwb endpoint.RecvMiddlewareBuilder) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.StreamOptions.RecvMiddlewareBuilders == nil {
					o.StreamOptions.RecvMiddlewareBuilders = make([]endpoint.RecvMiddlewareBuilder, 0, 4)
				}
				o.StreamOptions.RecvMiddlewareBuilders = append(o.StreamOptions.RecvMiddlewareBuilders, mwb)
			},
		},
	}
}

// WithStreamSendMiddleware adds a streaming send middleware to the client.
func WithStreamSendMiddleware(mw endpoint.SendMiddleware) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.StreamOptions.SendMiddlewares == nil {
					o.StreamOptions.SendMiddlewares = make([]endpoint.SendMiddleware, 0, 4)
				}
				o.StreamOptions.SendMiddlewares = append(o.StreamOptions.SendMiddlewares, mw)
			},
		},
	}
}

// WithStreamSendMiddlewareBuilder adds a streaming send middleware builder to the client.
func WithStreamSendMiddlewareBuilder(mwb endpoint.SendMiddlewareBuilder) StreamOption {
	return StreamOption{
		Option: Option{
			F: func(o *client.Options, di *utils.Slice) {
				if o.StreamOptions.SendMiddlewareBuilders == nil {
					o.StreamOptions.SendMiddlewareBuilders = make([]endpoint.SendMiddlewareBuilder, 0, 4)
				}
				o.StreamOptions.SendMiddlewareBuilders = append(o.StreamOptions.SendMiddlewareBuilders, mwb)
			},
		},
	}
}
