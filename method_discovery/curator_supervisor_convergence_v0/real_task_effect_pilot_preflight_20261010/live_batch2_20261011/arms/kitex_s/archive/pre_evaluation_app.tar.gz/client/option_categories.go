/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package client

import (
	"github.com/cloudwego/kitex/internal/client"
	"github.com/cloudwego/kitex/pkg/utils"
)

// UnaryOption is a client option specifically for unary RPC calls.
// It wraps the standard Option type to provide type-safe option categorization.
type UnaryOption struct {
	Option
}

// StreamOption is a client option specifically for streaming RPC calls.
// It wraps the standard Option type to provide type-safe option categorization.
type StreamOption struct {
	Option
}

// TTHeaderStreamingOption is a client option specifically for TTHeader-based streaming.
// It wraps the standard Option type to provide type-safe option categorization.
type TTHeaderStreamingOption struct {
	Option
}

// AsUnaryOption converts a standard Option to a UnaryOption.
// This function is used to explicitly mark an option as suitable for unary RPC calls.
//
// Example:
//   opt := AsUnaryOption(WithTimeout(time.Second))
func AsUnaryOption(opt Option) UnaryOption {
	return UnaryOption{Option: opt}
}

// AsStreamOption converts a standard Option to a StreamOption.
// This function is used to explicitly mark an option as suitable for streaming RPC calls.
//
// Example:
//   opt := AsStreamOption(WithStreamMiddleware(myMiddleware))
func AsStreamOption(opt Option) StreamOption {
	return StreamOption{Option: opt}
}

// AsTTHeaderStreamingOption converts a standard Option to a TTHeaderStreamingOption.
// This function is used to explicitly mark an option as suitable for TTHeader streaming.
//
// Example:
//   opt := AsTTHeaderStreamingOption(WithTTHeaderFrame())
func AsTTHeaderStreamingOption(opt Option) TTHeaderStreamingOption {
	return TTHeaderStreamingOption{Option: opt}
}

// ToOption extracts the underlying Option from a UnaryOption.
func (u UnaryOption) ToOption() Option {
	return u.Option
}

// ToOption extracts the underlying Option from a StreamOption.
func (s StreamOption) ToOption() Option {
	return s.Option
}

// ToOption extracts the underlying Option from a TTHeaderStreamingOption.
func (t TTHeaderStreamingOption) ToOption() Option {
	return t.Option
}

// UnaryOptions is a collection of UnaryOption values.
// It provides a convenient way to group multiple unary-specific options.
type UnaryOptions []UnaryOption

// ToOptions converts a UnaryOptions collection to a slice of standard Options.
func (opts UnaryOptions) ToOptions() []Option {
	result := make([]Option, len(opts))
	for i, opt := range opts {
		result[i] = opt.Option
	}
	return result
}

// StreamOptions is a collection of StreamOption values.
// It provides a convenient way to group multiple streaming-specific options.
type StreamOptions []StreamOption

// ToOptions converts a StreamOptions collection to a slice of standard Options.
func (opts StreamOptions) ToOptions() []Option {
	result := make([]Option, len(opts))
	for i, opt := range opts {
		result[i] = opt.Option
	}
	return result
}

// TTHeaderStreamingOptions is a collection of TTHeaderStreamingOption values.
// It provides a convenient way to group multiple TTHeader streaming-specific options.
type TTHeaderStreamingOptions []TTHeaderStreamingOption

// ToOptions converts a TTHeaderStreamingOptions collection to a slice of standard Options.
func (opts TTHeaderStreamingOptions) ToOptions() []Option {
	result := make([]Option, len(opts))
	for i, opt := range opts {
		result[i] = opt.Option
	}
	return result
}

// WithUnaryOptions creates a standard Option that applies multiple UnaryOptions.
// This allows unary-specific options to be passed where standard Options are expected.
func WithUnaryOptions(opts ...UnaryOption) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		for _, opt := range opts {
			opt.Option.F(o, di)
		}
	}}
}

// WithStreamOptions creates a standard Option that applies multiple StreamOptions.
// This allows streaming-specific options to be passed where standard Options are expected.
func WithStreamOptions(opts ...StreamOption) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		for _, opt := range opts {
			opt.Option.F(o, di)
		}
	}}
}

// WithTTHeaderStreamingOptions creates a standard Option that applies multiple TTHeaderStreamingOptions.
// This allows TTHeader streaming-specific options to be passed where standard Options are expected.
func WithTTHeaderStreamingOptions(opts ...TTHeaderStreamingOption) Option {
	return Option{F: func(o *client.Options, di *utils.Slice) {
		for _, opt := range opts {
			opt.Option.F(o, di)
		}
	}}
}
