/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sep

import (
	"context"

	"github.com/cloudwego/kitex/pkg/endpoint"
)

// UnaryEndpoint is a function type for server-side unary RPC endpoints.
// It processes a unary request-response pair.
type UnaryEndpoint func(ctx context.Context, req, resp interface{}) error

// UnaryMiddleware is a function type for server-side unary middleware.
// It wraps a UnaryEndpoint to add cross-cutting concerns.
type UnaryMiddleware func(next UnaryEndpoint) UnaryEndpoint

// UnaryMiddlewareBuilder builds a UnaryMiddleware with information from a context.
type UnaryMiddlewareBuilder func(ctx context.Context) UnaryMiddleware

// UnaryChain connects multiple unary middlewares into a single middleware.
func UnaryChain(mws ...UnaryMiddleware) UnaryMiddleware {
	return func(next UnaryEndpoint) UnaryEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}

// FromGenericEndpoint converts a generic endpoint.Endpoint to UnaryEndpoint.
func FromGenericEndpoint(ep endpoint.Endpoint) UnaryEndpoint {
	return func(ctx context.Context, req, resp interface{}) error {
		return ep(ctx, req, resp)
	}
}

// ToGenericEndpoint converts a UnaryEndpoint to generic endpoint.Endpoint.
func ToGenericEndpoint(ep UnaryEndpoint) endpoint.Endpoint {
	return func(ctx context.Context, req, resp interface{}) error {
		return ep(ctx, req, resp)
	}
}

// StreamingEndpoint is a function type for server-side streaming RPC endpoints.
// It handles the streaming communication with the client.
type StreamingEndpoint func(ctx context.Context, stream interface{}) error

// StreamingMiddleware is a function type for server-side streaming middleware.
type StreamingMiddleware func(next StreamingEndpoint) StreamingEndpoint

// StreamingMiddlewareBuilder builds a StreamingMiddleware with information from a context.
type StreamingMiddlewareBuilder func(ctx context.Context) StreamingMiddleware

// StreamingChain connects multiple streaming middlewares into a single middleware.
func StreamingChain(mws ...StreamingMiddleware) StreamingMiddleware {
	return func(next StreamingEndpoint) StreamingEndpoint {
		for i := len(mws) - 1; i >= 0; i-- {
			next = mws[i](next)
		}
		return next
	}
}
