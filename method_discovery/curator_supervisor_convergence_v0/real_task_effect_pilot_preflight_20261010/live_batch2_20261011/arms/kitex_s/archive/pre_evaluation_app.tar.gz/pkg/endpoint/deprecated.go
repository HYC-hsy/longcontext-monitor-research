/*
 * Copyright 2023 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package endpoint

import (
	"github.com/cloudwego/kitex/pkg/streaming"
)

// Deprecated: RecvEndpoint is deprecated and will be removed in a future version.
// Use streaming-specific endpoint types instead.
// RecvEndpoint represent one Recv call
type RecvEndpoint func(stream streaming.Stream, message interface{}) (err error)

// Deprecated: RecvMiddleware is deprecated and will be removed in a future version.
// Use streaming-specific middleware types instead.
// RecvMiddleware deal with input Endpoint and output Endpoint.
type RecvMiddleware func(next RecvEndpoint) RecvEndpoint

// Deprecated: SendEndpoint is deprecated and will be removed in a future version.
// Use streaming-specific endpoint types instead.
// SendEndpoint represent one Send call
type SendEndpoint func(stream streaming.Stream, message interface{}) (err error)

// Deprecated: SendMiddleware is deprecated and will be removed in a future version.
// Use streaming-specific middleware types instead.
// SendMiddleware deal with input Endpoint and output Endpoint.
type SendMiddleware func(next SendEndpoint) SendEndpoint
