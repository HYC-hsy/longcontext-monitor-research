/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming

import (
	"context"

	"github.com/cloudwego/kitex/pkg/stats"
)

// Header represents RPC metadata headers.
type Header map[string]string

// Trailer represents RPC metadata trailers.
type Trailer map[string]string

// ClientStream is the base interface for client-side streaming operations.
// It provides methods for sending and receiving messages, accessing metadata,
// and managing the stream lifecycle.
type ClientStream interface {
	// SendMsg sends a message to the peer.
	SendMsg(ctx context.Context, m any) error
	// RecvMsg receives a message from the peer.
	RecvMsg(ctx context.Context, m any) error
	// Header returns header metadata from the server.
	Header() (Header, error)
	// Trailer returns trailer metadata from the server.
	Trailer() (Trailer, error)
	// CloseSend closes the send direction.
	CloseSend(ctx context.Context) error
	// Context returns the stream's context.
	Context() context.Context
}

// ServerStream is the base interface for server-side streaming operations.
// It provides methods for sending and receiving messages and managing metadata.
type ServerStream interface {
	// SendMsg sends a message to the peer.
	SendMsg(ctx context.Context, m any) error
	// RecvMsg receives a message from the peer.
	RecvMsg(ctx context.Context, m any) error
	// SetHeader sets header metadata (may be called multiple times; merged).
	SetHeader(hd Header) error
	// SendHeader sends header metadata (fails if called after first response).
	SendHeader(hd Header) error
	// SetTrailer sets trailer metadata (merged when called multiple times).
	SetTrailer(hd Trailer) error
}

// ServerStreamingClient is a generic interface for server-streaming client operations.
type ServerStreamingClient[Res any] interface {
	ClientStream
	// Recv receives a response message.
	Recv(ctx context.Context) (*Res, error)
}

// serverStreamingClient is the implementation of ServerStreamingClient.
type serverStreamingClient[Res any] struct {
	ClientStream
}

// NewServerStreamingClient creates a typed server-streaming client.
func NewServerStreamingClient[Res any](st ClientStream) ServerStreamingClient[Res] {
	return &serverStreamingClient[Res]{ClientStream: st}
}

func (s *serverStreamingClient[Res]) Recv(ctx context.Context) (*Res, error) {
	m := new(Res)
	if err := s.ClientStream.RecvMsg(ctx, m); err != nil {
		return nil, err
	}
	return m, nil
}

// ServerStreamingServer is a generic interface for server-streaming server operations.
type ServerStreamingServer[Res any] interface {
	ServerStream
	// Send sends a response message.
	Send(ctx context.Context, res *Res) error
}

// serverStreamingServer is the implementation of ServerStreamingServer.
type serverStreamingServer[Res any] struct {
	ServerStream
}

// NewServerStreamingServer creates a typed server-streaming server.
func NewServerStreamingServer[Res any](st ServerStream) ServerStreamingServer[Res] {
	return &serverStreamingServer[Res]{ServerStream: st}
}

func (s *serverStreamingServer[Res]) Send(ctx context.Context, res *Res) error {
	return s.ServerStream.SendMsg(ctx, res)
}

// ClientStreamingClient is a generic interface for client-streaming client operations.
type ClientStreamingClient[Req, Res any] interface {
	ClientStream
	// Send sends a request message.
	Send(ctx context.Context, req *Req) error
	// CloseAndRecv closes the send direction and receives the response.
	CloseAndRecv(ctx context.Context) (*Res, error)
}

// clientStreamingClient is the implementation of ClientStreamingClient.
type clientStreamingClient[Req, Res any] struct {
	ClientStream
}

// NewClientStreamingClient creates a typed client-streaming client.
func NewClientStreamingClient[Req, Res any](st ClientStream) ClientStreamingClient[Req, Res] {
	return &clientStreamingClient[Req, Res]{ClientStream: st}
}

func (c *clientStreamingClient[Req, Res]) Send(ctx context.Context, req *Req) error {
	return c.ClientStream.SendMsg(ctx, req)
}

func (c *clientStreamingClient[Req, Res]) CloseAndRecv(ctx context.Context) (*Res, error) {
	if err := c.ClientStream.CloseSend(ctx); err != nil {
		return nil, err
	}
	m := new(Res)
	if err := c.ClientStream.RecvMsg(ctx, m); err != nil {
		return nil, err
	}
	return m, nil
}

// ClientStreamingServer is a generic interface for client-streaming server operations.
type ClientStreamingServer[Req, Res any] interface {
	ServerStream
	// Recv receives a request message.
	Recv(ctx context.Context) (*Req, error)
	// SendAndClose sends the response and closes the stream.
	SendAndClose(ctx context.Context, res *Res) error
}

// clientStreamingServer is the implementation of ClientStreamingServer.
type clientStreamingServer[Req, Res any] struct {
	ServerStream
}

// NewClientStreamingServer creates a typed client-streaming server.
func NewClientStreamingServer[Req, Res any](st ServerStream) ClientStreamingServer[Req, Res] {
	return &clientStreamingServer[Req, Res]{ServerStream: st}
}

func (c *clientStreamingServer[Req, Res]) Recv(ctx context.Context) (*Req, error) {
	m := new(Req)
	if err := c.ServerStream.RecvMsg(ctx, m); err != nil {
		return nil, err
	}
	return m, nil
}

func (c *clientStreamingServer[Req, Res]) SendAndClose(ctx context.Context, res *Res) error {
	return c.ServerStream.SendMsg(ctx, res)
}

// BidiStreamingClient is a generic interface for bidirectional streaming client operations.
type BidiStreamingClient[Req, Res any] interface {
	ClientStream
	// Send sends a request message.
	Send(ctx context.Context, req *Req) error
	// Recv receives a response message.
	Recv(ctx context.Context) (*Res, error)
}

// bidiStreamingClient is the implementation of BidiStreamingClient.
type bidiStreamingClient[Req, Res any] struct {
	ClientStream
}

// NewBidiStreamingClient creates a typed bidirectional streaming client.
func NewBidiStreamingClient[Req, Res any](st ClientStream) BidiStreamingClient[Req, Res] {
	return &bidiStreamingClient[Req, Res]{ClientStream: st}
}

func (b *bidiStreamingClient[Req, Res]) Send(ctx context.Context, req *Req) error {
	return b.ClientStream.SendMsg(ctx, req)
}

func (b *bidiStreamingClient[Req, Res]) Recv(ctx context.Context) (*Res, error) {
	m := new(Res)
	if err := b.ClientStream.RecvMsg(ctx, m); err != nil {
		return nil, err
	}
	return m, nil
}

// BidiStreamingServer is a generic interface for bidirectional streaming server operations.
type BidiStreamingServer[Req, Res any] interface {
	ServerStream
	// Recv receives a request message.
	Recv(ctx context.Context) (*Req, error)
	// Send sends a response message.
	Send(ctx context.Context, res *Res) error
}

// bidiStreamingServer is the implementation of BidiStreamingServer.
type bidiStreamingServer[Req, Res any] struct {
	ServerStream
}

// NewBidiStreamingServer creates a typed bidirectional streaming server.
func NewBidiStreamingServer[Req, Res any](st ServerStream) BidiStreamingServer[Req, Res] {
	return &bidiStreamingServer[Req, Res]{ServerStream: st}
}

func (b *bidiStreamingServer[Req, Res]) Recv(ctx context.Context) (*Req, error) {
	m := new(Req)
	if err := b.ServerStream.RecvMsg(ctx, m); err != nil {
		return nil, err
	}
	return m, nil
}

func (b *bidiStreamingServer[Req, Res]) Send(ctx context.Context, res *Res) error {
	return b.ServerStream.SendMsg(ctx, res)
}

// CloseCallbackRegister allows registering a callback to be invoked when the stream closes.
type CloseCallbackRegister interface {
	// RegisterCloseCallback registers a callback that will be invoked when the stream closes.
	RegisterCloseCallback(cb func(error))
}

// GRPCStreamGetter provides access to the underlying gRPC stream (deprecated interface).
type GRPCStreamGetter interface {
	// GetGRPCStream returns the underlying Stream interface.
	GetGRPCStream() Stream
}

// EventHandler is a function that handles stream events.
type EventHandler func(ctx context.Context, evt stats.Event, err error)
