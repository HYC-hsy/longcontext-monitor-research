/*
 * Copyright 2021 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Package transport provides predefined transport protocol.
package transport

import "strings"

// Protocol indicates the transport protocol.
type Protocol int

// Predefined transport protocols.
const (
	PurePayload Protocol = 0

	TTHeader Protocol = 1 << iota // 1 << 0 = 1
	Framed                        // 1 << 1 = 2
	HTTP                          // 1 << 2 = 4
	GRPC                          // 1 << 3 = 8
	HESSIAN2                      // 1 << 4 = 16

	// Composite protocols
	TTHeaderFramed Protocol = TTHeader | Framed // 1 | 2 = 3

	// Streaming protocols with explicit values
	TTHeaderStreaming Protocol = 64  // Dedicated streaming protocol over TTHeader
	GRPCStreaming     Protocol = 128 // Dedicated gRPC streaming protocol
)

// Unknown indicates the protocol is unknown.
const Unknown = "Unknown"

// String prints human readable information.
func (tp Protocol) String() string {
	// Handle known individual and composite constants first
	switch tp {
	case PurePayload:
		return "PurePayload"
	case TTHeader:
		return "TTHeader"
	case Framed:
		return "Framed"
	case HTTP:
		return "HTTP"
	case GRPC:
		return "GRPC"
	case HESSIAN2:
		return "Hessian2"
	case TTHeaderFramed:
		return "TTHeaderFramed"
	case TTHeaderStreaming:
		return "TTHeaderStreaming"
	case GRPCStreaming:
		return "GRPCStreaming"
	}

	// For composite values with multiple bits set
	// Check individual bits in ascending order of their numeric values
	var parts []string
	if tp&TTHeader != 0 {
		parts = append(parts, "TTHeader")
	}
	if tp&Framed != 0 {
		parts = append(parts, "Framed")
	}
	if tp&HTTP != 0 {
		parts = append(parts, "HTTP")
	}
	if tp&GRPC != 0 {
		parts = append(parts, "GRPC")
	}
	if tp&HESSIAN2 != 0 {
		parts = append(parts, "HESSIAN2")
	}
	if tp&TTHeaderStreaming != 0 {
		parts = append(parts, "TTHeaderStreaming")
	}
	if tp&GRPCStreaming != 0 {
		parts = append(parts, "GRPCStreaming")
	}
	if len(parts) > 0 {
		return strings.Join(parts, "|")
	}
	return Unknown
}
