package desktop

import "fyne.io/fyne/v2"

// App represents a desktop application with system tray support and other desktop-specific features.
//
// Since: 2.5
type App interface {
	fyne.App

	// SetSystemTrayMenu sets the menu that will be displayed when the system tray icon is interacted with.
	// On some systems, a single click will show the menu, on others it may be a right-click or other gesture.
	SetSystemTrayMenu(menu *fyne.Menu)

	// SetSystemTrayIcon sets the icon to be displayed in the system tray.
	// If the icon is nil, the system tray icon will be removed.
	SetSystemTrayIcon(icon fyne.Resource)
}
