package app

import (
	"sync"

	"fyne.io/fyne/v2"
)

var (
	meta      fyne.AppMetadata
	metaMutex sync.RWMutex
)

// SetMetadata sets the application metadata.
// This allows overriding the default metadata at runtime.
//
// Since: 2.5
func SetMetadata(m fyne.AppMetadata) {
	metaMutex.Lock()
	defer metaMutex.Unlock()
	meta = m
}

func getMetadata() fyne.AppMetadata {
	metaMutex.RLock()
	defer metaMutex.RUnlock()
	
	// Return default metadata if none set
	if meta.ID == "" && meta.Name == "" && meta.Version == "" && meta.Build == 0 {
		return fyne.AppMetadata{
			ID:      "com.example",
			Name:    "Fyne App",
			Version: "1.0.0",
			Build:   1,
		}
	}
	
	return meta
}
