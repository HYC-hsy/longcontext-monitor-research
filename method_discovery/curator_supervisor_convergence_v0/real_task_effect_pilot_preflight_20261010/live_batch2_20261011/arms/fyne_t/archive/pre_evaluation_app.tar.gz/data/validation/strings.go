package validation

import (
	"errors"

	"fyne.io/fyne/v2"
)

// NewAllStrings creates a new validator that ensures the input matches one of the provided valid strings.
// The validator will return nil if the input is in the validStrings slice, otherwise returns an error.
//
// Since: 2.5
func NewAllStrings(validStrings []string, reason string) fyne.StringValidator {
	return func(text string) error {
		for _, valid := range validStrings {
			if text == valid {
				return nil
			}
		}
		return errors.New(reason)
	}
}
