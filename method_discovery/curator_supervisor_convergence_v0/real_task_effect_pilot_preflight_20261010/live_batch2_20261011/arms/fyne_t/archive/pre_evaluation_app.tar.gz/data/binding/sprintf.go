package binding

import (
	"fmt"

	"fyne.io/fyne/v2/storage"
)

type sprintfBinding struct {
	base
	format string
	sources []DataItem
	lastErr error
}

// NewSprintf creates a formatted string binding that combines multiple data bindings.
// The format string works like fmt.Sprintf, and the binding updates automatically
// when any source binding changes.
//
// Since: 2.5
func NewSprintf(format string, bindings ...DataItem) String {
	sb := &sprintfBinding{
		format:  format,
		sources: bindings,
	}

	// Listen to all source bindings
	listener := NewDataListener(func() {
		sb.trigger()
	})

	for _, b := range bindings {
		b.AddListener(listener)
	}

	return sb
}

func (sb *sprintfBinding) Get() (string, error) {
	if sb.lastErr != nil {
		return "", sb.lastErr
	}

	values := make([]interface{}, len(sb.sources))
	for i, source := range sb.sources {
		val, err := sb.getValue(source)
		if err != nil {
			return "", err
		}
		values[i] = val
	}

	return fmt.Sprintf(sb.format, values...), nil
}

func (sb *sprintfBinding) Set(str string) error {
	values := make([]interface{}, len(sb.sources))
	
	// Prepare pointers for Sscanf
	for i, source := range sb.sources {
		switch source.(type) {
		case Bool:
			var v bool
			values[i] = &v
		case Int:
			var v int
			values[i] = &v
		case Float:
			var v float64
			values[i] = &v
		case String:
			var v string
			values[i] = &v
		case Rune:
			var v rune
			values[i] = &v
		case Untyped:
			// Untyped cannot be round-tripped through string
			return fmt.Errorf("cannot parse Untyped binding from string")
		case URI:
			var v string
			values[i] = &v
		default:
			return fmt.Errorf("unsupported binding type")
		}
	}

	// Parse the string
	n, err := fmt.Sscanf(str, sb.format, values...)
	if err != nil {
		return err
	}
	if n != len(sb.sources) {
		return fmt.Errorf("parsed %d values, expected %d", n, len(sb.sources))
	}

	// Set the parsed values back to source bindings
	for i, source := range sb.sources {
		if err := sb.setValue(source, values[i]); err != nil {
			return err
		}
	}

	return nil
}

func (sb *sprintfBinding) getValue(source DataItem) (interface{}, error) {
	switch b := source.(type) {
	case Bool:
		return b.Get()
	case Int:
		return b.Get()
	case Float:
		return b.Get()
	case String:
		return b.Get()
	case Rune:
		return b.Get()
	case Untyped:
		return b.Get()
	case URI:
		u, err := b.Get()
		if err != nil {
			return nil, err
		}
		return u.String(), nil
	default:
		return nil, fmt.Errorf("unsupported binding type")
	}
}

func (sb *sprintfBinding) setValue(source DataItem, value interface{}) error {
	switch b := source.(type) {
	case Bool:
		return b.Set(*(value.(*bool)))
	case Int:
		return b.Set(*(value.(*int)))
	case Float:
		return b.Set(*(value.(*float64)))
	case String:
		return b.Set(*(value.(*string)))
	case Rune:
		return b.Set(*(value.(*rune)))
	case URI:
		u, err := storage.ParseURI(*(value.(*string)))
		if err != nil {
			return err
		}
		return b.Set(u)
	default:
		return fmt.Errorf("unsupported binding type")
	}
}

func (sb *sprintfBinding) trigger() {
	// Check if any source has an error
	sb.lastErr = nil
	for _, source := range sb.sources {
		if _, err := sb.getValue(source); err != nil {
			sb.lastErr = err
			break
		}
	}

	sb.lock.RLock()
	defer sb.lock.RUnlock()

	for _, listener := range sb.listeners {
		queueItem(listener.DataChanged)
	}
}

// StringToStringWithFormat wraps a String binding with a format string.
// If format is "%s", returns the original binding without wrapping.
//
// Since: 2.5
func StringToStringWithFormat(str String, format string) String {
	if format == "%s" {
		return str
	}
	return NewSprintf(format, str)
}
