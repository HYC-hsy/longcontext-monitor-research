package fyne

// Menu stores the information required for a standard menu.
// A menu can pop down from a MainMenu or could be a pop out menu.
type Menu struct {
	Label string
	Items []*MenuItem
}

// NewMenu creates a new menu given the specified label (to show in a MainMenu) and list of items to display.
func NewMenu(label string, items ...*MenuItem) *Menu {
	return &Menu{Label: label, Items: items}
}

// Refresh updates the menu to reflect any changes to its items.
// This will update all windows that are currently displaying this menu.
//
// Since: 2.2
func (m *Menu) Refresh() {
	app := CurrentApp()
	if app == nil {
		return
	}
	
	for _, window := range app.Driver().AllWindows() {
		if mainMenu := window.MainMenu(); mainMenu != nil {
			// Trigger a refresh of the window to update the menu bar
			if content := window.Content(); content != nil {
				window.Canvas().Refresh(content)
			}
		}
	}
}

// MenuItem is a single item within any menu, it contains a display Label and Action function that is called when tapped.
type MenuItem struct {
	ChildMenu *Menu
	// Since: 2.1
	IsQuit      bool
	IsSeparator bool
	Label       string
	Action      func()
	// Since: 2.1
	Disabled bool
	// Since: 2.1
	Checked bool
	// Icon is an optional icon to display alongside the menu item label.
	//
	// Since: 2.2
	Icon Resource
	// Shortcut is an optional keyboard shortcut for this menu item.
	//
	// Since: 2.2
	Shortcut Shortcut
}

// NewMenuItem creates a new menu item from the passed label and action parameters.
func NewMenuItem(label string, action func()) *MenuItem {
	return &MenuItem{Label: label, Action: action}
}

// NewMenuItemSeparator creates a menu item that is to be used as a separator.
func NewMenuItemSeparator() *MenuItem {
	return &MenuItem{IsSeparator: true, Action: func() {}}
}

// MainMenu defines the data required to show a menu bar (desktop) or other appropriate top level menu.
type MainMenu struct {
	Items []*Menu
}

// NewMainMenu creates a top level menu structure used by fyne.Window for displaying a menubar
// (or appropriate equivalent).
func NewMainMenu(items ...*Menu) *MainMenu {
	return &MainMenu{items}
}

// Refresh updates the main menu to reflect any changes.
// This will update all windows that are currently using this main menu.
//
// Since: 2.2
func (m *MainMenu) Refresh() {
	app := CurrentApp()
	if app == nil {
		return
	}
	
	for _, window := range app.Driver().AllWindows() {
		if window.MainMenu() == m {
			// Trigger a refresh of the window to update the menu bar
			if content := window.Content(); content != nil {
				window.Canvas().Refresh(content)
			}
		}
	}
}
