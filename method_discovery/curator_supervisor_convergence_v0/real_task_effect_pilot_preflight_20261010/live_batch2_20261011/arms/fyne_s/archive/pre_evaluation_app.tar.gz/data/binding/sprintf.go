package binding

import (
	"fmt"
	
	"fyne.io/fyne/v2/storage"
)

// sprintfString is a String binding that formats values using fmt.Sprintf
type sprintfString struct {
	base
	
	format  string
	sources []DataItem
}

// StringToStringWithFormat creates a binding that formats the source string using the provided format.
// The format string should be compatible with fmt.Sprintf and should contain exactly one %s or similar
// string format verb.
//
// If the format is "%s" (identity), the original binding is returned directly (no wrapping).
//
// Since: 2.2
func StringToStringWithFormat(source String, format string) String {
	if source == nil {
		return NewString() // Return empty binding if source is nil
	}
	
	// Optimization: if format is "%s", return source directly
	if format == "%s" {
		return source
	}
	
	return NewSprintf(format, source)
}

// NewSprintf creates a new string binding that formats multiple source data items using fmt.Sprintf.
// The format string follows fmt.Sprintf conventions, and the number of format verbs should match
// the number of source data items provided.
//
// Supported source types: String, Int, Float, Bool, URI
//
// The formatted binding supports reverse parsing via Set() using fmt.Sscanf semantics.
// URI values are parsed via storage.ParseURI.
//
// Since: 2.2
func NewSprintf(format string, sources ...DataItem) String {
	ret := &sprintfString{
		format:  format,
		sources: sources,
	}
	
	// Add listeners to all sources
	for _, src := range sources {
		if src != nil {
			src.AddListener(ret)
		}
	}
	
	return ret
}

func (s *sprintfString) Get() (string, error) {
	values := make([]interface{}, len(s.sources))
	
	for i, src := range s.sources {
		if src == nil {
			values[i] = nil
			continue
		}
		
		switch src := src.(type) {
		case String:
			if val, err := src.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = ""
			}
		case Int:
			if val, err := src.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = 0
			}
		case Float:
			if val, err := src.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = 0.0
			}
		case Bool:
			if val, err := src.Get(); err == nil {
				values[i] = val
			} else {
				values[i] = false
			}
		case URI:
			if val, err := src.Get(); err == nil {
				if val != nil {
					values[i] = val.String()
				} else {
					values[i] = ""
				}
			} else {
				values[i] = ""
			}
		default:
			values[i] = nil
		}
	}
	
	return fmt.Sprintf(s.format, values...), nil
}

func (s *sprintfString) Set(str string) error {
	if len(s.sources) == 0 {
		return nil
	}
	
	// Create pointers to receive parsed values
	values := make([]interface{}, len(s.sources))
	
	for i, src := range s.sources {
		if src == nil {
			continue
		}
		
		switch src.(type) {
		case String:
			var val string
			values[i] = &val
		case Int:
			var val int
			values[i] = &val
		case Float:
			var val float64
			values[i] = &val
		case Bool:
			var val bool
			values[i] = &val
		case URI:
			var val string
			values[i] = &val
		default:
			return fmt.Errorf("unsupported binding type for parsing")
		}
	}
	
	// Parse the string using Sscanf
	n, err := fmt.Sscanf(str, s.format, values...)
	if err != nil && n == 0 {
		return err
	}
	
	// Set the parsed values back to source bindings
	for i, src := range s.sources {
		if src == nil || values[i] == nil {
			continue
		}
		
		switch src := src.(type) {
		case String:
			if strPtr, ok := values[i].(*string); ok {
				if err := src.Set(*strPtr); err != nil {
					return err
				}
			}
		case Int:
			if intPtr, ok := values[i].(*int); ok {
				if err := src.Set(*intPtr); err != nil {
					return err
				}
			}
		case Float:
			if floatPtr, ok := values[i].(*float64); ok {
				if err := src.Set(*floatPtr); err != nil {
					return err
				}
			}
		case Bool:
			if boolPtr, ok := values[i].(*bool); ok {
				if err := src.Set(*boolPtr); err != nil {
					return err
				}
			}
		case URI:
			if strPtr, ok := values[i].(*string); ok {
				uri, err := storage.ParseURI(*strPtr)
				if err != nil {
					return err
				}
				if err := src.Set(uri); err != nil {
					return err
				}
			}
		}
	}
	
	return nil
}

// DataChanged is called when any of the source data items change
func (s *sprintfString) DataChanged() {
	s.trigger()
}
