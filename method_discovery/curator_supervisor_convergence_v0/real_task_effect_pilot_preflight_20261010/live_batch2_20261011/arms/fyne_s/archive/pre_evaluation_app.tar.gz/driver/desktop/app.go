// Package desktop provides desktop-specific driver extensions
package desktop

import "fyne.io/fyne/v2"

// App is an extension interface for desktop applications.
// It provides desktop-specific functionality like system tray support.
//
// Since: 2.2
type App interface {
	fyne.App
	
	// SetSystemTrayMenu sets the system tray menu for the application.
	// This allows the application to add an icon and menu to the system tray.
	// Pass nil to remove the system tray menu.
	SetSystemTrayMenu(menu *fyne.Menu)
	
	// SetSystemTrayIcon sets the system tray icon for the application.
	// This icon will be displayed in the system tray/notification area.
	// Pass nil to use the default application icon.
	SetSystemTrayIcon(icon fyne.Resource)
}
