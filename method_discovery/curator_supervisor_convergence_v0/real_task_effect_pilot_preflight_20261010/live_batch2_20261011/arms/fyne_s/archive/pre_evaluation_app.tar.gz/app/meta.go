package app

import "fyne.io/fyne/v2"

var appMetadata = fyne.AppMetadata{
	ID:      "com.example",
	Name:    "Fyne App",
	Version: "1.0.0",
	Build:   1,
}

// SetMetadata sets the application metadata that will be returned by App.Metadata().
// This should be called before creating windows to ensure the metadata is available.
//
// Since: 2.2
func SetMetadata(meta fyne.AppMetadata) {
	appMetadata = meta
}
