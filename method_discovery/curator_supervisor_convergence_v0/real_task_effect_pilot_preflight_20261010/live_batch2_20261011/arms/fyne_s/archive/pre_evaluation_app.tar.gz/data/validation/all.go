package validation

import "fyne.io/fyne/v2"

// NewAllStrings creates a new validator that requires all provided validators to pass.
// The returned validator will only return nil if all the provided validators return nil.
// If any validator fails, the error from the first failing validator is returned.
//
// Since: 2.2
func NewAllStrings(validators ...fyne.StringValidator) fyne.StringValidator {
	return func(s string) error {
		for _, validator := range validators {
			if validator == nil {
				continue
			}
			if err := validator(s); err != nil {
				return err
			}
		}
		return nil
	}
}
