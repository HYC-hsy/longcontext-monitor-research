
# Check if NewAllStrings exists in the validation package
cd /app && grep -r "func NewAllStrings" data/validation/ 2>/dev/null || echo "Not found in data/validation"
