
# Check where NewAllStrings was added
cd /app && find . -name "all.go" -o -name "*validation*" | grep -v vendor | head -20
