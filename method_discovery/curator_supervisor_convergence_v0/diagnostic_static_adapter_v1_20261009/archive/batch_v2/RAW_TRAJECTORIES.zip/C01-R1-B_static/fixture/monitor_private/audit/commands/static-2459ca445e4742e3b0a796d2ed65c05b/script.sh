
# List files in data/validation directory
cd /app && ls -la data/validation/
