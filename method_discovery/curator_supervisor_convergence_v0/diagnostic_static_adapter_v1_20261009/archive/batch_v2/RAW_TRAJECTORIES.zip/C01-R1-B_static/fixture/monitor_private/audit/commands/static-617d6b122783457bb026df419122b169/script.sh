
# Check if NewAllStrings is in data/binding instead
cd /app && grep -r "func NewAllStrings" data/binding/ 2>/dev/null || echo "Not found in data/binding"
