
# Check if it was incorrectly added to data/binding
cd /app && find data/binding -name "*.go" -exec grep -l "NewAllStrings" {} \;
