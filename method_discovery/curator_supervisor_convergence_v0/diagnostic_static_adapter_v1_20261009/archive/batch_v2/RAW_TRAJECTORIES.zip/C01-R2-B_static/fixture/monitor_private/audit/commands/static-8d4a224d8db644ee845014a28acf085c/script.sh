
# Check if NewAllStrings is in the correct location
cd /app && find data/validation -name "*.go" -exec grep -l "NewAllStrings" {} \;
