
# Check what files exist in data/validation
cd /app && ls -la data/validation/
