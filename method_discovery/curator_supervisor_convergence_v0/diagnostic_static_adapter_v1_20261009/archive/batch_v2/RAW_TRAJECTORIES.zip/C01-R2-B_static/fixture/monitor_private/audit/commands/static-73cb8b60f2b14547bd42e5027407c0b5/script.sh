
# Check if validation.NewAllStrings exists anywhere
cd /app && grep -r "func NewAllStrings" . --include="*.go" | grep -v vendor
