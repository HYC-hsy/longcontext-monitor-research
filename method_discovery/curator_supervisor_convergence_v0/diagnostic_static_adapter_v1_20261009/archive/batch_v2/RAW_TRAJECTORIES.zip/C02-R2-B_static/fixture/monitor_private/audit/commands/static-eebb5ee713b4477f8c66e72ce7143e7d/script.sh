
# Check toolbar constructor return types
cd /app && grep "func NewToolbar" widget/toolbar.go | head -5
