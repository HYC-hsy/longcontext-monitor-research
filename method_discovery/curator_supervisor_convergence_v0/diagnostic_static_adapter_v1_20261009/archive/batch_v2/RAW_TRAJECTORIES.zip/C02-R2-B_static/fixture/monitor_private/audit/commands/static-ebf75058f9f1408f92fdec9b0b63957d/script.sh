
# Verify the build still passes with all changes
cd /app && go build ./... 2>&1 | tail -5
