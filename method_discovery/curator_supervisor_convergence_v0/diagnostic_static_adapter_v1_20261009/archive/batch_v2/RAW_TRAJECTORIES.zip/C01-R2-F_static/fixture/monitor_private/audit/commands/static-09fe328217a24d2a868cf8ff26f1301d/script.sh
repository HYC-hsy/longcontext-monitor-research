
# Check what exists in data/validation
cd /app && ls -la data/validation/ 2>&1
