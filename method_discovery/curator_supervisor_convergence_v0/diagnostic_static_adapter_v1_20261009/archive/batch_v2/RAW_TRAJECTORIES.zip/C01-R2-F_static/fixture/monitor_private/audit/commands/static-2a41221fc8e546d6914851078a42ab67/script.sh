
# Check where NewAllStrings was implemented
cd /app && find . -name "*.go" -type f -exec grep -l "func NewAllStrings" {} \; 2>/dev/null | grep -v vendor
