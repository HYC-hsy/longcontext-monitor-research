
# Search more directly for NewAllStrings
cd /app && grep -r "NewAllStrings" . --include="*.go" 2>/dev/null | grep -v vendor | head -5
