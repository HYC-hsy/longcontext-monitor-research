
# Final comprehensive verification - check all key contract signatures
cd /app

echo "=== Target 1: App.Metadata() method ==="
grep -n "Metadata()" app.go | head -2

echo -e "\n=== Target 2: FromJSON signature (must be string parameter) ==="
grep "func FromJSON" theme/json.go

echo -e "\n=== Target 3: Set() and StringToStringWithFormat ==="
grep "func (b \*sprintfBinding) Set" data/binding/sprintf.go
grep "func StringToStringWithFormat" data/binding/sprintf.go

echo -e "\n=== Target 4: MenuItem Icon and Shortcut fields ==="
grep -A 2 "type MenuItem struct" menu.go | head -15

echo -e "\n=== Target 5: Toolbar constructor return types ==="
grep "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go

echo -e "\n=== Target 6: Container, Hyperlink, Entry, Validation ==="
grep "func (c \*Container) RemoveAll\|func (c \*Container) Add" container.go | head -2
grep "OnTapped func()" widget/hyperlink.go
grep "func (e \*Entry) SetMinRowsVisible" widget/entry.go
grep "func NewAllStrings" data/validation/all.go

echo -e "\n=== Target 7: desktop.App interface ==="
grep "SetSystemTray" driver/desktop/app.go | grep -v "//"

echo -e "\n=== Build check ==="
go build ./... 2>&1 | tail -5
