
# Quick verification of MenuItem struct has Icon and Shortcut
cd /app && awk '/type MenuItem struct/,/^}/' menu.go | grep -E "Icon|Shortcut"
