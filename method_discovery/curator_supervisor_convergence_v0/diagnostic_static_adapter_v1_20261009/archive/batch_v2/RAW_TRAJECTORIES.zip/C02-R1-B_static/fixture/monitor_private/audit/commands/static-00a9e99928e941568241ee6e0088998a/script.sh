
# Final comprehensive verification - check all key implementations exist
cd /app

echo "=== Target 1: App.Metadata() in interface ==="
grep -n "Metadata()" app.go | head -3

echo -e "\n=== Target 1: AppMetadata struct fields ==="
grep -A 5 "type AppMetadata struct" app.go

echo -e "\n=== Target 2: Theme variant color support ==="
grep "ColorsDark\|ColorsLight" theme/json.go | head -4

echo -e "\n=== Target 3: sprintf Set() with Sscanf ==="
grep -A 2 "fmt.Sscanf" data/binding/sprintf.go | head -5

echo -e "\n=== Target 4: MenuItem Icon and Shortcut fields ==="
grep -A 10 "type MenuItem struct" menu.go | grep -E "Icon|Shortcut"

echo -e "\n=== Target 5: Toolbar concrete return types ==="
grep "func NewToolbar" widget/toolbar.go | head -3

echo -e "\n=== Target 6: All implementations present ==="
grep -n "func (c \*Container) RemoveAll\|func (e \*Entry) SetMinRowsVisible\|OnTapped func()" container.go widget/entry.go widget/hyperlink.go 2>/dev/null | head -6

echo -e "\n=== Build status ==="
go build ./... 2>&1 | tail -2
