
# Check if NewAllStrings is anywhere else
cd /app && grep -r "func NewAllStrings" data/ 2>/dev/null || echo "Not found in data/"
