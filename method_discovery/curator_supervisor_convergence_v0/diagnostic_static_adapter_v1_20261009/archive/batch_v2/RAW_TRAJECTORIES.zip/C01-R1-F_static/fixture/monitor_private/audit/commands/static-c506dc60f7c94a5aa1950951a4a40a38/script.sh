
# Check if NewAllStrings exists and in which package
cd /app && find . -name "*.go" -type f | xargs grep -l "func NewAllStrings" | grep -v vendor
