
# Check for NewAllStrings in validation package
cd /app && ls -la data/validation/ 2>/dev/null && grep -r "NewAllStrings" data/validation/ 2>/dev/null || echo "Not found in data/validation"
