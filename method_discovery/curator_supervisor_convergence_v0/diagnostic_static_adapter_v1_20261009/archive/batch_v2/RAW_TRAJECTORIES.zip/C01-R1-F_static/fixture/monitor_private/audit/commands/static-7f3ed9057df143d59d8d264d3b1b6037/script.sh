
# Verify the corrections were made to the right widgets
cd /app && grep -n "OnTapped" widget/hyperlink.go | head -5
cd /app && grep -n "SetMinRowsVisible" widget/entry.go | head -5
