
# Check the package location
cd /app && grep -r "func NewAllStrings" --include="*.go" | grep -v vendor | head -5
