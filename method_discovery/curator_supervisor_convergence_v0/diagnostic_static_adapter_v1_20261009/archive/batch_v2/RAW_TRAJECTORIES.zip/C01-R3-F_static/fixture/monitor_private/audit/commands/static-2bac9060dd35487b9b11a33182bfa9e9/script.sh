
# Search for NewAllStrings more broadly
cd /app && grep -r "NewAllStrings" data/ 2>&1 | head -10
