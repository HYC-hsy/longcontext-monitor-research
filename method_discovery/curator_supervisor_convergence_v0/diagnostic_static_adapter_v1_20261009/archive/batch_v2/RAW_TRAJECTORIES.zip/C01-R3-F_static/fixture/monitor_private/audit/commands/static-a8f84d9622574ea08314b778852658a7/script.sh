
# Check if NewAllStrings exists and where it was added
cd /app && find . -name "*.go" -type f -exec grep -l "func NewAllStrings" {} \; | grep -v vendor
