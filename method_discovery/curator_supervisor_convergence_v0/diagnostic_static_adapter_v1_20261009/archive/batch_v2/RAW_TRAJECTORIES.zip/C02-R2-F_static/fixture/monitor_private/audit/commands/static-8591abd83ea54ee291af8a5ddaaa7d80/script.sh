
# Verify build still passes
cd /app && go build ./... 2>&1 | tail -5
