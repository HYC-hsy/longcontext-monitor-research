
# Final verification - check toolbar return types
cd /app && grep -A 1 "^func NewToolbarAction\|^func NewToolbarSpacer\|^func NewToolbarSeparator" widget/toolbar.go | grep -v "^--$"
