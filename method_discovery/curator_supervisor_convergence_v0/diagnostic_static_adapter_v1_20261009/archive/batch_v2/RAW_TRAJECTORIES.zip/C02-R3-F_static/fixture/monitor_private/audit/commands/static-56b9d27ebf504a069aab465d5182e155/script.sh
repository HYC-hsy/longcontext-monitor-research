
# Check build status from archived output
cd /app && tail -20 /logs/agent/monitor/monitor_private/audit/commands/static-699b9850acde4edba10e50779799b931/output.log 2>&1 || echo "Build still running or log not ready"
