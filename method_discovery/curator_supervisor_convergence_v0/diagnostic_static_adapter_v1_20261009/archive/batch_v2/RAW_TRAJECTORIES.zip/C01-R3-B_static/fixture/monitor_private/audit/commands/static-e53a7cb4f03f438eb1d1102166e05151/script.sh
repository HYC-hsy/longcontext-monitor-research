
# Check where NewAllStrings was added
cd /app && find . -name "*.go" -exec grep -l "func NewAllStrings" {} \; | grep -v vendor
