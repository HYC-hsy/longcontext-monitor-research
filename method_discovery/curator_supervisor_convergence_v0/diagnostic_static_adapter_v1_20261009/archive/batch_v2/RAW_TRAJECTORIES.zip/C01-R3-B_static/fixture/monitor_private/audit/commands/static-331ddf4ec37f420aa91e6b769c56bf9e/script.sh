
# Check if all.go exists in data/validation
cd /app && test -f data/validation/all.go && echo "EXISTS" || echo "MISSING"
