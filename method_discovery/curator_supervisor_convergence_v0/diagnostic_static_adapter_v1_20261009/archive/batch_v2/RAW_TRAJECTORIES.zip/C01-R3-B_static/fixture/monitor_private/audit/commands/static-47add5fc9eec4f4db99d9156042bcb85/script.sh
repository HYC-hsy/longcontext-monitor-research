
# Check if Target 7 (desktop.App interface) exists
cd /app && ls -la driver/desktop/
