
# Verify Entry has minRowsVisible field
cd /app && grep -B 2 -A 2 "minRowsVisible" widget/entry.go | head -20
