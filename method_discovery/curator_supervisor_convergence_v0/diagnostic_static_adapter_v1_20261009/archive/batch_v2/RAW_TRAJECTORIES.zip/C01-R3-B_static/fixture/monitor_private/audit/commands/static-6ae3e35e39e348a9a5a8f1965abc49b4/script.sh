
# Verify Hyperlink.OnTapped exists
cd /app && grep -A 2 "OnTapped" widget/hyperlink.go | head -10
