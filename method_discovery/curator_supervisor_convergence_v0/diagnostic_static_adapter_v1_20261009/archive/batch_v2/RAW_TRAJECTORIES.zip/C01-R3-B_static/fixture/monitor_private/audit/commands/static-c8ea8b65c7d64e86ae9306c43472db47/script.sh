
# Check Container.RemoveAll and nil-safe Add
cd /app && grep -A 8 "func (c \*Container) RemoveAll" container.go
