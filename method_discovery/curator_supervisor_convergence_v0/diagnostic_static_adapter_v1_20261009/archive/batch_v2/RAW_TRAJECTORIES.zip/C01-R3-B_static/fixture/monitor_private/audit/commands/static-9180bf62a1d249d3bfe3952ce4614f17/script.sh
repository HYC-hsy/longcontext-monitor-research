
# Check if validation.NewAllStrings exists in the correct location
cd /app && ls -la data/validation/
