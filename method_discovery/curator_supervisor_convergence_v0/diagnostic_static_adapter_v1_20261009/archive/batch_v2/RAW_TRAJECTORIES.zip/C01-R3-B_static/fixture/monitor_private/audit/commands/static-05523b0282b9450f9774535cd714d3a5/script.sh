
# Check if there are more turns after 61
cd /app && wc -l /logs/agent/monitor/task_evidence/synopsis.jsonl
