
# Verify Entry.SetMinRowsVisible exists
cd /app && grep -A 5 "SetMinRowsVisible" widget/entry.go | head -15
