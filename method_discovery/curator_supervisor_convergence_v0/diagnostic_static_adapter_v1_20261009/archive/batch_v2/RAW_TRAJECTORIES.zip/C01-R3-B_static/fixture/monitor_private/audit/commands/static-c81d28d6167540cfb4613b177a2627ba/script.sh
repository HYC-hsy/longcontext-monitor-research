
# Check if app.go exists in driver/desktop
cd /app && test -f driver/desktop/app.go && echo "EXISTS" || echo "MISSING"
