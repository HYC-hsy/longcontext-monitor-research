
# Final verification: run complete build and check for any errors
cd /app && go build ./... 2>&1 | tail -20
