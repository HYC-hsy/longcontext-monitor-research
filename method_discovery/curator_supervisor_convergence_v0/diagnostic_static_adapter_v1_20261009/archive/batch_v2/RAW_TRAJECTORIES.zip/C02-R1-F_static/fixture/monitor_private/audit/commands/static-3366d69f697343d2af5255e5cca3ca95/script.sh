
# Quick structural verification of critical signatures
cd /app

echo "=== Target 1: App.Metadata() in interface ==="
grep "Metadata()" app.go | head -2

echo -e "\n=== Target 2: FromJSON signature ==="
grep "func FromJSON(data string)" theme/json.go

echo -e "\n=== Target 3: Set() implementation exists ==="
grep "func (b \*sprintfBinding) Set" data/binding/sprintf.go | head -1

echo -e "\n=== Target 4: MenuItem fields ==="
grep -A 1 "Icon Resource\|Shortcut Shortcut" menu.go | head -4

echo -e "\n=== Target 5: Toolbar return types ==="
grep "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go | head -3

echo -e "\n=== Target 6: Key methods ==="
grep "func (c \*Container) RemoveAll\|func (e \*Entry) SetMinRowsVisible\|func NewAllStrings" container.go widget/entry.go data/validation/all.go 2>/dev/null | head -5

echo -e "\n=== Target 7: desktop.App interface ==="
grep "SetSystemTrayMenu\|SetSystemTrayIcon" driver/desktop/app.go | grep -v "//\|Since"
