
# Check where NewAllStrings was added
cd /app && find . -name "*.go" -type f -exec grep -l "NewAllStrings" {} \; | grep -v vendor
