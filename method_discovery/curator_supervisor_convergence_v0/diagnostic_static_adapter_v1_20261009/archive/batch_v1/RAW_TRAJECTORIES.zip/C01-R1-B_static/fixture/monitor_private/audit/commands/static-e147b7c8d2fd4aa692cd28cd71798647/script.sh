
# Verify it's in the correct package (data/validation)
cd /app && grep -n "func NewAllStrings" data/validation/*.go 2>/dev/null || echo "Not found in data/validation"
