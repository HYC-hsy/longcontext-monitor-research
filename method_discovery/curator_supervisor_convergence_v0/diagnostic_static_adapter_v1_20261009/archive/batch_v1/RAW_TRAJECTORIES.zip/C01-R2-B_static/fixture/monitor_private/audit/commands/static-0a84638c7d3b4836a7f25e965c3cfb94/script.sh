
# Check if NewAllStrings was added and in which package
cd /app && find . -name "*.go" -type f -exec grep -l "func NewAllStrings" {} \; | grep -v vendor
