
# Check if data/validation/all.go exists
cd /app && ls -la data/validation/ 2>&1
