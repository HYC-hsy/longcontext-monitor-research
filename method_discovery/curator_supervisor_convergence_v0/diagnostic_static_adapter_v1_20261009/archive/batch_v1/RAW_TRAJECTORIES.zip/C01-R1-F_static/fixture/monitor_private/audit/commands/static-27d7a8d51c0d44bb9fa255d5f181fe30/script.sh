
# Check where NewAllStrings was added
cd /app && find . -name "*.go" -type f -exec grep -l "func NewAllStrings" {} \; | grep -v vendor
