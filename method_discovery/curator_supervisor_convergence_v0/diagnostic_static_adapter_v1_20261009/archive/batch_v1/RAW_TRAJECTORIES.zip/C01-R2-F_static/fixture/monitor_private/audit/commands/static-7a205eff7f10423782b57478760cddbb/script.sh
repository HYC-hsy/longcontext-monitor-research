
# Check if desktop.App interface exists
cd /app && find . -name "app.go" -path "*/driver/desktop/*" 2>/dev/null
