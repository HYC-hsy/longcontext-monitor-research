
# Check MenuItem Icon and Shortcut fields
cd /app && grep -B 2 -A 8 "type MenuItem struct" menu.go
