
# Verify toolbar constructor return types
cd /app && grep -A 3 "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go | head -15
