
# Check if NewAllStrings exists and where
cd /app && find . -name "*.go" -type f -exec grep -l "func NewAllStrings" {} \; | grep -v vendor
