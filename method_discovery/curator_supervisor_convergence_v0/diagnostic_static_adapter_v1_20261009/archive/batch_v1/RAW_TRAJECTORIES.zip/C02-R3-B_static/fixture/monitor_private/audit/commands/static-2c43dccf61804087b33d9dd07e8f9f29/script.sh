
# Final comprehensive verification of all 7 targets
cd /app

echo "=== Target 1: AppMetadata in App interface ==="
grep -A 2 "Metadata()" app.go | head -5

echo -e "\n=== Target 2: JSON Theme variant support ==="
grep -n "ColorsDark\|ColorsLight" theme/json.go | head -5

echo -e "\n=== Target 3: sprintf Set() implementation ==="
grep -A 3 "func (b \*sprintfBinding) Set" data/binding/sprintf.go | head -6

echo -e "\n=== Target 4: MenuItem Icon and Shortcut fields ==="
grep -B 2 -A 1 "Icon.*Resource\|Shortcut.*Shortcut" menu.go | grep -A 1 "type MenuItem"

echo -e "\n=== Target 5: Toolbar concrete return types ==="
grep "func NewToolbar" widget/toolbar.go | head -4

echo -e "\n=== Target 6: All components present ==="
echo "Container.Add nil check:" && grep -A 2 "func (c \*Container) Add" container.go | head -4
echo "Hyperlink.OnTapped:" && grep "OnTapped func()" widget/hyperlink.go
echo "validation.NewAllStrings location:" && ls -la data/validation/all.go

echo -e "\n=== Target 7: Both desktop.App methods ==="
grep "SetSystemTray" driver/desktop/app.go | grep "func\|SetSystemTray"
