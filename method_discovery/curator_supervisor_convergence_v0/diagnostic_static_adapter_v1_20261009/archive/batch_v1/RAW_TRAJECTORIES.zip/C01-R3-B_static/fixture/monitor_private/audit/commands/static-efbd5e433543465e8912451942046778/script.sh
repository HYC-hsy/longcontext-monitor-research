
# Check if validation/all.go exists
cd /app && ls -la data/validation/
