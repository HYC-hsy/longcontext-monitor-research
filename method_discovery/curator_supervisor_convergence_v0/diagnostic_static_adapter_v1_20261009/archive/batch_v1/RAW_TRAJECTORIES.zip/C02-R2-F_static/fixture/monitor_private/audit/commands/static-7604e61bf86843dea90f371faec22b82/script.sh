
# Final verification: check toolbar constructor return types
cd /app && grep -A 1 "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go | head -20
