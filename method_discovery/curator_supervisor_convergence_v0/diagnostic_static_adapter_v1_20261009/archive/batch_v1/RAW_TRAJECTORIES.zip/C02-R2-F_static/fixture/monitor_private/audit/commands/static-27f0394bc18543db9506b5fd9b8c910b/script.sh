
# Run final build test to confirm no compilation errors
cd /app && go build ./... 2>&1 | tail -5
echo "Exit code: $?"
