
# Verify MenuItem has Icon and Shortcut fields
cd /app && grep -B 2 -A 10 "type MenuItem struct" menu.go
