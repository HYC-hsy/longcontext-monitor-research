
# Check ToolbarAction.SetIcon and toolbar constructor return types
cd /app && grep -A 2 "func (t \*ToolbarAction) SetIcon\|func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go
