
# Cancel the long build and do a simpler syntax check
cd /app && timeout 10 go build ./app ./theme ./data/binding ./data/validation ./widget ./driver/desktop 2>&1 || echo "Build check complete or timed out"
