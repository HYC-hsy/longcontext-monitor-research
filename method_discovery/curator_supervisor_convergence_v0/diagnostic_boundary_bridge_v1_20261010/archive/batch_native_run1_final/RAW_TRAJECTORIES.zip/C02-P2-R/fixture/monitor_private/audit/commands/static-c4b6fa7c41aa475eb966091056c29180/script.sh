
# Run a comprehensive build test
cd /app && go build -v ./... 2>&1 | tail -20
