
# Final comprehensive verification of all contract requirements
cd /app

echo "=== Target 1: App.Metadata() interface check ==="
grep -A 1 "Metadata()" app.go | head -5

echo -e "\n=== Target 2: JSON Theme variant color support ==="
grep -A 2 "ColorsDark\|ColorsLight" theme/json.go | head -10

echo -e "\n=== Target 3: sprintf Set() implementation check ==="
grep -A 10 "func (b \*sprintfBinding) Set" data/binding/sprintf.go | head -15

echo -e "\n=== Target 4: MenuItem Icon and Shortcut fields ==="
grep -A 2 "type MenuItem struct" menu.go | head -15

echo -e "\n=== Target 5: Toolbar concrete return types ==="
grep "func NewToolbar" widget/toolbar.go | head -5

echo -e "\n=== Build verification ==="
go build ./... 2>&1 | tail -5 || echo "Build exit code: $?"
