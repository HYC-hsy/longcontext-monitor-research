
# Quick verification of critical signatures
cd /app

echo "MenuItem Icon/Shortcut fields:"
grep -A 15 "type MenuItem struct" menu.go | grep -E "Icon|Shortcut|Label|Action"

echo -e "\nToolbarAction.SetIcon:"
grep -A 2 "func.*SetIcon" widget/toolbar.go | head -5
