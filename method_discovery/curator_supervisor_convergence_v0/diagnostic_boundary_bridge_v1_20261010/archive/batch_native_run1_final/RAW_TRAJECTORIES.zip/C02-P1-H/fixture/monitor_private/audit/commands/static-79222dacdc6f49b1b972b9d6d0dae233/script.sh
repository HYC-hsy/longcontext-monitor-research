
# Verify all 7 targets with complete evidence
cd /app

echo "=== VERIFICATION OF ALL 7 TARGETS ==="
echo ""
echo "Target 1 - App.Metadata() in interface:"
grep -A 1 "Metadata()" app.go | head -3

echo -e "\nTarget 2 - FromJSON string parameter:"
grep "func FromJSON(data string)" theme/json.go

echo -e "\nTarget 3 - sprintf.Set() implementation:"
grep -A 5 "func (b \*sprintfBinding) Set(str string)" data/binding/sprintf.go | head -7

echo -e "\nTarget 3 - StringToStringWithFormat exists:"
grep "func StringToStringWithFormat" data/binding/sprintf.go

echo -e "\nTarget 4 - MenuItem.Icon and Shortcut:"
grep -E "^\s+(Icon|Shortcut)" menu.go

echo -e "\nTarget 5 - Concrete toolbar types:"
grep "func NewToolbarAction.*\*ToolbarAction\|func NewToolbarSpacer.*\*ToolbarSpacer\|func NewToolbarSeparator.*\*ToolbarSeparator" widget/toolbar.go

echo -e "\nTarget 6 - validation.NewAllStrings location:"
ls -la data/validation/all.go

echo -e "\nTarget 7 - Both desktop.App methods:"
grep "SetSystemTray" driver/desktop/app.go | grep -v "//"
