
# Check ToolbarAction.SetIcon implementation - does it refresh?
cd /app && grep -A 5 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
