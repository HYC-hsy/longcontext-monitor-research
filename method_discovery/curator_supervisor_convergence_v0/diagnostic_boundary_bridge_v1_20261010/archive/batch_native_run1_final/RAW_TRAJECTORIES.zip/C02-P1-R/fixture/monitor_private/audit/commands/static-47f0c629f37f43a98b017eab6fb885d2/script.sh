
# Check toolbar return types and SetIcon
cd /app && grep -A 2 "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator\|func (t \*ToolbarAction) SetIcon" widget/toolbar.go
