
# Check if Hyperlink Tapped method checks OnTapped
cd /app && grep -B 3 -A 10 "func (hl \*Hyperlink) Tapped" widget/hyperlink.go
