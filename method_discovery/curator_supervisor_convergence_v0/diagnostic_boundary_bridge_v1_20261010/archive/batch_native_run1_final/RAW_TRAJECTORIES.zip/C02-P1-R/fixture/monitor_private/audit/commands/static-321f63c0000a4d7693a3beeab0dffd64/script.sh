
# Get complete MenuItem struct definition
cd /app && grep -A 20 "type MenuItem struct" menu.go
