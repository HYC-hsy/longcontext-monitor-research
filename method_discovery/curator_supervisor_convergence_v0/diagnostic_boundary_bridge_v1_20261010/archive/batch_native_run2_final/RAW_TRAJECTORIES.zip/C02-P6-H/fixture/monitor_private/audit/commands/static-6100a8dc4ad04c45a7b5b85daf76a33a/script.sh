
# Verify ToolbarAction.SetIcon and return types for toolbar constructors
cd /app && grep -A 3 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go

echo -e "\n=== Toolbar constructor signatures ==="
grep "^func NewToolbar" widget/toolbar.go | head -5
