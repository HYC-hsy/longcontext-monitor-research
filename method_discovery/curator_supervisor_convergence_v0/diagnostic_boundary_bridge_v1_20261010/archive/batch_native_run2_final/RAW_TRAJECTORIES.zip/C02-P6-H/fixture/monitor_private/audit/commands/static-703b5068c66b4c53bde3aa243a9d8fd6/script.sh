
# Try a simpler compilation check on a specific package
cd /app && go list -e -f '{{.ImportPath}}: {{.Error}}' ./... 2>&1 | grep -v "nil" | head -20
