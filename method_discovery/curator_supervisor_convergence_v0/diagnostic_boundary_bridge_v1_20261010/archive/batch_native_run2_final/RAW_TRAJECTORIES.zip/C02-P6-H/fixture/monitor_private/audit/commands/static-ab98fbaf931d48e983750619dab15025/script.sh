
# Check the actual output from the long-running builds
tail -50 /logs/agent/monitor/monitor_private/audit/commands/static-2160d60af72842a6bc6aa939c7159436/output.log
