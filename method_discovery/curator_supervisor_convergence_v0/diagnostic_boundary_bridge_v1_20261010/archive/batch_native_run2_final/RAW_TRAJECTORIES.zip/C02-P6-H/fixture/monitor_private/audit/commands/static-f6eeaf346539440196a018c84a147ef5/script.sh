
# Cancel the hanging builds and check a simpler compilation test
pkill -9 -f "go build" 2>/dev/null
sleep 1

# Test compilation of just the modified core files
cd /app && go build -o /tmp/test_app.o app.go 2>&1 | head -10
