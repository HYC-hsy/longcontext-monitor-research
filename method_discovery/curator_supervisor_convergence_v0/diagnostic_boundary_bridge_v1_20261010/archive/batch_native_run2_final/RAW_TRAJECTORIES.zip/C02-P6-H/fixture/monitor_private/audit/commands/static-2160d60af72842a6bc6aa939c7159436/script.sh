
# Get actual build errors
cd /app && go build ./... 2>&1 | grep -E "^#|error|cannot|undefined" | head -30
