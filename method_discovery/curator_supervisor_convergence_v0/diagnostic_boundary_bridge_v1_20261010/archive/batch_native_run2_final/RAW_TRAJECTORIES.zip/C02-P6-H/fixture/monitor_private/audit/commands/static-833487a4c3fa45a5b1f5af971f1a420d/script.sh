
# Check MenuItem Icon and Shortcut fields
cd /app && grep -A 20 "^type MenuItem struct" menu.go
