# Root Review - Completion Verification

## Investigation Summary

Systematically verified all 7 targets against task/original_task.txt specifications.

### Critical Contract Violations Found

#### Violation 1: Hyperlink.OnTapped Behavior Not Implemented

**Task Requirement** (task/original_task.txt lines 139-141):
> "When `OnTapped` is non-nil, tapping the hyperlink calls `OnTapped` **instead of** opening the URL. When `OnTapped` is nil, the existing URL-opening behavior is preserved."

**Actual Implementation** (widget/hyperlink.go):
- Line 30: `OnTapped func()` field exists ✓
- Line 163-165: `Tapped()` method unconditionally calls `hl.openURL()`
- Line 175-181: `openURL()` always opens URL, never checks OnTapped field

**Violation**: The behavior contract is not satisfied. The implementation always opens the URL regardless of whether OnTapped is set. Should call OnTapped INSTEAD OF opening URL when non-nil.

#### Violation 2: NewSprintf Set() Missing Required Type Handling

**Task Requirement** (task/original_task.txt lines 88-95):
> "Accepts a format string and variadic `DataItem` arguments (which may be `Bool`, `Bytes`, `Float`, `Int`, `Rune`, `String`, or `URI` bindings)"
> 
> "`Set(str string)` parses the string back using `fmt.Sscanf` and sets each source binding to the parsed value. **`Bytes` and `URI` types have special handling: `Bytes` cannot be round-tripped (returns an error), `URI` is parsed via `storage.ParseURI`**."

**Actual Implementation** (data/binding/sprintf.go lines 107-186):
- Set() method handles: String, Int, Float, Bool, Untyped
- NO handling for Bytes type (should return error for round-trip)
- NO handling for URI type (should use storage.ParseURI instead of fmt.Sscanf)
- NO handling for Rune type (also listed as acceptable DataItem)

**Verification**: URI binding type exists (data/binding/binditems.go line 466), Rune binding exists (line 284). Task explicitly lists these as supported types.

**Violation**: Required special handling for Bytes and URI is completely missing. Implementation will fail or behave incorrectly when these types are passed to NewSprintf.

### Targets Verified Correct

**Target 1 - App Metadata**: ✓
- AppMetadata struct in app.go has correct fields: ID, Name, Version, Build, Icon
- App.Metadata() method exists
- app/meta.go has SetMetadata with defaults

**Target 2 - JSON Theme**: ✓
- FromJSON and FromJSONReader exist
- Hex parsing supports 3,4,6,8 digit formats
- Variant color support implemented

**Target 4 - Menu**: ✓
- MenuItem has Icon and Shortcut fields
- Menu.Refresh() and MainMenu.Refresh() exist

**Target 5 - Toolbar**: ✓
- ToolbarAction.SetIcon() exists
- Constructors return concrete types

**Target 6 - Container/Other Widgets**: ✓
- Container.RemoveAll() exists, Add() is nil-safe
- Entry.SetMinRowsVisible() exists on Entry
- validation.NewAllStrings() in correct package

**Target 7 - Desktop App**: ✓
- desktop.App interface has both required methods

## Conclusion

Two behavioral contract violations block release:
1. Hyperlink.OnTapped does not override URL opening
2. NewSprintf Set() missing Bytes/URI/Rune type handling

Prior CRS focused only on structural presence (signatures, packages). These are behavioral correctness issues requiring implementation fixes.
