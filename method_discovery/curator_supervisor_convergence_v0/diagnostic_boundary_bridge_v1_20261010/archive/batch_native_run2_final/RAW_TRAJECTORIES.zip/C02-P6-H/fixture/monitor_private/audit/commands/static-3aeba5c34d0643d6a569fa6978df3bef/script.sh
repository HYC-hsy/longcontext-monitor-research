
# Check if the test package still compiles after all fixes
cd /app && go build ./test 2>&1 | head -20
