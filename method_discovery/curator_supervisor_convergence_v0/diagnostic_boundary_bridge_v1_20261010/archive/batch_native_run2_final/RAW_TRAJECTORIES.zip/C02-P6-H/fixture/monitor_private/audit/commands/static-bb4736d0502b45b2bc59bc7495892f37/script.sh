
# Quick build verification with timeout
cd /app && timeout 15 go build ./... 2>&1 && echo "BUILD_SUCCESS" || echo "BUILD_FAILED"
