
# Final comprehensive build check
cd /app && go build ./... 2>&1 | tail -20
echo "Build exit code: $?"
