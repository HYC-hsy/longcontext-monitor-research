
# Quick verification of key contract requirements
cd /app

echo "=== Target 1: AppMetadata fields ==="
grep -A 5 "type AppMetadata struct" app.go | head -10

echo -e "\n=== Target 2: FromJSON signature ==="
grep "^func FromJSON" theme/json.go

echo -e "\n=== Target 3: Set() and StringToStringWithFormat ==="
grep "^func.*Set(" data/binding/sprintf.go | head -1
grep "^func StringToStringWithFormat" data/binding/sprintf.go

echo -e "\n=== Target 6: NewAllStrings location ==="
ls -la data/validation/all.go 2>&1

echo -e "\n=== Target 7: desktop.App both methods ==="
grep "SetSystemTray" driver/desktop/app.go | grep -v "//"
