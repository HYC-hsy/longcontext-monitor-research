
# Quick final build check
cd /app && go build ./... 2>&1 | tail -5
