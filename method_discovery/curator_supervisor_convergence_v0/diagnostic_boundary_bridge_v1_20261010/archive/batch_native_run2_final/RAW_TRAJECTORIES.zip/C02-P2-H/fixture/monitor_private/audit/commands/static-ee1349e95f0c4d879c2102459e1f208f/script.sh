
cd /app

echo "=== Target 4: MenuItem fields (Icon and Shortcut) ==="
grep -A 10 "^type MenuItem struct" menu.go | head -20

echo -e "\n=== Target 4: Menu.Refresh and MainMenu.Refresh ==="
grep -n "func.*Refresh()" menu.go

echo -e "\n=== Target 5: Toolbar constructor signatures ==="
grep -n "^func NewToolbar" widget/toolbar.go

echo -e "\n=== Target 6: Container.RemoveAll ==="
grep -n "func.*RemoveAll" container.go

echo -e "\n=== Target 3: NewSprintf existence ==="
grep -n "^func NewSprintf" data/binding/sprintf.go
