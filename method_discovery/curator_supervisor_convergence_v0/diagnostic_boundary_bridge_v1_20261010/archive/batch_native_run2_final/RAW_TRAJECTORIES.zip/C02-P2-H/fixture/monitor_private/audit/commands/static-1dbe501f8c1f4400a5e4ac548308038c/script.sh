
# Quick test compile just the core packages modified
cd /app && timeout 15 go build -o /dev/null ./app ./theme ./data/binding ./data/validation ./driver/desktop 2>&1
