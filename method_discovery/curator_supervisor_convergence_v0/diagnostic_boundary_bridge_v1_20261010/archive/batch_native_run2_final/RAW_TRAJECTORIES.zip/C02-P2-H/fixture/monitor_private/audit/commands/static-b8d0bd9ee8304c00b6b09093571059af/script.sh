
cd /app

echo "=== Target 1: SetMetadata function in app/meta.go ==="
ls -la app/meta.go 2>&1
grep -n "func SetMetadata" app/meta.go 2>&1

echo -e "\n=== Target 5: ToolbarAction.SetIcon method ==="
grep -n "func.*SetIcon" widget/toolbar.go 2>&1

echo -e "\n=== Verify all implementations compile ==="
go build -v ./... 2>&1 | tail -5
echo "Exit code: $?"
