
# Check the openURL implementation to see if OnTapped overrides or is called in addition
cd /app && grep -A 10 "func (hl \*Hyperlink) openURL" widget/hyperlink.go
