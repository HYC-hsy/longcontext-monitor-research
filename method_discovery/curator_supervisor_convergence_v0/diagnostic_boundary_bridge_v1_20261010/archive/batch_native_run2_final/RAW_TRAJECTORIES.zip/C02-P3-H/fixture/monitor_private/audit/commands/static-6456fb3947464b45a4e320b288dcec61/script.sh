
# Check if MenuItem has Icon and Shortcut fields as required
cd /app && grep -A 20 "type MenuItem struct" menu.go
