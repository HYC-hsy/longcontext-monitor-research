
# Verify quick build without long test runs
cd /app && go build -o /dev/null . 2>&1 | head -20
