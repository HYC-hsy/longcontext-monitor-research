
# Quick targeted verification of critical contracts
cd /app

echo "=== Target 4: MenuItem Icon/Shortcut fields ==="
grep -A 10 "type MenuItem struct" menu.go | head -15

echo -e "\n=== Target 6: Hyperlink.OnTapped behavior requirement ==="
# Task: "When OnTapped is non-nil, tapping the hyperlink calls OnTapped instead of opening the URL"
grep -A 15 "func (h \*Hyperlink) Tapped" widget/hyperlink.go | head -20
