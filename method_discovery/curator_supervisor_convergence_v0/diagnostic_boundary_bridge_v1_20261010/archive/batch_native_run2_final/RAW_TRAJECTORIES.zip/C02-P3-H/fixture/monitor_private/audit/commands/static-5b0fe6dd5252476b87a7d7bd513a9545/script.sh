
# Check complete Tapped implementation to see if OnTapped overrides URL behavior
cd /app && grep -B 3 -A 15 "func (hl \*Hyperlink) Tapped" widget/hyperlink.go
