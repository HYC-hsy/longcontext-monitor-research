
# Check Hyperlink.OnTapped implementation and behavior
cd /app && grep -B 5 -A 20 "func (h.*Tapped\|OnTapped" widget/hyperlink.go | head -40
