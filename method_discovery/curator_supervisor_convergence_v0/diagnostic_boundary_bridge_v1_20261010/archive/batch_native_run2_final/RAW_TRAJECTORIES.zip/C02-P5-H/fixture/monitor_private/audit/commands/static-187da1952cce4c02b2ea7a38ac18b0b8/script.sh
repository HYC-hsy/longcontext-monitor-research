
# Quick build check with timeout
cd /app && timeout 30 go build ./... 2>&1 | tail -10
echo "Build exit code: $?"
