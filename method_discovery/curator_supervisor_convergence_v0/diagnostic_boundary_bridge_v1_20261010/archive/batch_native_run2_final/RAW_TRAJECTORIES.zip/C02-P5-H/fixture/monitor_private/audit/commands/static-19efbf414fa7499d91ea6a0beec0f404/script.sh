
# Verify all required files exist
cd /app
echo "=== Checking all target files exist ==="
for file in app.go app/meta.go app/app.go test/testapp.go theme/json.go data/binding/sprintf.go menu.go widget/toolbar.go container.go widget/hyperlink.go widget/entry.go data/validation/all.go driver/desktop/app.go; do
  if [ -f "$file" ]; then
    echo "✓ $file"
  else
    echo "✗ MISSING: $file"
  fi
done
