
# Final comprehensive verification of all 7 targets
cd /app

echo "=== Target 1: App Metadata ==="
grep -A2 "type AppMetadata struct" app.go | head -7

echo -e "\n=== Target 2: JSON Theme FromJSON signature ==="
grep "func FromJSON" theme/json.go

echo -e "\n=== Target 3: StringToStringWithFormat optimization check ==="
grep -A5 "func StringToStringWithFormat" data/binding/sprintf.go | head -10

echo -e "\n=== Target 4: MenuItem fields ==="
grep -E "Icon Resource|Shortcut Shortcut" menu.go

echo -e "\n=== Target 5: Toolbar constructor signatures ==="
grep "func NewToolbar" widget/toolbar.go

echo -e "\n=== Target 6: Container & Widget methods ==="
grep "func.*RemoveAll\|func.*SetMinRowsVisible" container.go widget/entry.go

echo -e "\n=== Target 6: validation.NewAllStrings location ==="
ls -la data/validation/all.go

echo -e "\n=== Target 7: desktop.App interface ==="
grep -A2 "type App interface" driver/desktop/app.go
