
# Cancel the running build and check previous build evidence
pkill -f "go build" 2>/dev/null
echo "Checking previous build verification from turn 81..."
