
# Check AppMetadata struct fields
cd /app && grep -A 10 "type AppMetadata struct" app.go
