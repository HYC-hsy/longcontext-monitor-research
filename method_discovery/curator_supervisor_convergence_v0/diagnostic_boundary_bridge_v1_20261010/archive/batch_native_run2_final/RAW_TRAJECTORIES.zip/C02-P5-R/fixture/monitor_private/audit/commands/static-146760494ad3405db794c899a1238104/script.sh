
# Final build verification to ensure everything compiles
cd /app && go build -v ./... 2>&1 | tail -5
