
# Check toolbar function return types
cd /app && grep -E "^func NewToolbar(Action|Spacer|Separator)" widget/toolbar.go
