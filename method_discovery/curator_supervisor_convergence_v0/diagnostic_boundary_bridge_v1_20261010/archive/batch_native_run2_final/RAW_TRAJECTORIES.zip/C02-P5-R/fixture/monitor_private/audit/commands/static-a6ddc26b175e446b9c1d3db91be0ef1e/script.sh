
# Verify MenuItem.Shortcut field exists (continuing from previous grep)
cd /app && grep -A 20 "type MenuItem struct" menu.go | grep -A 2 "Shortcut"
