
# Quick compilation check on key modified files
cd /app && go build app.go 2>&1 | head -5
