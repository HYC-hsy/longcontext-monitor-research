
# Verify ToolbarAction.SetIcon method
cd /app && grep -A 3 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
