
# Check for Bytes/URI special handling by looking at the full Set implementation
cd /app && sed -n '/func (b \*sprintfBinding) Set/,/^}/p' data/binding/sprintf.go | grep -A 3 "Bytes\|URI"
