
# Verify complete build passes
cd /app && go build -v ./... 2>&1 | tail -5
