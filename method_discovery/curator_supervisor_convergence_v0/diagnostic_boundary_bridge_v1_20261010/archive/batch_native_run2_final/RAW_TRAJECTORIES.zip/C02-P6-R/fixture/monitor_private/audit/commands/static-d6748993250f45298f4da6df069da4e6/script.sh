
# Check Bytes and URI special handling in Set() - need to see the full implementation
cd /app && grep -A 80 "func (b \*sprintfBinding) Set" data/binding/sprintf.go | grep -B 5 -A 5 "Bytes\|URI\|storage.ParseURI"
