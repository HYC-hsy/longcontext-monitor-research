
# Check variant-specific color support in JSON parsing
cd /app && grep -B 5 -A 10 "ColorsDark\|ColorsLight" theme/json.go | head -40
