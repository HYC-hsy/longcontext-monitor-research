
# Check Set() implementation in sprintf binding with Sscanf
cd /app && grep -A 40 "func (b \*sprintfBinding) Set" data/binding/sprintf.go | head -50
