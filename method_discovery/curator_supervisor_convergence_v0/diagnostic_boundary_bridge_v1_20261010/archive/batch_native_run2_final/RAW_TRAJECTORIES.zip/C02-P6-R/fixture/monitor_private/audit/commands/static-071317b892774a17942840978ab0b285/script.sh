
# Check if Bytes and URI types are handled in Set() implementation
cd /app && grep -n "case Bytes\|case URI" data/binding/sprintf.go
