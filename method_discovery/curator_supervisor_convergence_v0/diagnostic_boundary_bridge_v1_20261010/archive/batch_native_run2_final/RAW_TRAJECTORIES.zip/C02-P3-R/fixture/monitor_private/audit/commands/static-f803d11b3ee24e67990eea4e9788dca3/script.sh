
# Check if sprintf Set() handles Bytes and URI specially per spec
cd /app && grep -n "case Bytes\|case URI" data/binding/sprintf.go
