
# Verify hex parsing has case 8 for 8-digit format
cd /app && grep -A 80 "func parseHexColor" theme/json.go | grep "case 8:" -A 10
