
# Verify hex parsing handles 6 and 8 digit formats
cd /app && grep -A 50 "func parseHexColor" theme/json.go | grep -E "case (6|8):" -A 10
