
# Search for OnTapped usage in hyperlink openURL or Tapped methods
cd /app && sed -n '150,180p' widget/hyperlink.go
