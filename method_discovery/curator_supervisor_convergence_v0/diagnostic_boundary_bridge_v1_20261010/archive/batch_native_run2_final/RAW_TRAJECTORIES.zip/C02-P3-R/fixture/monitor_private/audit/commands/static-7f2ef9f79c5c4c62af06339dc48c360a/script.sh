
# Get the full Set() implementation to check for Bytes and URI handling
cd /app && awk '/^func \(b \*sprintfBinding\) Set\(/,/^}$/' data/binding/sprintf.go | wc -l
cd /app && awk '/^func \(b \*sprintfBinding\) Set\(/,/^}$/' data/binding/sprintf.go
