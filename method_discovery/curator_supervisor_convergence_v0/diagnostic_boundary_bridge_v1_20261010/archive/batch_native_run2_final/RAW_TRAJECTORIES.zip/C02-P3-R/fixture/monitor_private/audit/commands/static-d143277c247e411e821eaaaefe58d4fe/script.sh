
# Check if Bytes and URI have special handling in Set()
cd /app && grep -A 80 "func (b \*sprintfBinding) Set" data/binding/sprintf.go | grep -E "Bytes|URI" -A 3
