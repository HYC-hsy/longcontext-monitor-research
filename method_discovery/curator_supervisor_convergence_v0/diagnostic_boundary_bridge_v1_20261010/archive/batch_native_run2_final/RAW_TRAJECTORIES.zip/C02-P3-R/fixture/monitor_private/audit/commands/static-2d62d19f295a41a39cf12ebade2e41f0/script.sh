
# Check toolbar return types and SetIcon
cd /app && grep -E "func NewToolbar(Action|Spacer|Separator)" widget/toolbar.go
cd /app && grep -A 3 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
