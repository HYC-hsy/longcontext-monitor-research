
# Check the complete sprintf Set() for Bytes/URI handling
cd /app && awk '/func \(b \*sprintfBinding\) Set\(/,/^}$/' data/binding/sprintf.go | grep -E "Bytes|URI|storage\.ParseURI" 
