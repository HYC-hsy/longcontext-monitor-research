
# Check MenuItem struct for Icon and Shortcut fields - need full struct
cd /app && grep -A 15 "type MenuItem struct" menu.go
