
# Verify theme error handling returns default theme on parse error
cd /app && grep -B 2 -A 2 "return.*DefaultTheme" theme/json.go | head -20
