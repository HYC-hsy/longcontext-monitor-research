
# Check Hyperlink.OnTapped behavior - should REPLACE URL opening, not add to it
cd /app && grep -A 20 "func (h \*Hyperlink) Tapped" widget/hyperlink.go
