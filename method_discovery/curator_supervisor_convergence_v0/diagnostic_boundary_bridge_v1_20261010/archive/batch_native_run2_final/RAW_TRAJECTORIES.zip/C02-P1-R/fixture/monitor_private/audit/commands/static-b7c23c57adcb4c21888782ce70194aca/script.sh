
# Verify Bytes and URI special handling in sprintf Set()
cd /app && grep -A 30 "func (b \*sprintfBinding) Set" data/binding/sprintf.go | grep -A 5 "Bytes\|URI"
