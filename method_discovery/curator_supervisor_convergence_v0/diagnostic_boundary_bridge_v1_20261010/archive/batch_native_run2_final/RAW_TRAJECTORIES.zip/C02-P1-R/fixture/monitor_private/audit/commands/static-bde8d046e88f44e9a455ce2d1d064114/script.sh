
# Check the complete openURL implementation to verify OnTapped behavior
cd /app && grep -A 12 "func (hl \*Hyperlink) openURL" widget/hyperlink.go
