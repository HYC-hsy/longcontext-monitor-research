
# Check ToolbarAction.SetIcon implementation
cd /app && grep -A 8 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
