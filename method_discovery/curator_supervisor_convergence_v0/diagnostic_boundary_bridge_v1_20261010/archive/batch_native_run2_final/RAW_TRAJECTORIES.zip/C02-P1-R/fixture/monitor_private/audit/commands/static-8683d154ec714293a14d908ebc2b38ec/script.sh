
# Verify Hyperlink behavior - search for OnTapped usage in openURL or Tapped
cd /app && grep -B 5 -A 10 "OnTapped" widget/hyperlink.go | head -40
