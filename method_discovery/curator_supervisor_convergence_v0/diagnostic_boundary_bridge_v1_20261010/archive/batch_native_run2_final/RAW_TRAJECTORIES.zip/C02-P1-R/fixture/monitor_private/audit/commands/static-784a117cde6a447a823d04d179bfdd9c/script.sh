
# Check if ToolbarAction.SetIcon refreshes the toolbar as required
cd /app && grep -B 2 -A 10 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
