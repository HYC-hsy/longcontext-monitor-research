
# Check if Bytes or URI bindings are handled in sprintf Set()
cd /app && grep -n "Bytes\|URI\|Rune" data/binding/sprintf.go | head -20
