
# Check toolbar constructor return types
cd /app && grep "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go
