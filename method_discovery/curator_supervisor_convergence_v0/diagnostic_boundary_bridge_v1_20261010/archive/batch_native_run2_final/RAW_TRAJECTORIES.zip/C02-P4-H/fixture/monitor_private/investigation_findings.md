# Root Horizon Reset Investigation Findings

## Critical Contract Violations Found

### 1. StringToStringWithFormat Missing Optimization (Target 3)

**Specification (task/original_task.txt line 96):**
> "If the format is `"%s"` (identity), return the original binding directly (no wrapping). Otherwise, delegate to `NewSprintf(format, str)`."

**Actual Implementation (data/binding/sprintf.go line 201-210):**
```go
func StringToStringWithFormat(str String, format string) String {
	b := &stringToStringWithFormat{
		format: format,
		source: str,
	}
	// Listen to source changes
	str.AddListener(b)
	return b
}
```

**Evidence:** obs:code:792f20e271c5e1992bbe9fad shows no `if format == "%s"` check exists in the file.

**Contract Violation:** The function ALWAYS creates a wrapper, never returns the original binding directly when format is "%s". This violates the explicit optimization requirement.

---

### 2. Hyperlink.OnTapped Not Implemented (Target 6)

**Specification (task/original_task.txt line 141):**
> "When `OnTapped` is non-nil, tapping the hyperlink calls `OnTapped` **instead of** opening the URL. When `OnTapped` is nil, the existing URL-opening behavior is preserved."

**Actual Implementation (widget/hyperlink.go):**
- obs:code:06df3717120f5f29f4e4f83f shows Tapped() implementation:
```go
func (hl *Hyperlink) Tapped(*fyne.PointEvent) {
	hl.openURL()
}
```

- openURL() always attempts to open the URL if non-nil, never checks OnTapped field

**Contract Violation:** The OnTapped field exists (added to struct), but the Tapped() method NEVER checks or calls it. The implementation always opens the URL, completely ignoring the OnTapped callback. This violates the core behavioral requirement.

---

## Status of All 7 Targets

✓ Target 1: App Metadata - Complete
✓ Target 2: JSON Theme - Complete  
✗ Target 3: Data Binding - StringToStringWithFormat missing "%s" optimization
✓ Target 4: Menu System - Complete
✓ Target 5: Toolbar - Complete
✗ Target 6: Widget/Container - Hyperlink.OnTapped not implemented (field exists but unused)
✓ Target 7: Desktop App - Complete

**Entry.SetMinRowsVisible verified present:** obs shows line 468 in widget/entry.go
**Container.RemoveAll() verified present:** Earlier observations confirmed
**validation.NewAllStrings verified present:** Earlier observations confirmed
