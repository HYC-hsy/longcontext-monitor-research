
# Check Entry.SetMinRowsVisible method exists
grep -n "func.*SetMinRowsVisible" widget/entry.go || echo "NOT FOUND: Entry.SetMinRowsVisible method"
