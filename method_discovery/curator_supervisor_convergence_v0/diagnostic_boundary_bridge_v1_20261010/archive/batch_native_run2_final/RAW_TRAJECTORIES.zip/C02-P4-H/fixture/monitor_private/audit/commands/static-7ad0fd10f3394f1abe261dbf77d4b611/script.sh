
# Quick check of key implementations without full build
cd /app

echo "=== MenuItem struct fields ==="
grep -A 10 "type MenuItem struct" menu.go | head -15

echo -e "\n=== Toolbar constructors ==="
grep "func NewToolbar" widget/toolbar.go | head -5

echo -e "\n=== Test sprintf.Set() exists ==="
grep -c "func (b \*sprintfBinding) Set" data/binding/sprintf.go
