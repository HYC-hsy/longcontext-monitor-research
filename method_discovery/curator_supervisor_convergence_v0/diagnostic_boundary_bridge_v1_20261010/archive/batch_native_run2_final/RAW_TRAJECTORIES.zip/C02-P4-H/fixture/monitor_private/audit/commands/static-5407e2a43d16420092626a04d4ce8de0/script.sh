
# Check the actual StringToStringWithFormat implementation
echo "=== StringToStringWithFormat function ==="
grep -B 5 -A 15 "^func StringToStringWithFormat" data/binding/sprintf.go
