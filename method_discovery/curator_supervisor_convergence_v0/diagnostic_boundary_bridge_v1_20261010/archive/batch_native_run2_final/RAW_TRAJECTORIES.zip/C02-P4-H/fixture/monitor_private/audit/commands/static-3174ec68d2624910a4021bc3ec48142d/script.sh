
# Check if openURL respects OnTapped callback
grep -B 5 -A 10 "func (hl \*Hyperlink) Tapped" task/workspace/widget/hyperlink.go
