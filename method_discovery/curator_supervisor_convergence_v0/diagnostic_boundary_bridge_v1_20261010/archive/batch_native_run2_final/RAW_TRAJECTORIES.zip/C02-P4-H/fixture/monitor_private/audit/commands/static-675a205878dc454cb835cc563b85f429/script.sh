
# Check if workspace exists
ls task/ 2>&1 | head -10
