
# Check Entry.SetMinRowsVisible method
grep -n "func.*SetMinRowsVisible" task/workspace/widget/entry.go
