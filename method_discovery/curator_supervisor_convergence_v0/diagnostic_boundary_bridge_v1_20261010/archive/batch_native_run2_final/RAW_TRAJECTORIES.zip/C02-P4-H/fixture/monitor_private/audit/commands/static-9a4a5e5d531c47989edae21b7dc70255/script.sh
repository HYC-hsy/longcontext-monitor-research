
# Verify Hyperlink.Tapped respects OnTapped callback
echo "=== Hyperlink.Tapped implementation ===" 
grep -A 10 "func (hl \*Hyperlink) Tapped" widget/hyperlink.go

echo ""
echo "=== Hyperlink.openURL implementation ==="
grep -A 8 "func (hl \*Hyperlink) openURL" widget/hyperlink.go
