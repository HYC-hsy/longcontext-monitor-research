
# Check MenuItem Icon and Shortcut fields
cd /app && awk '/type MenuItem struct/,/^}/' menu.go | grep -E "Icon|Shortcut"
