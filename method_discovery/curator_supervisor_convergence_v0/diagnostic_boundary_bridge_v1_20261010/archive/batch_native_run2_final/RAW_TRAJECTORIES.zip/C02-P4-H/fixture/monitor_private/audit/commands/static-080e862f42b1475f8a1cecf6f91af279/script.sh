
# Find the actual workspace location
pwd
ls -la | head -20
