
# Check StringToStringWithFormat optimization for "%s"
grep -n 'if format == "%s"' data/binding/sprintf.go || echo "NOT FOUND: No optimization for format == '%s'"
