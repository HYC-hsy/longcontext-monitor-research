
# Check Hyperlink.Tapped implementation respects OnTapped callback
grep -B 2 -A 8 "func (hl \*Hyperlink) Tapped" widget/hyperlink.go
