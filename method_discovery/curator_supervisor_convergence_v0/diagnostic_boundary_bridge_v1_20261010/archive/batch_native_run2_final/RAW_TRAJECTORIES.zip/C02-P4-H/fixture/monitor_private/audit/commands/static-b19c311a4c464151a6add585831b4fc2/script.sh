
# Check StringToStringWithFormat optimization
grep -n 'if format == "%s"' task/workspace/data/binding/sprintf.go
