
# Verify if OnTapped field is checked in Hyperlink.Tapped implementation
echo "=== Full Tapped() and openURL() chain ==="
grep -B 2 -A 12 "func (hl \*Hyperlink) Tapped" widget/hyperlink.go
echo ""
echo "=== Check if OnTapped is ever referenced in hyperlink.go ==="
grep -n "OnTapped" widget/hyperlink.go
