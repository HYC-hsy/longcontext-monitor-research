
# Check the openURL implementation to verify OnTapped behavior
cd /app && grep -A 10 "func (hl \*Hyperlink) openURL" widget/hyperlink.go
