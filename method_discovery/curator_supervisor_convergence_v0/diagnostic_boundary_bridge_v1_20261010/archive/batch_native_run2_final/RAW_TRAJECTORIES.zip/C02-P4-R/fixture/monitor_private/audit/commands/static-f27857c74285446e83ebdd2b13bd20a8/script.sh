
# Check for MenuItem.Shortcut field (need to see more of the struct)
cd /app && grep -A 20 "type MenuItem struct" menu.go | grep -i shortcut
