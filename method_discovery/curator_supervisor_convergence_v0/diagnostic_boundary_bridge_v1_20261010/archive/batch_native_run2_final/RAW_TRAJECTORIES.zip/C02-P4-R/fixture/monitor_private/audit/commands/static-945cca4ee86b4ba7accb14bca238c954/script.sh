
# Check actual function signatures for toolbar constructors
cd /app && grep -A 1 "^func NewToolbarAction\|^func NewToolbarSpacer\|^func NewToolbarSeparator" widget/toolbar.go
