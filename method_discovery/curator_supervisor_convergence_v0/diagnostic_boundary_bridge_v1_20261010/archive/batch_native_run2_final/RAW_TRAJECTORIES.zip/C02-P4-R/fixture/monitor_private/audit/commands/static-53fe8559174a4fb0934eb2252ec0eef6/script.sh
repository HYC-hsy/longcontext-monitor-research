
# Check toolbar return types and SetIcon method
cd /app && grep -n "func NewToolbar\|func (t \*ToolbarAction) SetIcon" widget/toolbar.go | head -10
