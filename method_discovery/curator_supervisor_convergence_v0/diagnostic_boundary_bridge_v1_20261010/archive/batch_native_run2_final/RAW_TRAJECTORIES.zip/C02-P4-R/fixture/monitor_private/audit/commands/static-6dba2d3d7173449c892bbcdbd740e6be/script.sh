
# Final build check to ensure everything compiles
cd /app && go build ./... 2>&1 | tail -5
