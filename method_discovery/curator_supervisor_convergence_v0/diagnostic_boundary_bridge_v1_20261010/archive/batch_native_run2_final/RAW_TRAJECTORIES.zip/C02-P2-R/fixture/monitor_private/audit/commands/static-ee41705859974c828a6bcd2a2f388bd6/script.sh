
# Verify variant color support in JSON theme
cd /app && grep -A 5 "ColorsDark\|ColorsLight" theme/json.go | head -20
