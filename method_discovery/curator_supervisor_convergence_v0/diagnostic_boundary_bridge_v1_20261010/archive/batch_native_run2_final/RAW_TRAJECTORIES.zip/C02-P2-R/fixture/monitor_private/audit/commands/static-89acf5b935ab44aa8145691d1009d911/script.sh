
# Search for Tapped or MouseDown in hyperlink to see behavior
cd /app && grep -n "Tapped\|MouseDown\|MouseUp" widget/hyperlink.go | head -10
