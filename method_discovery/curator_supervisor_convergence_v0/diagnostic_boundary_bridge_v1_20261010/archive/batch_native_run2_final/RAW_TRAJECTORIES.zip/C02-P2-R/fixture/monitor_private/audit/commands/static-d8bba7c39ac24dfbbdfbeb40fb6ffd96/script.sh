
# Check if there's a renderer or tap handler implementation
cd /app && grep -A 20 "hyperlink.*Tapped\|hyperlinkRenderer" widget/hyperlink.go | head -40
