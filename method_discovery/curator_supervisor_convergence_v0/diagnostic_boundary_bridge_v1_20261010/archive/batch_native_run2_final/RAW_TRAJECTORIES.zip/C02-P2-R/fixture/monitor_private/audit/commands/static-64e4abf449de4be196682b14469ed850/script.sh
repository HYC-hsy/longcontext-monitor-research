
# Check ToolbarAction.SetIcon method
cd /app && grep -A 5 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
