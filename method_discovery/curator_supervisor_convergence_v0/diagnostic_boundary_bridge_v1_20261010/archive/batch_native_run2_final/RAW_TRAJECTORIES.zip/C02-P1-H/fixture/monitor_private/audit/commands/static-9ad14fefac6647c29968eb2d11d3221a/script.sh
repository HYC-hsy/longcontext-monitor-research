
# Final comprehensive verification - check that all 7 targets have correct signatures
cd /app

echo "=== Target 1: App.Metadata() in App interface ==="
grep -A 1 "Metadata() AppMetadata" app.go

echo -e "\n=== Target 2: FromJSON(string) signature ==="
grep "func FromJSON(data string)" theme/json.go

echo -e "\n=== Target 3: Set() and StringToStringWithFormat ==="
grep "func (b \*sprintfBinding) Set(str string)" data/binding/sprintf.go
grep "func StringToStringWithFormat(str String, format string)" data/binding/sprintf.go

echo -e "\n=== Target 4: MenuItem.Icon and MenuItem.Shortcut fields ==="
grep -A 2 "type MenuItem struct" menu.go | grep -E "Icon|Shortcut"

echo -e "\n=== Target 5: Toolbar constructor return types ==="
grep "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go

echo -e "\n=== Target 6: All features ==="
grep "func (c \*Container) RemoveAll()" container.go
grep "OnTapped func()" widget/hyperlink.go
grep "func (e \*Entry) SetMinRowsVisible" widget/entry.go
grep "func NewAllStrings" data/validation/all.go

echo -e "\n=== Target 7: desktop.App both methods ==="
grep "SetSystemTray" driver/desktop/app.go
