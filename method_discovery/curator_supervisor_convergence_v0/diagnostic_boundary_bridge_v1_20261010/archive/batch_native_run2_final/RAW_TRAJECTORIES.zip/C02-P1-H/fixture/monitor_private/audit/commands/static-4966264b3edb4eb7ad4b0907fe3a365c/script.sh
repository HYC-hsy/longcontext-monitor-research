
# Verify the build passes
cd /app && go build ./... 2>&1 | tail -20
