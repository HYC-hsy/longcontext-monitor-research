"""Offline exact pinned PMA loader/formatter check; no transport or Task execution."""
import hashlib, importlib, importlib.util, json, os, socket, sys, tempfile
from pathlib import Path
from types import ModuleType
ROOT=Path(__file__).resolve().parent
REFERENCE=ROOT.parent/'lab/integration/run_actual_pma.py'
REF_HASH='856f00548f4e497eabf27a4783cd18820ace9441110298c7895043304db8f948'
PUBLIC=Path('/workspace/shared/baseline12_audit_20261016/public')
CASES=[('07',235),('18',6),('14',105)]
def digest(x): return hashlib.sha256(x.encode()).hexdigest()
def main():
 assert sys.flags.isolated and sys.flags.no_site
 assert set(os.environ) <= {'LC_CTYPE'}, 'clean environment required (Python locale coercion allowed)'
 sys.dont_write_bytecode=True
 assert hashlib.sha256(REFERENCE.read_bytes()).hexdigest()==REF_HASH
 spec=importlib.util.spec_from_file_location('reviewed_loader_reference',REFERENCE)
 ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
 cases=[]
 for arm,step in CASES:
  bank_path=ROOT/f'pre_phase1_{arm}_{step}.json'
  request_path=PUBLIC/arm/'pma_requests_public.json'
  request=json.loads(request_path.read_text())[2*step-2]
  assert request['phase']=='bank_management'
  cases.append((arm,step,json.loads(bank_path.read_text()),request,hashlib.sha256(bank_path.read_bytes()).hexdigest(),hashlib.sha256(request_path.read_bytes()).hexdigest()))
 violations=[]
 with tempfile.TemporaryDirectory(prefix='pma_loader_only_') as directory:
  root=Path(directory)
  for relative,expected in ref.PINS.items():
   data=(ref.SOURCE/relative).read_bytes();assert hashlib.sha256(data).hexdigest()==expected
   target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  for name,path in [('memory_agent',root/'src/memory_agent'),('memory_agent.memory',root/'src/memory_agent/memory')]:
   package=ModuleType(name);package.__path__=[str(path)];sys.modules[name]=package
  shim=ModuleType('shortuuid')
  def forbidden_uuid(): raise AssertionError('loader must preserve archived IDs')
  shim.uuid=forbidden_uuid;sys.modules['shortuuid']=shim
  def audit(event,args):
   blocked=event in {'socket.connect','socket.bind','socket.getaddrinfo','socket.sendto','socket.sendmsg','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork'}
   if event=='import': blocked=args[0].split('.')[0] not in sys.stdlib_module_names and args[0].split('.')[0] not in {'memory_agent','shortuuid'}
   if event=='socket.__new__': blocked=True
   if event=='open':
    mode,flags=args[1:3]
    blocked=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
   if blocked: violations.append(event);raise PermissionError('offline loader boundary: '+event)
  sys.addaudithook(audit)
  module=importlib.import_module('memory_agent.memory.memory_agent')
  rows=[]
  marker='\n\n## Context (Task Description + Recent Trajectory)\n'
  # Remove only the fixed original template suffix, not text matched within observation.
  suffix='\n\n## Your Task\nAnalyze the trajectory and update the memory bank. Save important facts, record experiences, delete outdated entries. Be selective — only save what would be lost as the agent\'s context scrolls.\n'
  for arm,step,snapshot,request,bank_sha,archive_sha in cases:
   prompt=request['prompt'];assert prompt.endswith(suffix)
   observation=prompt.split(marker,1)[1][:-len(suffix)]
   bank=module.UniversalMemory.from_dict(snapshot)
   agent=module.MemoryAgent(llm=None,memory=bank)
   rebuilt=agent._build_phase1_prompt(observation,step_count=step)
   roundtrip=bank.to_dict()
   content_equal=roundtrip['status']==snapshot['status'] and all([{k:x[k] for k in ('id','content')} for x in roundtrip[key]]==snapshot[key] for key in ('knowledge','procedural'))
   rows.append(dict(arm=arm,step=step,prompt_bytes_equal=rebuilt.encode()==prompt.encode(),content_ids_order_status_equal=content_equal,system_equal=request['system']==module.PHASE1_SYSTEM,tools_equal=request['tools']==module.BANK_TOOLS,bank_sha256=bank_sha,archive_sha256=archive_sha,archived_prompt_sha256=digest(prompt),rebuilt_prompt_sha256=digest(rebuilt),observation_sha256=digest(observation),observation=observation,entry_counts={k:len(snapshot[k]) for k in ('knowledge','procedural')},metadata_defaults={'created_at':'fresh loader timestamp, not historical','access_count':0,'last_accessed':None},max_memory_in_prompt=agent.max_memory_in_prompt,use_bm25_prefilter=agent.use_bm25_prefilter))
  assert not violations
  print(json.dumps(dict(status='pass' if all(x['prompt_bytes_equal'] and x['content_ids_order_status_equal'] and x['system_equal'] and x['tools_equal'] for x in rows) else 'mismatch',cases=rows,source_hashes=ref.PINS,reviewed_harness_sha256=REF_HASH,blocked_events=violations,model_calls=0,task_runs=0,scope='Actual upstream loader and full Phase1 user prompt byte equality; not historical metadata or Task checkpoint restoration'),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
