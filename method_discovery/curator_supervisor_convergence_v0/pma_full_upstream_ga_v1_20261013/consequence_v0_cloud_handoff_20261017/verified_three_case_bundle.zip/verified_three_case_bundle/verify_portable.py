"""Offline exact pinned PMA loader/formatter check; no transport or Task execution."""
import hashlib, importlib, importlib.util, json, os, socket, sys, tempfile
from pathlib import Path
from types import ModuleType
ROOT=Path(__file__).resolve().parent
MANIFEST=json.loads((ROOT/'bundle.json').read_text())
def digest(x): return hashlib.sha256(x.encode()).hexdigest()
def main():
 assert sys.flags.isolated and sys.flags.no_site
 assert set(os.environ) <= {'LC_CTYPE'}, 'clean environment required (Python locale coercion allowed)'
 sys.dont_write_bytecode=True
 from types import SimpleNamespace
 ref=SimpleNamespace(SOURCE=ROOT/'vendor',PINS=MANIFEST['pma_source_hashes'])
 cases=[]
 for x in MANIFEST['cases']:
  bank_path=ROOT/x['bank'];obs_path=ROOT/x['observation']
  assert hashlib.sha256(bank_path.read_bytes()).hexdigest()==x['bank_sha256']
  assert hashlib.sha256(obs_path.read_bytes()).hexdigest()==x['observation_sha256']
  cases.append((x,json.loads(bank_path.read_text()),obs_path.read_text()))
 violations=[]
 with tempfile.TemporaryDirectory(prefix='pma_loader_only_') as directory:
  root=Path(directory)
  for relative,expected in ref.PINS.items():
   data=(ref.SOURCE/relative).read_bytes();assert hashlib.sha256(data).hexdigest()==expected
   target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  for name,path in [('memory_agent',root/'src/memory_agent'),('memory_agent.memory',root/'src/memory_agent/memory')]:
   package=ModuleType(name);package.__path__=[str(path)];sys.modules[name]=package
  shim=ModuleType('shortuuid')
  def forbidden_uuid(): raise AssertionError('loader must preserve archived IDs')
  shim.uuid=forbidden_uuid;sys.modules['shortuuid']=shim
  def audit(event,args):
   blocked=event in {'socket.connect','socket.bind','socket.getaddrinfo','socket.sendto','socket.sendmsg','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork'}
   if event=='import': blocked=args[0].split('.')[0] not in sys.stdlib_module_names and args[0].split('.')[0] not in {'memory_agent','shortuuid'}
   if event=='socket.__new__': blocked=True
   if event=='open':
    mode,flags=args[1:3]
    blocked=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
   if blocked: violations.append(event);raise PermissionError('offline loader boundary: '+event)
  sys.addaudithook(audit)
  module=importlib.import_module('memory_agent.memory.memory_agent')
  rows=[]
  for x,snapshot,observation in cases:
   arm,step=x['arm'],x['step']
   bank=module.UniversalMemory.from_dict(snapshot)
   agent=module.MemoryAgent(llm=None,memory=bank)
   rebuilt=agent._build_phase1_prompt(observation,step_count=step)
   roundtrip=bank.to_dict()
   content_equal=roundtrip['status']==snapshot['status'] and all([{k:x[k] for k in ('id','content')} for x in roundtrip[key]]==snapshot[key] for key in ('knowledge','procedural'))
   rows.append(dict(arm=arm,step=step,prompt_hash_equal=digest(rebuilt)==x['expected_original_U_phase1_prompt_sha256'],content_ids_order_status_equal=content_equal,rebuilt_prompt_sha256=digest(rebuilt)))
  assert not violations
  assert all(x['prompt_hash_equal'] and x['content_ids_order_status_equal'] for x in rows), rows
  print(json.dumps(dict(status='pass',cases=rows,model_calls=0,task_runs=0,blocked_events=violations),indent=2))
if __name__=='__main__':main()
