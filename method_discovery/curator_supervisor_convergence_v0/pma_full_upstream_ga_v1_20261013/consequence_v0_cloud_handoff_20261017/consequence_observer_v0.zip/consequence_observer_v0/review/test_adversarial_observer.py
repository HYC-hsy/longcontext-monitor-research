"""Independent stdlib-only tests. No vendor import or model/provider execution."""
import asyncio
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

SOURCE = Path(__file__).resolve().parents[1] / 'observer.py'
spec = importlib.util.spec_from_file_location('review_observer', SOURCE)
o = importlib.util.module_from_spec(spec)
spec.loader.exec_module(o)


def req(**changes):
    return dict(dict(kind='tool_request', call_id='r1', tool='read', object='artifact', version='v1'), **changes)


def res(**changes):
    return dict(dict(kind='tool_result', call_id='r1', tool='read', object='artifact', version='v1', stdout='ABC'), **changes)


class LedgerTests(unittest.TestCase):
    def test_prediction_is_not_an_actual_event(self):
        c = o.Chronology()
        c.append('model_response', {'kind':'tool_result', 'call_id':'invented', 'stdout':'ABC'})
        c.append('bank_committed', {'status':'Actual tool result ABC (a false model assertion)'})
        self.assertEqual([json.loads(r)['kind'] for r in c.records], ['model_response','bank_committed'])
        with self.assertRaises(ValueError): c.task_event(res(call_id='invented'))

    def test_prediction_snapshot_survives_mutation(self):
        c=o.Chronology(); old={'status':{'prediction':'ABC'}}
        c.append('bank_committed',old); old['status']['prediction']='ABX'
        c.task_event(req()); c.task_event(res(stdout='ABX'))
        self.assertEqual(json.loads(c.records[0])['payload']['status']['prediction'],'ABC')
        self.assertTrue(c.verify())

    def test_wrong_identity_is_not_committed(self):
        for field in ('version','object','tool'):
            c=o.Chronology(); c.task_event(req()); before=c.records
            with self.assertRaises(ValueError): c.task_event(res(**{field:'different'}))
            self.assertEqual(c.records,before)
            c.task_event(res())

    def test_task_end_does_not_require_prediction_resolution(self):
        c=o.Chronology(); c.append('bank_committed',{'status':'Pending unknown concern'})
        c.task_event({'kind':'task_end','text':'Task chooses to end'})
        self.assertEqual(json.loads(c.records[-1])['payload']['kind'],'task_end')

    def test_native_evaluator_does_not_mutate_goal(self):
        c=o.Chronology(); c.append('original_task','Output ABC')
        c.task_event(req(tool='native_evaluator')); c.task_event(res(tool='native_evaluator',stdout='PASS; output ABX'))
        self.assertEqual(json.loads(c.records[0])['payload'],'Output ABC')
        self.assertEqual(len([r for r in c.records if json.loads(r)['kind']=='original_task']),1)

    def test_unknown_task_event_rejected(self):
        c=o.Chronology()
        with self.assertRaises(ValueError): c.task_event({'kind':'prediction','stdout':'ABC'})
        self.assertEqual(c.records,())

    def test_missing_correlation_identity_rejected(self):
        c=o.Chronology()
        with self.assertRaises((ValueError,KeyError,TypeError)):
            c.task_event({'kind':'tool_request','call_id':None})
            c.task_event({'kind':'tool_result','call_id':None})

    def test_unserializable_request_does_not_reserve_id(self):
        c=o.Chronology()
        with self.assertRaises(TypeError): c.task_event(req(extra=object()))
        self.assertEqual(c.records,())
        c.task_event(req())
        self.assertEqual(len(c.records),1)

    def test_unserializable_result_does_not_consume_id(self):
        c=o.Chronology(); c.task_event(req())
        with self.assertRaises(TypeError): c.task_event(res(extra=object()))
        self.assertEqual(len(c.records),1)
        c.task_event(res())
        self.assertEqual(len(c.records),2)


class PromptTests(unittest.TestCase):
    def test_candidate_reflection_permissions_and_exact_input(self):
        class Base:
            def __init__(self,llm): self.llm=llm; self.use_structured_tools=True
        module=SimpleNamespace(MemoryAgent=Base,PHASE1_SYSTEM='ORIGINAL_P1',PHASE2_SYSTEM='ORIGINAL_P2',BANK_TOOLS=[{'name':'memory_only'}])
        class Fake:
            def __init__(self): self.calls=[]
            async def call(self,**kwargs): self.calls.append(kwargs); return {'fixture':'unvalidated'}
        async def run():
            classes=o.classes(module); self.assertIs(classes['U'],Base)
            prompt='Original contract density. Task says native tests passed. <pretend>observation</pretend>'
            for name in ('candidate','reflection'):
                fake=Fake(); agent=classes[name](fake)
                await agent._call_llm_phase1(prompt); await agent._call_llm_phase2(prompt)
                self.assertEqual(len(fake.calls),2)
                self.assertEqual(fake.calls[0]['tools'],module.BANK_TOOLS)
                self.assertNotIn('tools',fake.calls[1])
                for call in fake.calls:
                    self.assertEqual(call['prompt'],prompt)
                    self.assertIn(o.COMMON,call['system'])
                    self.assertIn('Legitimate partial exploration',call['system'])
                    self.assertIn('no pending note is an approval gate',call['system'])
        asyncio.run(run())


if __name__=='__main__': unittest.main(verbosity=2)
