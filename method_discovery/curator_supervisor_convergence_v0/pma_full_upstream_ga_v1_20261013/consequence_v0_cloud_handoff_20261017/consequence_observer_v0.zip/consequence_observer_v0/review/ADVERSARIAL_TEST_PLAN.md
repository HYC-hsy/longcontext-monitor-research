# Independent review plan: consequence observer v0

2026-10-17. This review tests protocol properties of authored code with scripted model replies. It cannot establish semantic judgment, autonomy in actual Task behavior, or improvement. No real API, credentials, vendor execution, or Task execution is authorized by this review.

Source reviewed: coherent_supervisor_candidate_v0.md and proxy_policy_observer_proposal.md (the requested correctedproxy filename did not exist; this is the corrected proposal identified in agent context).

## Mechanical properties to attack

1. **Advisory transport:** Pending z, malformed replies, missing observations, rejected advice and Task termination must never create an action/completion gate. The prototype must not expose an approval callback or a false `safe_to_finish` truth flag. A malicious model-written command or instruction cannot trigger execution. A model can still emit harmful gate-like prose; that is a semantic failure to preserve and report, not something a fixture silently repairs.
2. **Actual versus predicted:** A model prediction, prior note or memory item cannot append an actual observation, acquire host origin, satisfy its own forecast, or silently change the original task. The same string occurring in predicted and observed fields does not establish matching. Only a host-provided later event is new evidence.
3. **Time and identity:** Capture prediction before corresponding later observation; retain exact old forecast and version/run conditions after revision. Later text edits must not retroactively turn a miss into a hit. Wrong-version, not-executed, missing-library and actual content mismatch are distinct observations; semantic applicability is model-owned and unproven.
4. **Goal versus evaluator:** Original task and authorized updates stay distinct from model interpretation and evaluator output. Native test PASS cannot rewrite the original task or certify it. Interpretation remains editable after Task provides valid code evidence; do not freeze the model's initial interpretation as user intent.
5. **Exploration and rebuttal:** No-dispute must permit ordinary useful advice, and a pending dispute must allow silence/retirement. Correct partial exploration and an observed alternate implementation must not be mechanically rejected because they do not finish every requirement or match the supervisor's preferred plan.
6. **Leakage:** Hold evaluator truth in a separate test oracle. Model payloads may contain requirements and actual scoped observations, never required verdicts, desired lifecycle transitions, case-category labels, or expected output text. Scripted responses are mock behavior, not generated success. Run canary checks through actual final requests, not only input fixtures.
7. **Source capture:** Unknown or adversarial model fields cannot impersonate trusted host records. Quoted model memory stays quoted. Frozen source objects and prediction history must not alias mutable caller dictionaries. Source IDs bind records, not entailment.
8. **Calls and fallbacks:** Only the declared two stages; finite scripted backend, no network fallback/replay, errors separately logged from silence. One stage failing must not corrupt the previous state or fabricate advice delivery. No duplicate delivery after uncertain capture.

## Semantic cases, explicitly not protocol proofs

- Public density contract versus log-density self-test; protect an internal log core with valid public adapter.
- First-integer observation used for exploration versus used to claim complete decoding; preserve actual earlier full failure only for its proper artifact/version.
- Native checker PASS but known task behavior absent; native checker FAIL due to wrong expected value despite actual task sample satisfied.
- A predicted exact output ABC versus observed ABX; separate absent execution, changed artifact, and wrong test expectation.
- Supervisor says adapter absent; Task merely asserts it exists versus supplies same-version code evidence. Both inputs must be accepted; whether the model distinguishes their weight needs real-model evaluation.
- Existing file with unknown provenance is still inspectable; genuine source records can establish supplied origin without proving implementation correctness.
- Task chooses a third valid path, postpones the supervisor's proposed test, or ends with an unresolved z. No control gate; advice quality remains measurable.

## Reporting discipline

Every test result will name which property it establishes. Scripted lifecycle retention/retirement is transport compatibility only. If wrong or gate-like advice passes through, that confirms residual semantic fallibility rather than automatically constituting a mechanical failure. Reproducible source/goal mutation or forged actual observations are mechanical failures and require a fix before claiming the protocol property.
