"""New prompt-only candidate; original PMA mechanics supplied by pinned module.
No model, provider, semantic verifier, task controller, or credentials here.
"""
import copy
import hashlib
import json

COMMON = '''
Additional policy (takes precedence over a conflicting visibility-only rule):
Preserve ordinary useful memory and help. Information that is visible but is being
misapplied may merit a reminder. Mere visibility is not a reason to suppress help.
The original task and authorized updates are the goal; native evaluator scores and
local tests are imperfect observations, not replacements for that goal. Your
interpretation of the task can be wrong and can be revised without rewriting the
original instructions. Actual tool results, Task narrative, and your own previous
notes have distinct origins. A source ID does not prove an interpretation true.
Legitimate partial exploration need not satisfy the entire task at every step.
Do not invent a next action, completion claim, or missing observation. Accept valid
Task counterevidence. You may revise or withdraw your own advice or find no issue.
Task retains control of actions and completion; no pending note is an approval gate.
Use ordinary bank tools only. Keep normal progress in status and, if useful, at most
one short provisional note in that same freeform status. Replace or clear the note
when no longer useful. This is a model convention, not a host-validated schema.
'''
CANDIDATE = '''
Goal-conditioned action-consequence comparison:
Consider the observable current action and the immediate signal it seeks, including
whether it is exploration, a public behavior change, or a larger completion claim.
If that action perfectly obtained its local signal, what task-relevant consequence
would follow? Compare with a minimal compatible alternative only if a supported
constraint conflict, unjustified scope expansion, or concrete goal obstruction is
present. Incomplete coverage by itself is not a conflict. Check whether your own
interpretation is mistaken. Do not manufacture a contrast when none is useful.
When existing requirements and observations settle the difference, use them now;
do not recast known failures as unobserved or ask tests to vote on the task contract.
When an important descriptive uncertainty remains, a provisional freeform note may
state the action/object/version/conditions and expected observable consequence,
what would change the advice, and what is still unknown. It is not a fact.
On later normal wakes compare the previously recorded expectation to actual linked
actions and results, checking applicability; changed versions, blocked execution,
and faulty tests may make a result uninformative. Repeated narrative is not new
observation. A hit supports only those conditions, not the whole explanation.
Revise, withdraw, retain, or release the same note as useful. No extra investigation
call is available. A recommendation is not an executed Task action.
'''
REFLECTION = '''
Ordinary reflective review:
Think carefully about the original task, recent trajectory, relevant observations,
and the current bank. Review whether your understanding and proposed assistance
are accurate, relevant, and helpful. Check prior assumptions, uncertainty, mistakes,
and the scope of claims; consider whether another reasonable interpretation fits.
Use new evidence to reconsider old advice, retain useful context, and remove
obsolete notes. Give the Task concise useful help when needed, otherwise remain
silent. You may use the same ordinary status space for one provisional reflection.
'''
PHASE2 = '''
Choose ordinary useful help or silence using the just-committed bank and actual
trajectory. If offering a correction, state the decision-relevant difference and
compatible direction, not a command or mandatory test checklist. Do not repeat
advice the Task is already addressing. You may explicitly withdraw mistaken advice.
Return the original <context_for_action>...</context_for_action> or
<no_intervention/> format. No additional output protocol is required.
'''

def classes(module):
    class PolicyMemory(module.MemoryAgent):
        policy = ''
        async def _call_llm_phase1(self, user_prompt):
            kwargs = dict(prompt=user_prompt, system=module.PHASE1_SYSTEM + COMMON + self.policy)
            if self.use_structured_tools:
                kwargs['tools'] = module.BANK_TOOLS
            return await self.llm.call(**kwargs)
        async def _call_llm_phase2(self, user_prompt):
            return await self.llm.call(prompt=user_prompt,
                system=module.PHASE2_SYSTEM + COMMON + self.policy + PHASE2)
    class ConsequenceMemory(PolicyMemory):
        policy = CANDIDATE
    class ReflectionMemory(PolicyMemory):
        policy = REFLECTION
    return {'U': module.MemoryAgent, 'candidate': ConsequenceMemory,
            'reflection': ReflectionMemory}


def freeze(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))

class Chronology:
    """Host receipts only. Hash chain is tamper-evidence, not semantic truth/security.

    Each record is serialized immediately. Bank/response snapshots freeze any
    prediction before later observed events, without extracting or grading prose.
    No model-generated object can enter this ledger automatically.
    """
    def __init__(self):
        self._records = []
        self._requests = {}
        self._results = set()
    @property
    def records(self):
        return tuple(self._records)
    def append(self, kind, payload):
        previous = hashlib.sha256(self._records[-1].encode()).hexdigest() if self._records else None
        record = freeze(dict(seq=len(self._records), kind=kind, payload=copy.deepcopy(payload), previous=previous))
        self._records.append(record)
        return len(self._records)-1
    def task_event(self, event):
        # Validate and serialize before touching identity registries. A malformed
        # receipt must not poison a later valid receipt with the same call ID.
        event = copy.deepcopy(event)
        kind = event['kind']
        if kind in {'tool_request', 'tool_result'}:
            for field in ('call_id', 'tool'):
                if not isinstance(event.get(field), str) or not event[field].strip():
                    raise ValueError('missing transport identity: ' + field)
            for field in ('object', 'version'):
                if field not in event:
                    raise ValueError('scope must be explicit (null if unknown): ' + field)
                if event[field] is not None and (not isinstance(event[field], str) or not event[field].strip()):
                    raise ValueError('invalid scope: ' + field)
        call_id = event.get('call_id')
        if kind == 'tool_request':
            if call_id in self._requests:
                raise ValueError('duplicate call_id')
        elif kind == 'tool_result':
            if call_id not in self._requests:
                raise ValueError('orphan result')
            if call_id in self._results:
                raise ValueError('duplicate result')
            request = self._requests[call_id]
            for field in ('tool', 'object', 'version'):
                if event[field] != request[field]:
                    raise ValueError('result correlation mismatch: ' + field)
            # Null scope matches an unknown receipt, never proves version/object.
        elif kind not in {'task_text', 'task_end', 'user_update'}:
            raise ValueError('unknown host event kind')
        sequence = self.append('host_event', event)  # serialization can raise
        if kind == 'tool_request':
            self._requests[call_id] = event
        elif kind == 'tool_result':
            self._results.add(call_id)
        return sequence
    def verify(self):
        previous = None
        for index, raw in enumerate(self._records):
            row = json.loads(raw)
            if row['seq'] != index or row['previous'] != previous:
                return False
            previous = hashlib.sha256(raw.encode()).hexdigest()
        return True
