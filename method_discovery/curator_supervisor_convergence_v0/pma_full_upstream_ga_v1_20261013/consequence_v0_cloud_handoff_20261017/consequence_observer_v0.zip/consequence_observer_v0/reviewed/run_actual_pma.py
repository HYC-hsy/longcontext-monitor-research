"""Offline integration: actual pinned PMA assembly/CRUD/parser, scripted model I/O."""
import asyncio
import contextlib
import copy
import hashlib
import importlib
import io
import json
import logging
import os
from pathlib import Path
import socket
import sys
import tempfile
from types import ModuleType, SimpleNamespace

SOURCE = Path('/workspace/shared/pma_prototypes_20261015/integration/upstream/vendor/pma_89e5c0d')
EVIDENCE = Path(__file__).resolve().parents[1] / 'fixtures/generated/online_evidence.json'
PINS = {
 'src/memory_agent/memory/memory_agent.py': 'e00d412034b8cfebb6b8121477453d2815e26ce2d78344c9f7991a37048e0b35',
 'src/memory_agent/memory/universal_memory.py': 'bc816449dbdac2cb0b2d03d0e2e5af008ce9c563fcabb93d741a09d7be0bf8b0',
 'src/memory_agent/memory/bm25_search.py': '9d4169c482e3aeef11ace9d6d87dbadc015b0a1ac2d4c1906b4b0f901bbe376b',
 'src/memory_agent/memory/trigger.py': '4c9981e57ba9b28ae2da398b2d2eb8a30905bdd4b33951a827b6f60227abd16f',
 'LICENSE': 'bbbcb4cfa4a21f1f5a1dbb6941c4005c284851843849d250833af730e1d4a376',
}
PRIOR = 'SYNTHETIC_PRIOR_SENTINEL: fixture prior, not evidence.'
SAVED = 'PHASE1_SAVED_SENTINEL: scripted update, not a verified finding.'
REMINDER = 'Scripted reminder; semantic quality is not tested.'

def freeze(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False)

def response(content='', calls=()):
    return SimpleNamespace(content=content, tool_calls=list(calls))

def save_reply():
    return response(calls=[SimpleNamespace(function=SimpleNamespace(
        name='memory_save_knowledge', arguments={'content': SAVED}))])

class FakeOnly:
    """Immutable wire snapshots and errors survive exceptions swallowed by PMA."""
    def __init__(self, stages, replies):
        self.stages = tuple(stages)
        self.replies = list(replies)
        self.wire = []
        self.errors = []
        self.attempts = 0

    async def call(self, *, prompt, system, tools=None):
        index = self.attempts
        self.attempts += 1
        stage = self.stages[index] if index < len(self.stages) else 'unexpected'
        self.wire.append(freeze({'stage': stage, 'prompt': prompt, 'system': system, 'tools': tools}))
        if index >= len(self.replies):
            self.errors.append({'stage': stage, 'error': 'reply_exhausted'})
            raise RuntimeError('No scripted reply; no fallback permitted')
        item = self.replies[index]
        if isinstance(item, Exception):
            self.errors.append({'stage': stage, 'error': type(item).__name__})
            raise item
        return copy.deepcopy(item)

    def assert_complete(self):
        assert not self.errors, self.errors
        assert self.attempts == len(self.stages) == len(self.replies)

async def run_variant(module, case, variant, fault=None):
    bank = module.UniversalMemory()
    bank.save_knowledge(PRIOR)  # Original API, no injection into compiled prompts.
    initial_snapshot = freeze(bank.to_dict())
    original = {'original_task': case['requirement'], 'actual_evidence': case['evidence']}
    original_snapshot = freeze(original)
    question = 'What do the actual observations establish?'
    answer = 'Fixed auxiliary fixture answer; no semantic claim.'
    assert variant in {'A', 'B0', 'B1'}
    stages = [] if variant == 'A' else (['observer'] if variant == 'B0' else ['questioner', 'answerer'])
    replies = [] if variant == 'A' else ([response(answer)] if variant == 'B0' else [response(question), response(answer)])
    if fault == 'missing_answer':
        replies[-1] = response('')
    replies += [save_reply(), response('<context_for_action>' + REMINDER + '</context_for_action>')]
    stages += ['original_phase1', 'original_phase2']
    if fault == 'phase1_exception':
        replies[-2] = RuntimeError('Deliberate offline transport failure')
    transport = FakeOnly(stages, replies)
    if variant == 'B0':
        aux = await transport.call(prompt=original_snapshot, system='Observe original task and actual evidence only.')
    elif variant == 'B1':
        q = await transport.call(prompt=freeze({**original, 'prior_bank': bank.to_dict()}),
                                 system='Form a question about the original task and actual evidence.')
        question = q.content
        aux = await transport.call(prompt=freeze({**original, 'question': question}),
                                   system='Answer from original task and all actual evidence. Question may be biased.')
    auxiliary = None
    if variant != 'A':
        auxiliary = {'origin': 'scripted_auxiliary_model_note_not_Task_tool',
                     'status': 'available' if aux.content.strip() else 'missing_answer',
                     'content': aux.content}
        if variant == 'B1':
            auxiliary['question'] = question
    observation = original_snapshot if variant == 'A' else freeze({**original, 'auxiliary_note': auxiliary})
    observation_core = json.loads(observation)
    observation_core.pop('auxiliary_note', None)
    assert observation_core == original
    if variant == 'A':
        assert 'auxiliary_note' not in json.loads(observation)
    assert '<memory_bank>' not in observation and PRIOR not in observation
    agent = module.MemoryAgent(llm=transport, memory=bank, use_structured_tools=True)
    result = await agent.process(observation, step_count=1)
    wire_before = tuple(transport.wire)
    wire = [json.loads(item) for item in wire_before]
    phase1, phase2 = wire[-2:]
    assert transport.attempts == {'A': 2, 'B0': 3, 'B1': 4}[variant]
    assert phase1['system'] == module.PHASE1_SYSTEM and phase2['system'] == module.PHASE2_SYSTEM
    assert phase1['tools'] == module.BANK_TOOLS and phase2['tools'] is None
    for request in (phase1, phase2):
        assert request['prompt'].count('<memory_bank>') == 1
        assert request['prompt'].count(PRIOR) == 1
        assert observation in request['prompt']
    for request in ([] if variant == 'A' else ([wire[0]] if variant == 'B0' else [wire[1]])):
        projection = json.loads(request['prompt'])
        assert projection['original_task'] == original['original_task']
        assert projection['actual_evidence'] == original['actual_evidence']
        assert PRIOR not in request['prompt'] and 'prior_bank' not in projection
    if variant == 'B1':
        assert PRIOR in wire[0]['prompt']
    assert SAVED not in phase1['prompt']
    if fault != 'phase1_exception':
        transport.assert_complete()
        assert SAVED in phase2['prompt']
        assert bank.knowledge[-1].content == SAVED
        assert result.operations[0].success
    else:
        assert SAVED not in phase2['prompt']
        try:
            transport.assert_complete()
        except AssertionError:
            pass
        else:
            raise AssertionError('Swallowed error was not detected out-of-band')
    assert result.should_inject and result.context_for_action == REMINDER
    assert freeze(original) == original_snapshot
    assert PRIOR in initial_snapshot and SAVED not in initial_snapshot
    # Tampering with a decoded caller copy cannot change archived wire strings.
    wire[0]['prompt'] = 'mutated external copy'
    assert tuple(transport.wire) == wire_before
    assert transport.wire[0] != freeze(wire[0])
    return {'case_id': case['case_id'], 'variant': variant, 'fault': fault,
            'status': 'failed_transport' if transport.errors else (auxiliary['status'] if auxiliary else 'available'),
            'call_count': transport.attempts, 'requests': [json.loads(x) for x in transport.wire],
            'transport_errors': transport.errors, 'original_observation': original,
            'actual_process_observation': observation, 'initial_bank_snapshot': initial_snapshot,
            'final_bank': bank.to_dict(), 'parsed_reminder': result.context_for_action,
            'semantic_quality': 'not_tested', 'task_execution': 'not_run'}

def main():
    assert sys.flags.isolated and sys.flags.no_site, 'Run python -I -S for isolation'
    assert not any(k for k in os.environ if any(s in k.upper() for s in ('KEY', 'TOKEN', 'SECRET')))
    sys.dont_write_bytecode = True
    evidence_bytes = EVIDENCE.read_bytes()
    cases = json.loads(evidence_bytes)['cases']
    assert len(cases) == 6
    violations, imports = [], []
    with tempfile.TemporaryDirectory(prefix='pma_integration_offline_') as directory:
        root = Path(directory)
        for relative, expected in PINS.items():
            data = (SOURCE / relative).read_bytes()
            assert hashlib.sha256(data).hexdigest() == expected, relative
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        for name, path in [('memory_agent', root / 'src/memory_agent'),
                           ('memory_agent.memory', root / 'src/memory_agent/memory')]:
            assert name not in sys.modules
            package = ModuleType(name)
            package.__path__ = [str(path)]
            sys.modules[name] = package
        shim = ModuleType('shortuuid')
        counter = iter(range(1, 10000))
        shim.uuid = lambda: f'{next(counter):08d}'
        shim.__fixture_only__ = True
        sys.modules['shortuuid'] = shim
        def audit(event, args):
            blocked = event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo',
                                'socket.sendto', 'socket.sendmsg', 'subprocess.Popen',
                                'os.system', 'os.exec', 'os.posix_spawn', 'os.fork'}
            if event == 'import':
                imports.append(args[0])
                top = args[0].split('.')[0]
                blocked = top not in sys.stdlib_module_names and top not in {'memory_agent', 'shortuuid'}
            if event == 'socket.__new__':
                blocked = args[1] != socket.AF_UNIX
            if event == 'open':
                mode, flags = args[1], args[2]
                blocked = (isinstance(mode, str) and any(x in mode for x in 'wax+')) or (
                    isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)))
            if blocked:
                violations.append(event)
                raise PermissionError('offline audit blocked ' + event)
        sys.addaudithook(audit)
        module = importlib.import_module('memory_agent.memory.memory_agent')
        trigger_module = importlib.import_module('memory_agent.memory.trigger')
        importlib.import_module('memory_agent.memory.bm25_search')
        assert Path(module.__file__).resolve() == (root / 'src/memory_agent/memory/memory_agent.py').resolve()
        assert trigger_module.MemoryAgentTrigger(trigger_module.TriggerConfig(interval=1, trigger_on_first_step=True)).should_trigger(1)[0]
        constants_snapshot = freeze([module.PHASE1_SYSTEM, module.PHASE2_SYSTEM, module.BANK_TOOLS])
        captured = io.StringIO()
        async def suite():
            runs = []
            for case in cases:
                pair = [await run_variant(module, case, variant) for variant in ('A', 'B0', 'B1')]
                baseline_core = json.loads(pair[0]['actual_process_observation'])
                for run in pair:
                    projected = json.loads(run['actual_process_observation'])
                    projected.pop('auxiliary_note', None)
                    assert projected == baseline_core == run['original_observation']
                    prior = json.loads(run['initial_bank_snapshot'])
                    assert [entry['content'] for entry in prior['knowledge']] == [PRIOR]
                runs.extend(pair)
            negatives = [await run_variant(module, cases[0], 'B1', 'missing_answer'),
                         await run_variant(module, cases[0], 'B0', 'phase1_exception')]
            assert negatives[0]['status'] == 'missing_answer'
            assert negatives[1]['status'] == 'failed_transport'
            return runs, negatives
        with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
            runs, negatives = asyncio.run(suite())
        assert freeze([module.PHASE1_SYSTEM, module.PHASE2_SYSTEM, module.BANK_TOOLS]) == constants_snapshot
        assert not violations, violations
        assert not any(name.startswith(('litellm', 'openai', 'httpx', 'requests', 'pydantic', 'harbor')) for name in sys.modules)
        report = {'status': 'passed_mechanical_checks', 'source_revision': '89e5c0d',
                  'source_hashes': PINS, 'online_evidence_sha256': hashlib.sha256(evidence_bytes).hexdigest(),
                  'real_model_calls': 0, 'positive_scripted_calls': sum(x['call_count'] for x in runs),
                  'negative_scripted_calls': sum(x['call_count'] for x in negatives),
                  'per_variant_counts': {variant: {'runs': sum(x['variant'] == variant for x in runs),
                      'scripted_calls': sum(x['call_count'] for x in runs if x['variant'] == variant)}
                      for variant in ('A', 'B0', 'B1')},
                  'study_kind': 'offline scripted integration, separate from any external real-model study',
                  'source_compatibility': 'pinned 89e5c0d only; latest/GA host not established',
                  'question_leakage': 'B1 questioner sees bank. Its question can leak bank prose or bias; answer isolation is architectural only.',
                  'semantic_quality': 'not_tested', 'task_execution': 'not_run',
                  'blocked_events': violations, 'audited_imports': imports,
                  'captured_vendor_output': captured.getvalue(), 'runs': runs, 'negative_controls': negatives}
        print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
