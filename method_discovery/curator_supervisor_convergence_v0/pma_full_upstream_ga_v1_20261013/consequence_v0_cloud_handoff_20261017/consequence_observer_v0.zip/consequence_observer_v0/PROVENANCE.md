# Source and new-code boundary

## Direct runtime reuse

Repository: https://github.com/yifannnwu/proactive-memory-agent
Revision: `89e5c0d6aadfe531a1aee42fd290d48be89973dd`
License: Apache-2.0, exact LICENSE preserved in the existing vendor checkout and copied unchanged to the isolated staging directory for execution.

Read-only local source: `/workspace/shared/pma_prototypes_20261015/integration/upstream/vendor/pma_89e5c0d`.

The four Python files are copied byte-for-byte to a temporary directory, SHA-256 checked before execution:

- `src/memory_agent/memory/memory_agent.py`: `e00d412034b8cfebb6b8121477453d2815e26ce2d78344c9f7991a37048e0b35`
- `src/memory_agent/memory/universal_memory.py`: `bc816449dbdac2cb0b2d03d0e2e5af008ce9c563fcabb93d741a09d7be0bf8b0`
- `src/memory_agent/memory/bm25_search.py`: `9d4169c482e3aeef11ace9d6d87dbadc015b0a1ac2d4c1906b4b0f901bbe376b`
- `src/memory_agent/memory/trigger.py`: `4c9981e57ba9b28ae2da398b2d2eb8a30905bdd4b33951a827b6f60227abd16f`
- `LICENSE`: `bbbcb4cfa4a21f1f5a1dbb6941c4005c284851843849d250833af730e1d4a376`

`memory_agent` and `memory_agent.memory` package shells are fixture-only to avoid full package initializers. A deterministic in-memory `shortuuid` shim substitutes fixture IDs; it is not the real shortuuid distribution. No upstream package installation or provider adapter is loaded.

## Existing reviewed research code reused

`../lab/integration/run_actual_pma.py`, SHA-256 `856f00548f4e497eabf27a4783cd18820ace9441110298c7895043304db8f948`, is hash-checked and imported as a module, not executed as a main program. Directly reused: `SOURCE`, `PINS`, `freeze`, `response`, `FakeOnly`. New runner adapts its staged-package, clean-environment, audit-hook, stdout capture, and out-of-band exception-detection patterns. This local research file does not establish a separate public project license; no license beyond the original PMA source is invented here.

## Newly written in this directory

- `observer.py`: shared corrected policy, action-consequence policy, generic-reflection policy, two prompt-seam subclasses, and host chronology/correlation audit.
- `run_fake.py`: subclassed fake transport capture, configurable scenario/session runner, authored lifecycle fixtures, mechanical checks, and assembly of the reviewed execution boundary.
- `README.md`, this provenance file, and generated `results.json`/`results.stderr`.

No code or prompts copied from PCE, PoS, CRITIC, Hypothetical Minds, or other related algorithms. Their research ideas are discussed elsewhere; the executable code here is original adaptation around PMA. It is not a new independent memory implementation and not an efficacy result.
