# Goal-conditioned action-consequence observer: offline v0

## Verified result, not efficacy

The executable prototype passes its mechanical checks with **15 arm/scenario runs plus one skipped-wake run, 46 scripted transport calls, zero real model calls**. Three deliberate Phase-1 transport failures remain failures in their individual out-of-band ledgers even though original PMA catches the exceptions and continues. No Task agent ran, no suggestion was delivered to a Task, and no model reasoning or task improvement was measured. All replies and Task event sequences are authored fixtures. A scripted withdrawal demonstrates that the protocol permits withdrawal, not that a model will withdraw.

Run using the existing Python, no installation:

    PY=$(command -v python)
    env -i "$PY" -I -S /workspace/shared/deep_supervisor_20261017/consequence_v0/run_fake.py > /workspace/shared/deep_supervisor_20261017/consequence_v0/results.json 2> /workspace/shared/deep_supervisor_20261017/consequence_v0/results.stderr

## Concrete integration

`observer.classes(pinned_module)` returns:

- `U`: the original `MemoryAgent` class itself, not a replacement implementation.
- `candidate`: subclass overriding only `_call_llm_phase1` and `_call_llm_phase2` to supply the new policy.
- `reflection`: same seams, shared permission/capacity policy, ordinary reflection instead of action-consequence procedure.

All arms use original `process`, bank CRUD, bank formatting/BM25 behavior, Phase-2 parser, and trigger. No third call, extra model, custom memory tool, or Task approval/termination gate exists. The original source comments say shared conversation, but actual code makes two independent `llm.call` requests; this prototype follows the code. Phase 2 sees actual committed memory after Phase 1, not a claim that an operation succeeded.

The candidate's single transient contrast is ordinary freeform **status** text alongside ordinary progress. No schema parser or host semantic acceptance exists. Model policy permits no issue, revision, withdrawal, and release. Cardinality and brevity are prompt conventions rather than enforced properties. Original status has a 2000-character truncation limit; this is unchanged and can lose information. The full raw response is retained in the audit, but this audit is not automatically reinserted into future model inputs. The candidate may therefore lose a long prediction; no persistence benefit is claimed beyond what is actually in status/history.

Both non-U arms receive the same explicit visible-but-misused reminder permission, legitimate-partial-exploration protection, revisable goal interpretation, Task autonomy, ordinary help, and one-note status capacity. Exact observations, fake responses, wake schedules and original bank settings match across arms. U keeps its original policy. Candidate and reflection have different prompt lengths; equal call count is **not** a measured token/latency/cost match. The fixed kernel interface used here exposes no output-budget parameter; real provider budget parity is not established.

## Chronology and evidence

`Chronology` serializes host records immediately in an append-only in-process sequence with hash chaining. Original task, received host events, model request, model response, committed bank, and reminder records remain distinct. Predictions are preserved as original response/bank prose before later result events. There is no extraction of a gold issue, correctness grading, automatic matching of natural-language predictions, or machine decision that a result falsifies advice.

`task_event` mechanically correlates supplied tool results to prior supplied requests by `call_id`, tool, object, and version. Orphan, duplicate, or mismatched results raise an audit error before being appended. This protects fixture receipt integrity, not Task execution permissions; the offline harness has no Task to stop. The adapter still needs trustworthy actual Task host receipts in any future integration. A forged fixture could lie about its source. Exact correlation does not prove semantic applicability, and changes of version should use a new tool request/call ID rather than incorrectly attaching a new-version result to an old invocation.

`CapturingFake` archives the exact kwargs passed to the fake transport before returning the scripted response. It also reuses the reviewed immutable wire ledger and out-of-band error capture. This is actual fake-transport request capture, not real-provider wire capture. Snapshot/hash chaining prevents accidental historical rewrites through returned caller copies; it is not a cryptographic security boundary against code that can replace the whole ledger.

## Configurable fake harness

`run_session(module, trigger_module, variant, scenario, interval=1)` accepts a scenario dictionary with `name`, literal `goal`, `steps` (ordered host event lists), and `replies` (original-compatible reply objects or deliberate exceptions). `reply(status=..., content=..., calls=...)` constructs fixtures, not inferred judgments. `scenarios()` supplies the reproducible default set. Change fixtures in a new driver or invoke this API under the same isolated staged setup; there is no real-provider switch or fallback. Evaluation-only desired outcomes belong in external checks, never the observation packet. The default cases are development protocol fixtures, not held-out tasks.

Checks cover matching input observations and tools, untouched U systems and global constants, two calls per wake, committed status in Phase 2, frozen pre-result prediction, no future ABX in the earlier request, revision/release, silence for partial exploration, permitted rebuttal withdrawal, malformed reminder no-op, swallowed exception reporting, exact correlation rejection, and original interval=2 wake skipping. The fake model outputs are intentionally identical across arms, so differences in observed efficacy are impossible to infer from this suite.

## Safety and reuse

Only the new directory was written. No existing prototype or vendor source was changed. No credentials, private profiles, providers, native evaluations, packages, network calls, or actual task tools were used. The child runs with cleared environment and `-I -S`; after staging, its audit hook blocks writes, subprocess execution, network operations, and non-stdlib imports except staged PMA/shortuuid. Asyncio's local AF_UNIX socketpair is allowed. As in the reviewed harness, this is a trusted-code execution boundary, not a hostile-code sandbox. Temporary cleanup remains allowed.

See `PROVENANCE.md` for exact reuse. Compatibility is limited to the pinned PMA core. Live GA adaptation, actual reminder/history delivery, real provider capture/budgets, and closed-loop Task behavior remain unimplemented and unverified. Any later real calls must use the developer's existing private profile in its authorized environment; this prototype neither reads nor stores it.

## Adversarial correction round

The independent review initially found three bookkeeping defects: missing call identities were accepted; an unserializable request reserved an ID; an unserializable result consumed an ID. All three were corrected. The review's ten independent tests and the complete integration suite were rerun successfully. Original failed review output is retained by the reviewer, rather than overwritten.

A tool receipt now requires nonempty string `call_id`/`tool` and explicit `object`/`version` keys. Null object/version means unknown. Matching two nulls binds only the call identity and tool, **not** the missing object/version; no semantic applicability follows. Invalid audit input is rejected before changing the receipt registry. The host can retain raw malformed data separately, but must not pretend that it has correlated it.
