# Portable offline research prototype

Unzip anywhere. Requires Python 3.10+; tested with 3.12. No installation or model credentials. From this directory:

    PY=$(command -v python)
    env -i "$PY" -I -S run_fake.py > results.json 2> results.stderr
    env -i "$PY" -I -S review/test_adversarial_observer.py > unit_tests.txt 2>&1
    env -i "$PY" -I -S review/run_adversarial_integration.py > adversarial_results.json 2> adversarial_results.stderr

Expected: base integration 46 scripted calls; adversarial integration 76 scripted calls; 10 unit tests pass. Every call is fake. Three deliberate transport failures per integration remain explicitly failed in their own ledgers. There is no network/provider fallback.

The method draft is an original goal-conditioned action-consequence **prompt policy** inside original PMA's two phases. It asks the model to compare the consequence of a locally successful action with the original task, propose a compatible alternative when warranted, and revise a provisional note using later actual observations. A generic-reflection policy shares permissions and memory capacity. U stays the original class. The transient note uses ordinary status prose. This is executable policy plumbing, not a proven algorithm or observed improvement. See README for limits and the source documents for theory; this package is not an instruction to launch real calls.

## Exact portability change

`PORTABILITY_ADAPTER.diff` contains the complete difference from the reviewed local runner: source and reviewed-helper paths are bundle-relative. `SOURCE_HASHES.json` pins the four executed upstream Python files and LICENSE. No vendor source was edited. The original reviewed research harness is included byte-for-byte under `reviewed/`; its SHA is checked by `run_fake.py`. It has an unused historical absolute SOURCE constant and historical main function. Neither is used for portable source resolution or invoked as a program; the new runner imports only its helpers/constants and uses explicit bundle-relative `SOURCE_ROOT`. Nothing reads the original workspace paths.

Original PMA: https://github.com/yifannnwu/proactive-memory-agent at 89e5c0d6aadfe531a1aee42fd290d48be89973dd, Apache-2.0. The exact license is in vendor/pma_89e5c0d/LICENSE. The new code and existing research helper reuse boundaries are detailed in PROVENANCE.md. Four pinned Python files plus LICENSE are the complete five-file runtime source set; no additional upstream modules are needed.

## Important evidence caveat

Tool/object/version equality checks correlate host receipts only if those fields are immutable invocation metadata. A returned artifact can actually have a changed version. Do not discard that observation as if it never occurred: a future live adapter should retain the raw result and separate requested identity from observed artifact identity. This prototype only checks the fixed receipt-routing schema, not changed-version semantic interpretation. Explicit null scope remains unknown.

Real APIs, GA continuation, delivery into actual Task history, provider budget parity, and live registration are not implemented. Any future real work must use the developer's existing authorized private profile without copying secrets into this package.
