"""Fake-only two-phase integration. Run env -i python -I -S run_fake.py.
Adapted execution boundary and fake transport from lab/integration/run_actual_pma.py.
"""
import asyncio
import contextlib
import copy
import hashlib
import importlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
from types import ModuleType, SimpleNamespace

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / 'reviewed/run_actual_pma.py'
SOURCE_ROOT = ROOT / 'vendor/pma_89e5c0d'
REFERENCE_SHA256 = '856f00548f4e497eabf27a4783cd18820ace9441110298c7895043304db8f948'

def load_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

sys.dont_write_bytecode = True
assert hashlib.sha256(REFERENCE.read_bytes()).hexdigest() == REFERENCE_SHA256, 'reviewed harness changed'
ref = load_file('reviewed_integration', REFERENCE)
local = load_file('consequence_observer', ROOT / 'observer.py')

def reply(status=None, content='<no_intervention/>', calls=None):
    operations = list(calls or [])
    if status is not None:
        operations.append(SimpleNamespace(function=SimpleNamespace(
            name='memory_update_status', arguments={'content': status})))
    return ref.response(content=content, calls=operations)

class CapturingFake(ref.FakeOnly):
    def __init__(self, ledger, replies):
        super().__init__(['phase1', 'phase2'] * (len(replies)//2), replies)
        self.ledger = ledger
    async def call(self, **kwargs):
        self.ledger.append('model_request', kwargs)
        try:
            result = await super().call(**kwargs)
        except Exception as exc:
            self.ledger.append('transport_error', {'error': type(exc).__name__})
            raise
        calls = [{'name': c.function.name, 'arguments': c.function.arguments} for c in result.tool_calls]
        self.ledger.append('model_response', {'content': result.content, 'tool_calls': calls,
                                            'origin': 'scripted_fixture_not_model_behavior'})
        return result

async def run_session(module, trigger_module, variant, scenario, interval=1):
    ledger = local.Chronology()
    bank = module.UniversalMemory()
    bank.save_knowledge('Ordinary useful memory survives; synthetic fixture.')
    initial = ref.freeze(bank.to_dict())
    transport = CapturingFake(ledger, scenario['replies'])
    agent = local.classes(module)[variant](llm=transport, memory=bank)
    trigger = trigger_module.MemoryAgentTrigger(trigger_module.TriggerConfig(interval=interval))
    history, turns = [], []
    ledger.append('original_task', scenario['goal'])
    for step, events in enumerate(scenario['steps'], 1):
        for event in events:
            ledger.task_event(event)
            history.append(copy.deepcopy(event))
        observation = ref.freeze({'original_task': scenario['goal'], 'actual_history': history})
        woke, reason = trigger.should_trigger(step)
        ledger.append('wake', {'step': step, 'woke': woke, 'reason': reason})
        if not woke:
            continue
        ledger.append('bank_before', bank.to_dict())
        result = await agent.process(observation, step_count=step)
        ledger.append('bank_committed', bank.to_dict())
        ledger.append('reminder', {'content': result.context_for_action, 'should_inject': result.should_inject,
                                  'delivery': 'not_delivered_to_Task; offline fixture only'})
        turns.append({'step': step, 'observation': observation, 'status': bank.status,
                      'operations': [vars(op) for op in result.operations],
                      'reminder': result.context_for_action, 'should_inject': result.should_inject})
    assert ledger.verify()
    return {'variant': variant, 'scenario': scenario['name'], 'initial_bank': initial,
            'turns': turns, 'ledger': ledger.records, 'requests': transport.wire,
            'transport_errors': transport.errors, 'attempts': transport.attempts,
            'fake_replies_remaining': len(transport.replies)-transport.attempts,
            'final_bank': bank.to_dict(), 'semantic_quality': 'not_tested',
            'task_continuation': 'scripted_events_only', 'real_calls': 0}

def scenarios():
    goal = 'Decode the supplied complete file to ABC. Partial probes are allowed.'
    request = {'kind': 'tool_request', 'call_id': 'decode-1', 'tool': 'decode',
               'object': 'sample.bin', 'version': 'v1', 'arguments': {'mode': 'full'}}
    result = {'kind': 'tool_result', 'call_id': 'decode-1', 'tool': 'decode',
              'object': 'sample.bin', 'version': 'v1', 'returncode': 0, 'stdout': 'ABX'}
    prediction = ('PROVISIONAL: The planned full decode of sample.bin v1 may yield ABC. '
                  'A header length of 3 does not settle payload equality. Compare only '
                  'a successfully executed matching full decode; revise with its output.')
    first = [{'kind': 'task_text', 'text': 'Header length is 3. I plan full decoding next.'}]
    return [dict(name='prediction_revision_release', goal=goal,
        steps=[first, [request, result], [{'kind': 'task_end', 'text': 'Task ends with result unresolved.'}]],
        replies=[reply(status=prediction), reply(content='<context_for_action>Scripted scoped note.</context_for_action>'),
                 reply(status='REVISED: matching full decode observed ABX; old expectation not met.'), reply(),
                 reply(status='Task ended. No active provisional contrast.'), reply()]),
        dict(name='partial_exploration_no_issue', goal=goal,
        steps=[[{'kind': 'task_text', 'text': 'I am only locating the payload boundary, not claiming completion.'}]],
        replies=[reply(status='Exploration continues; no current conflict.'), reply()]),
        dict(name='valid_rebuttal_withdraw', goal='Public callback accepts density; internal log representation allowed.',
        steps=[[{'kind': 'task_text', 'text': 'The adapter performs one log conversion; internal log API is separate.'}]],
        replies=[reply(status='Withdraw prior interpretation; Task reports a separate internal API. Evidence scope remains to inspect.'), reply()]),
        dict(name='transport_failure', goal=goal, steps=[first],
        replies=[RuntimeError('deliberate fake phase1 failure'), reply()]),
        dict(name='malformed_output_no_gate', goal=goal, steps=[first],
        replies=[reply(status='Unstructured provisional prose {} malformed if treated as JSON'), reply(content='malformed output')])]

def check_report(runs, module):
    positive = [r for r in runs if r['scenario'] != 'transport_failure']
    assert all(not r['transport_errors'] and r['fake_replies_remaining'] == 0 for r in positive)
    for run in runs:
        assert run['attempts'] == len(run['turns']) * 2
        requests = [json.loads(x) for x in run['requests']]
        for i, turn in enumerate(run['turns']):
            p1, p2 = requests[i*2:i*2+2]
            assert p1['tools'] == module.BANK_TOOLS and p2['tools'] is None
            assert turn['observation'] in p1['prompt'] and turn['observation'] in p2['prompt']
            assert turn['status'] in p2['prompt']
            if run['variant'] == 'U':
                assert p1['system'] == module.PHASE1_SYSTEM and p2['system'] == module.PHASE2_SYSTEM
        if run['scenario'] == 'transport_failure':
            assert run['transport_errors'] and run['attempts'] == 2
        if run['scenario'] in {'partial_exploration_no_issue', 'malformed_output_no_gate', 'valid_rebuttal_withdraw'}:
            assert not run['turns'][0]['should_inject']
        if run['scenario'] == 'prediction_revision_release':
            rows = [json.loads(x) for x in run['ledger']]
            future = next(i for i, row in enumerate(rows) if row['kind']=='host_event' and row['payload']['kind']=='tool_result')
            frozen = [row for row in rows[:future] if row['kind']=='bank_committed']
            assert frozen and 'may yield ABC' in frozen[0]['payload']['status']
            assert 'ABX' not in requests[0]['prompt'] and 'ABX' in requests[2]['prompt']
            assert 'may yield ABC' in frozen[0]['payload']['status'] # no rewrite after revision
    for name in {r['scenario'] for r in runs}:
        group = [r for r in runs if r['scenario']==name]
        assert all([t['observation'] for t in r['turns']] == [t['observation'] for t in group[0]['turns']] for r in group)
    # Negative correlation controls must fail before appending an invalid result.
    for change in ('orphan', 'version', 'object', 'tool', 'duplicate'):
        ledger = local.Chronology()
        req = dict(kind='tool_request', call_id='c', tool='t', object='o', version='1')
        res = {**req, 'kind':'tool_result'}
        if change != 'orphan': ledger.task_event(req)
        if change in {'version','object','tool'}: res[change] = 'wrong'
        if change == 'duplicate': ledger.task_event(res)
        n = len(ledger.records)
        try: ledger.task_event(res)
        except ValueError: pass
        else: raise AssertionError('invalid correlation accepted: ' + change)
        assert len(ledger.records) == n
    # Original trigger, including skipped wake, is exercised separately.


def main():
    assert sys.flags.isolated and sys.flags.no_site, 'Use python -I -S'
    assert not any(k for k in os.environ if any(s in k.upper() for s in ('KEY','TOKEN','SECRET')))
    violations = []
    with tempfile.TemporaryDirectory(prefix='consequence_fake_') as directory:
        root = Path(directory)
        for relative, expected in ref.PINS.items():
            data = (SOURCE_ROOT / relative).read_bytes()
            assert hashlib.sha256(data).hexdigest() == expected
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        for name, path in [('memory_agent', root/'src/memory_agent'), ('memory_agent.memory', root/'src/memory_agent/memory')]:
            package = ModuleType(name); package.__path__ = [str(path)]; sys.modules[name] = package
        shim = ModuleType('shortuuid'); counter = iter(range(1,100000))
        shim.uuid = lambda: f'{next(counter):08d}'; sys.modules['shortuuid'] = shim
        def audit(event, args):
            blocked = event in {'socket.connect','socket.bind','socket.getaddrinfo','socket.sendto','socket.sendmsg','subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork'}
            if event == 'import':
                blocked = args[0].split('.')[0] not in sys.stdlib_module_names and args[0].split('.')[0] not in {'memory_agent','shortuuid'}
            if event == 'socket.__new__': blocked = args[1] != socket.AF_UNIX
            if event == 'open':
                mode, flags = args[1:3]
                blocked = (isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
            if blocked:
                violations.append(event); raise PermissionError('offline boundary: '+event)
        sys.addaudithook(audit)
        module = importlib.import_module('memory_agent.memory.memory_agent')
        trigger = importlib.import_module('memory_agent.memory.trigger')
        constants = ref.freeze([module.PHASE1_SYSTEM, module.PHASE2_SYSTEM, module.BANK_TOOLS])
        async def suite():
            runs = []
            for scenario in scenarios():
                for variant in ('U','candidate','reflection'):
                    runs.append(await run_session(module,trigger,variant,scenario))
            check_report(runs,module)
            sparse = scenarios()[0]
            sparse['replies'] = sparse['replies'][:2] + sparse['replies'][4:]
            skipped = await run_session(module,trigger,'candidate',sparse,interval=2)
            assert [t['step'] for t in skipped['turns']] == [1,3] and skipped['attempts']==4
            return runs, skipped
        logs = io.StringIO()
        with contextlib.redirect_stdout(logs), contextlib.redirect_stderr(logs):
            runs, skipped = asyncio.run(suite())
        assert constants == ref.freeze([module.PHASE1_SYSTEM,module.PHASE2_SYSTEM,module.BANK_TOOLS])
        assert not violations
        print(json.dumps(dict(status='mechanical_checks_passed', real_model_calls=0,
            semantic_efficacy='not_tested', source_hashes=ref.PINS,
            reviewed_harness_sha256=hashlib.sha256(REFERENCE.read_bytes()).hexdigest(),
            variants=['U','candidate','reflection'], runs=runs, skipped_wake_run=skipped,
            scripted_calls=sum(r['attempts'] for r in runs)+skipped['attempts'],
            blocked_events=violations, captured_vendor_logs=logs.getvalue()),indent=2))

if __name__ == '__main__': main()
