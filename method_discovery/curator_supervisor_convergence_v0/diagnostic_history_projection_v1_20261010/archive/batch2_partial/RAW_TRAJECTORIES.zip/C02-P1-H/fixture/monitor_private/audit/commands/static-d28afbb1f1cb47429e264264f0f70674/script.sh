
# Quick build check - just compile, don't run full build
cd /app && go build ./app ./theme ./data/binding ./data/validation ./widget ./driver/desktop 2>&1 | head -20
