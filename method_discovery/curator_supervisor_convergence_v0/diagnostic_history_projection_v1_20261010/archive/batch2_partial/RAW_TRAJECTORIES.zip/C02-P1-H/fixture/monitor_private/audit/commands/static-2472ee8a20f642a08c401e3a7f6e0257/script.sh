
# Final verification: check toolbar return types
cd /app && grep -n "^func NewToolbarAction\|^func NewToolbarSpacer\|^func NewToolbarSeparator" widget/toolbar.go
