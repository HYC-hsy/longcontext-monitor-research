
# Check MenuItem Icon and Shortcut fields - read more lines
cd /app && grep -A 15 "^type MenuItem struct" menu.go
