
# Verify MenuItem has Icon and Shortcut fields
cd /app && grep -A 10 "^type MenuItem struct" menu.go
