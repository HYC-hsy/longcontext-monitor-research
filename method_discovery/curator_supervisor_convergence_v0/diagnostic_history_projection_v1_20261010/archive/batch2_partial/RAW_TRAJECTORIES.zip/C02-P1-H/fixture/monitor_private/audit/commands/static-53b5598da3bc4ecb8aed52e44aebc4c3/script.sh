
# Run final build verification
cd /app && go build -v ./... 2>&1 | tail -10
