
# Search for minRowsVisible usage in internal entry renderer
cd /app && grep -r "minRowsVisible" internal/ 2>/dev/null | head -10
