
# Verify sprintf Set() implementation uses fmt.Sscanf
cd /app && grep -A 30 "func (b \*sprintfBinding) Set" data/binding/sprintf.go | head -40
