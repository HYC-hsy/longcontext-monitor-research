
# Check if minRowsVisible is used in the renderer's MinSize calculation
cd /app && find . -name "*entry*.go" -path "*/internal/*" -exec grep -l "minRowsVisible" {} \;
