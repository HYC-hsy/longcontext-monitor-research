
# Critical: Check if Hyperlink.OnTapped OVERRIDES URL opening (task says "instead of", not "in addition to")
cd /app && grep -B 5 -A 20 "OpenURL\|openURL" widget/hyperlink.go | grep -A 15 "OnTapped"
