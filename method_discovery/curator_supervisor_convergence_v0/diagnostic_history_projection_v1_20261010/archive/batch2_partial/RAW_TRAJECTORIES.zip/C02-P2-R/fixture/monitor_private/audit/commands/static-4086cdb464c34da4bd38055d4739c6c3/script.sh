
# Check Entry.SetMinRowsVisible field usage in MinSize calculation
cd /app && grep -B 5 -A 15 "minRowsVisible" widget/entry.go | head -50
