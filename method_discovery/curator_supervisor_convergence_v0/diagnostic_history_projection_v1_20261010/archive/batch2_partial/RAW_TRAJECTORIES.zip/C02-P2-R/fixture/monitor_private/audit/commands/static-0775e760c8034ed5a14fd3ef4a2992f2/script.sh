
# Check if Entry MinSize uses minRowsVisible - search internal renderer
cd /app && find internal -name "entry*.go" 2>/dev/null | xargs grep -l "MinSize" | head -3
