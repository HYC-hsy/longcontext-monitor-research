
# Check the Tapped method implementation to see if it checks OnTapped
cd /app && grep -B 3 -A 10 "func (hl \*Hyperlink) Tapped" widget/hyperlink.go
