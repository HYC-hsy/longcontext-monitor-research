
# Critical: Check if Hyperlink.openURL checks OnTapped callback
cd /app && grep -A 8 "func (hl \*Hyperlink) openURL" widget/hyperlink.go
