
# Check if Hyperlink.OnTapped overrides URL-opening (not just "in addition to")
cd /app && grep -A 15 "func (h \*Hyperlink) Tapped\|func (h \*Hyperlink) tapped" widget/hyperlink.go
