
# Check variant-specific color handling in JSON theme
cd /app && grep -A 10 "ColorsDark\|ColorsLight" theme/json.go | head -30
