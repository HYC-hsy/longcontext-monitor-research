
# Check if Entry.minRowsVisible actually affects MinSize calculation
cd /app && grep -B 3 -A 30 "func (e \*Entry) MinSize\|func (e \*entry.*) MinSize" widget/entry.go | head -50
