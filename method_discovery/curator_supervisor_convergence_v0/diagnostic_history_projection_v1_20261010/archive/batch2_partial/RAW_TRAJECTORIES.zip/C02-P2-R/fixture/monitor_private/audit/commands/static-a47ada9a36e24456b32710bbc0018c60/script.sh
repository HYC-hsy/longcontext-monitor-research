
# Verify ToolbarAction.SetIcon method exists and check return types
cd /app && grep -n "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator\|func (t \*ToolbarAction) SetIcon" widget/toolbar.go | head -10
