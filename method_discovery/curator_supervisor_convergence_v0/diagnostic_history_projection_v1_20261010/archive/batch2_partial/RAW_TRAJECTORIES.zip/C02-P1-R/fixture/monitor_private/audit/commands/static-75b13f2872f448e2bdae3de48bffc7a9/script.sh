
# Check ToolbarAction.SetIcon exists
cd /app && grep -A 5 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
