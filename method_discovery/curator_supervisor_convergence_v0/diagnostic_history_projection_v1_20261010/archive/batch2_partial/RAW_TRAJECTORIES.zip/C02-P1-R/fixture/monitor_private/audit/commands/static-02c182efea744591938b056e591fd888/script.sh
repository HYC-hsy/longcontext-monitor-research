
# Check MenuItem fields for Icon and Shortcut
cd /app && grep -A 15 "^type MenuItem struct" menu.go
