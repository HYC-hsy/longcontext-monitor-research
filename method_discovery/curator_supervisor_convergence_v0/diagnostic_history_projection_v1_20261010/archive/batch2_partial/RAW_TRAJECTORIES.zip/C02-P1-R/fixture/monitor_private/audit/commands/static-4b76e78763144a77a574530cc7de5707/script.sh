
# Verify MenuItem has Shortcut field as well
cd /app && grep -A 20 "type MenuItem struct" menu.go | grep -A 2 "Shortcut"
