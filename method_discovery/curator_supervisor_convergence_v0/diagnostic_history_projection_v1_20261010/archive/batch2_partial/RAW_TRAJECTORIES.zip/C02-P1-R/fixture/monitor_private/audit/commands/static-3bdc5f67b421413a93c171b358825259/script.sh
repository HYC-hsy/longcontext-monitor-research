
# Quick check if there were any compilation errors in the last build
cd /app && ls -lh 2>&1 | head -5
echo "---"
cd /app && go list ./... 2>&1 | head -10
