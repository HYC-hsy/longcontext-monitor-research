
# Check if Hyperlink.OnTapped overrides URL opening when set (critical behavior)
cd /app && grep -B 5 -A 25 "func (h \*Hyperlink) Tapped" widget/hyperlink.go
