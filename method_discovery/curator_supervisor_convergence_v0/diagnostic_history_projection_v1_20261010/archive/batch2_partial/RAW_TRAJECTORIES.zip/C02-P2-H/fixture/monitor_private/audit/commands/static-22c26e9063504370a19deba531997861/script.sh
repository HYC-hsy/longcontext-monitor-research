
# Quick compile check of just the modified packages
cd /app && go build -o /dev/null ./app ./theme ./data/binding ./data/validation ./widget ./driver/desktop 2>&1
echo "Exit: $?"
