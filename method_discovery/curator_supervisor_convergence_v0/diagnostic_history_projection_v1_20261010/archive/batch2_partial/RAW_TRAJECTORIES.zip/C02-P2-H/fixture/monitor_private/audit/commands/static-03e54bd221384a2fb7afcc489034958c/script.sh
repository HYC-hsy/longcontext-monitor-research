
# Final build verification
cd /app && go build ./... 2>&1 | tail -5
echo "Exit code: $?"
