
# Check toolbar return types
cd /app && grep -A 2 "^func NewToolbarAction\|^func NewToolbarSpacer\|^func NewToolbarSeparator" widget/toolbar.go
