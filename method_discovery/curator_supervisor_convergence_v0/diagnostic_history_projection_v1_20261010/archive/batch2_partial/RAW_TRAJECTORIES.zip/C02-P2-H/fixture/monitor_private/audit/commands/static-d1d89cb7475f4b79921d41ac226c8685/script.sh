
# Verify the actual behavior of Hyperlink.OnTapped vs URL opening
cd /app && grep -A 20 "func (h \*Hyperlink) Tapped" widget/hyperlink.go | head -30
