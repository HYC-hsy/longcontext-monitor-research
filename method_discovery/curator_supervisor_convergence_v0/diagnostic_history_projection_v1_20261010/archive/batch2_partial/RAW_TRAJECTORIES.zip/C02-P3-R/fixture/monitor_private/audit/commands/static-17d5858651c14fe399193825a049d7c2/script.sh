
# Search for any invocation of OnTapped callback
cd /app && grep -n "hl.OnTapped" widget/hyperlink.go
