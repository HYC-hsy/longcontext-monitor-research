
# Check the Hyperlink.Tapped implementation to see if OnTapped overrides URL opening
cd /app && grep -A 15 "func (h \*Hyperlink) Tapped" widget/hyperlink.go
