
# Check if there's a MouseDown or tap handler
cd /app && grep -B 5 -A 10 "OnTapped" widget/hyperlink.go | head -40
