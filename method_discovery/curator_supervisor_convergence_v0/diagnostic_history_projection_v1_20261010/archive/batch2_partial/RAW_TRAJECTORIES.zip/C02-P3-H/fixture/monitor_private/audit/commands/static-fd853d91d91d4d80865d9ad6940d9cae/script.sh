
# Run comprehensive build to verify compilation
cd /app && go build ./... 2>&1 | tail -20
