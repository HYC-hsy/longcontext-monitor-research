
# Get the actual function signatures
cd /app && grep -A 1 "^func NewToolbarAction\|^func NewToolbarSpacer\|^func NewToolbarSeparator\|func (t \*ToolbarAction) SetIcon" widget/toolbar.go
