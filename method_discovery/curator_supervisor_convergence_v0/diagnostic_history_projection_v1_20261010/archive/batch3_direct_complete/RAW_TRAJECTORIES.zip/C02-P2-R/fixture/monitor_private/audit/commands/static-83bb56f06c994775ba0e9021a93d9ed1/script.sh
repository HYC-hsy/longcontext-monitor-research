
# Build timed out, try a quicker check - just compile key packages
cd /app && go build -v ./app ./theme ./data/binding ./data/validation ./widget ./driver/desktop 2>&1
