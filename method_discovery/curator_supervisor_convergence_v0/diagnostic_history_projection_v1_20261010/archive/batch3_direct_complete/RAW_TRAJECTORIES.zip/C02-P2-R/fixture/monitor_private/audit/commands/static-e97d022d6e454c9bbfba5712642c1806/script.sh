
# Check for compilation errors without full build - use go list to check syntax
cd /app && go list -e -f '{{if .Error}}{{.ImportPath}}: {{.Error}}{{end}}' ./app ./theme ./data/binding ./data/validation ./widget ./driver/desktop ./test 2>&1
