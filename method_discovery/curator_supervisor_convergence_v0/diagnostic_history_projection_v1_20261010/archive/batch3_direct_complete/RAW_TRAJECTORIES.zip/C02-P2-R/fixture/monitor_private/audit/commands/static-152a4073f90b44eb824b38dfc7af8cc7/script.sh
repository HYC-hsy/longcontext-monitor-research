
# Check ToolbarAction.SetIcon and toolbar constructor return types
cd /app && grep -E "func.*ToolbarAction\.SetIcon|func NewToolbar(Action|Spacer|Separator)" widget/toolbar.go
