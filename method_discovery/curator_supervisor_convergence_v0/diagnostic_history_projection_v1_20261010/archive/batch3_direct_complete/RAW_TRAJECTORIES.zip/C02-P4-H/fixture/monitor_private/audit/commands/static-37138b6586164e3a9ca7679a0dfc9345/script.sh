
# Quick build check - just verify it compiles
cd /app && timeout 30 go build -o /tmp/fyne_test ./app 2>&1 | tail -10
echo "Exit: $?"
