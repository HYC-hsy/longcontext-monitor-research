
# Final comprehensive verification - build and check all targets
cd /app && go build ./... 2>&1 | tail -5
echo "=== Build exit code: $? ==="
