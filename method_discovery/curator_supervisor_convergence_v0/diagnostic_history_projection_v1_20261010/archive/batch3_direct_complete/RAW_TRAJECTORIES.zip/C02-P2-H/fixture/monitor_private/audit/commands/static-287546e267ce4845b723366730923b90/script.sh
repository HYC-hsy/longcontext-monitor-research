
# Verify the actual OnTapped behavior in the Tapped() handler
cd /app && grep -A 15 "func (h \*Hyperlink) Tapped" widget/hyperlink.go
