
# Check critical behavioral requirement: Hyperlink.OnTapped specification
cd /app && grep -B 1 -A 3 "OnTapped func()" widget/hyperlink.go | head -8
