
# Verify Build field exists in AppMetadata (not just Title)
cd /app && grep -A 10 "type AppMetadata struct" app.go
