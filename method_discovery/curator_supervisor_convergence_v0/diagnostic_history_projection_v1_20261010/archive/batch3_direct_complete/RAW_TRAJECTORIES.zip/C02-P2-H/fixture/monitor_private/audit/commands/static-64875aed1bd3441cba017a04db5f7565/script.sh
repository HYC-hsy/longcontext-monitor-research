
# Final verification - compile all packages to ensure no errors
cd /app && go build -v ./... 2>&1 | tail -5
echo "Exit code: $?"
