
# Check if testApp was updated with Metadata() 
cd /app && grep -A 7 "func (a \*testApp) Metadata" test/testapp.go
