
# Verify the actual function signatures
cd /app && sed -n '179,181p; 267,269p; 279,281p' widget/toolbar.go
