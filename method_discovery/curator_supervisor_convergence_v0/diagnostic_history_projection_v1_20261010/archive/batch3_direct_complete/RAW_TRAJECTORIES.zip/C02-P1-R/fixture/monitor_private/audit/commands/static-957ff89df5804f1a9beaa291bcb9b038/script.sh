
# Quick compilation check on specific modified packages
cd /app && go build -o /dev/null ./app ./theme ./data/binding ./data/validation ./widget ./driver/desktop 2>&1
