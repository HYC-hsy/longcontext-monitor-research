
# Check MenuItem.Shortcut field continuation
cd /app && grep -A 20 "type MenuItem struct" menu.go | grep -A 5 "Shortcut"
