
# Check toolbar return types and SetIcon method
cd /app && grep -n "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator\|func (t \*ToolbarAction) SetIcon" widget/toolbar.go | head -10
