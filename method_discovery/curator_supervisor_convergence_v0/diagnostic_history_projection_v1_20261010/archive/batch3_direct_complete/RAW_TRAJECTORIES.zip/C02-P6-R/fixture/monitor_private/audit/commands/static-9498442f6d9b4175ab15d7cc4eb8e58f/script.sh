
# Check MenuItem fields
cd /app && grep -A 5 "type MenuItem struct" menu.go
