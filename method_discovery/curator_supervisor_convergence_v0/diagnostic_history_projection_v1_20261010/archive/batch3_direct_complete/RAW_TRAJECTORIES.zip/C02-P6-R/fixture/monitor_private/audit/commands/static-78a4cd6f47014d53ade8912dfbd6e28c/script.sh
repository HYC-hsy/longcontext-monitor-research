
# Check full MenuItem struct for Icon and Shortcut fields
cd /app && sed -n '/type MenuItem struct/,/^}/p' menu.go
