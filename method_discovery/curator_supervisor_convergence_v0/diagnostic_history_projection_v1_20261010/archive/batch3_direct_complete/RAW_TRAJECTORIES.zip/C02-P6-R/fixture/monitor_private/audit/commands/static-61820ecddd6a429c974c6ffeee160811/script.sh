
# Check toolbar return types
cd /app && grep "func NewToolbar" widget/toolbar.go | head -5
