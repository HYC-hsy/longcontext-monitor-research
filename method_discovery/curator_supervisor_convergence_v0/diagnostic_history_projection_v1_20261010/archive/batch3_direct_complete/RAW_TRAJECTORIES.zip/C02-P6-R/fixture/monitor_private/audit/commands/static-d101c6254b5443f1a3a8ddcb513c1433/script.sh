
# Check Hyperlink.OnTapped behavior - does it override URL opening?
cd /app && grep -A 15 "func (h \*Hyperlink) Tapped" widget/hyperlink.go
