
# Check if variant-specific colors are parsed in buildThemeFromData
cd /app && grep -A 10 "ColorsDark\|ColorsLight" theme/json.go | head -25
