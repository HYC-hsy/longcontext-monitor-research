
# Verify default metadata values in app/meta.go
cd /app && cat app/meta.go
