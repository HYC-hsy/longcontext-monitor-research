
# Verify StringToStringWithFormat behavior when format is "%s"
cd /app && sed -n '/func StringToStringWithFormat/,/^}/p' data/binding/sprintf.go
