
# Check the openURL function to see if OnTapped is called
cd /app && sed -n '/func (hl \*Hyperlink) openURL/,/^}/p' widget/hyperlink.go
