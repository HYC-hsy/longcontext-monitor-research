
# Final verification: check if build succeeds
cd /app && timeout 30 go build ./... 2>&1 | tail -20
