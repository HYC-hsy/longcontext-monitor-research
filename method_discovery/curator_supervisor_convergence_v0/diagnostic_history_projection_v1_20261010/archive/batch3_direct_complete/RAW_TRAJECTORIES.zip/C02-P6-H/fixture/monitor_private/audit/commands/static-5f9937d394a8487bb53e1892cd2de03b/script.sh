
# Quick compile check on modified packages only
cd /app && go build -o /tmp/test_theme ./theme 2>&1
