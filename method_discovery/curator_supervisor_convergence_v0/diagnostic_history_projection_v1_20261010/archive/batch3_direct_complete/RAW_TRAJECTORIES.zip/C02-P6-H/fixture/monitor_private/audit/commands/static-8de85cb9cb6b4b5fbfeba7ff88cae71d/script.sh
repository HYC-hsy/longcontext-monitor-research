
# Run full build to verify no compilation errors
cd /app && go build ./... 2>&1 | tail -20
