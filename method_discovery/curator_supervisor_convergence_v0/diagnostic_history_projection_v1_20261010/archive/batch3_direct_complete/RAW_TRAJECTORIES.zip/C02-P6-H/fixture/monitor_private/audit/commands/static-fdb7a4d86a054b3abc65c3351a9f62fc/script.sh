
# Verify toolbar constructors return concrete types
cd /app && grep -n "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go
