
# Check MenuItem Icon and Shortcut fields
cd /app && grep -A 15 "type MenuItem struct" menu.go
