
# Check MenuItem Shortcut field
cd /app && grep -A 5 "Shortcut" menu.go | head -10
