
# Verify Hyperlink.OnTapped behavior - check if it's documented to replace URL opening
cd /app && grep -B 3 -A 3 "OnTapped func()" widget/hyperlink.go
