
# Check if ToolbarAction.SetIcon calls Refresh() as required
cd /app && sed -n '/^func (t \*ToolbarAction) SetIcon/,/^}/p' widget/toolbar.go
