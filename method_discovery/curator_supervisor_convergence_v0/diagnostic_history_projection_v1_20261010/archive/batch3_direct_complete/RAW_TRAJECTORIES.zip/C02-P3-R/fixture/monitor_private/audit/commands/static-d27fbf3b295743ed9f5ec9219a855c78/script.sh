
# Check if NewSprintf Set() uses fmt.Sscanf
cd /app && sed -n '/^func (b \*sprintfBinding) Set/,/^}/p' data/binding/sprintf.go | head -50
