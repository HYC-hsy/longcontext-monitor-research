
# Check ToolbarAction.SetIcon
cd /app && grep -A 4 "func (t \*ToolbarAction) SetIcon" widget/toolbar.go
