
# Check complete 8-digit case and verify error handling
cd /app && sed -n '/case 8:/,/default:/p' theme/json.go
