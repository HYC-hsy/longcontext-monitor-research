
# Check 4-digit and 6-digit hex parsing in detail
cd /app && sed -n '/case 4:/,/case 6:/p' theme/json.go | head -30
