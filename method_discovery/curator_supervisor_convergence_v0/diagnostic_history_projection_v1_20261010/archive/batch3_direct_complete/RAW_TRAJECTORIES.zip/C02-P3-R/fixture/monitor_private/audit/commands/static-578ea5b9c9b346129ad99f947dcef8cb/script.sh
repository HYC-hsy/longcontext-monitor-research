
# Check 8-digit hex and verify all cases
cd /app && sed -n '/case 6:/,/case 8:/p' theme/json.go
