
# Final check: verify the build actually succeeded
cd /app && go build ./... 2>&1 | tail -5
echo "Exit code: $?"
