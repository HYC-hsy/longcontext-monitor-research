
# Verify AppMetadata struct fields match specification exactly
cd /app && sed -n '/^type AppMetadata struct/,/^}/p' app.go
