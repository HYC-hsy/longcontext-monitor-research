
# Final comprehensive verification of all 7 targets
cd /app

echo "=== Target 1: App.Metadata() interface check ==="
grep -n "Metadata() AppMetadata" app.go

echo -e "\n=== Target 1: testApp.Metadata() implementation ==="
grep -A 3 "func (a \*testApp) Metadata" test/testapp.go

echo -e "\n=== Target 2: Hex parsing - 3 and 4 digit support ==="
grep -A 8 "case 3:" theme/json.go | head -10
grep -A 8 "case 4:" theme/json.go | head -10

echo -e "\n=== Target 3: Set() implementation with Sscanf ==="
grep -A 3 "fmt.Sscanf" data/binding/sprintf.go

echo -e "\n=== Target 4: MenuItem Icon and Shortcut fields ==="
grep -B 2 "Icon.*Resource\|Shortcut.*Shortcut" menu.go | grep -A 1 "type MenuItem"

echo -e "\n=== Target 5: Toolbar concrete return types ==="
grep "func NewToolbar" widget/toolbar.go | head -3

echo -e "\n=== Target 6: Hyperlink.OnTapped field ==="
grep -A 2 "OnTapped func()" widget/hyperlink.go

echo -e "\n=== Target 7: Both desktop.App methods ==="
grep "SetSystemTray" driver/desktop/app.go | grep "func"
