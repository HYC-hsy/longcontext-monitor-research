
# Verify MenuItem struct has Icon and Shortcut fields
cd /app && awk '/type MenuItem struct/,/^}/' menu.go
