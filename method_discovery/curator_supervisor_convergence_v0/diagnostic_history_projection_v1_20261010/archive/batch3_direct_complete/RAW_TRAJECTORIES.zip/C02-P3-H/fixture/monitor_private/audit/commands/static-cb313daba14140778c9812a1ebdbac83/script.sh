
# Check if there were any previous successful builds in the task
cd /app && grep -i "build.*success\|exit.*code.*0" /logs/agent/monitor/task_evidence/public_events.jsonl | tail -5
