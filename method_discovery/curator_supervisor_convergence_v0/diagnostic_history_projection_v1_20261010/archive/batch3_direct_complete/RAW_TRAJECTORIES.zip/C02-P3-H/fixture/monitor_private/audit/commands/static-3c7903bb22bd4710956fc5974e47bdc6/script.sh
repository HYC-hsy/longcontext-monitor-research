
# Final build verification to confirm everything compiles
cd /app && go build ./... 2>&1 | tail -20
echo "Build exit code: $?"
