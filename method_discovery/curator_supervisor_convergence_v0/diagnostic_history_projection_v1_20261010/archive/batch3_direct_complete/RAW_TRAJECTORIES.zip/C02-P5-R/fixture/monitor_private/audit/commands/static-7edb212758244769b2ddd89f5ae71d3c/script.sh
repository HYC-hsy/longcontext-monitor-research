
# Check if build was successful as claimed
cd /app && go build -v ./... 2>&1 | tail -20
