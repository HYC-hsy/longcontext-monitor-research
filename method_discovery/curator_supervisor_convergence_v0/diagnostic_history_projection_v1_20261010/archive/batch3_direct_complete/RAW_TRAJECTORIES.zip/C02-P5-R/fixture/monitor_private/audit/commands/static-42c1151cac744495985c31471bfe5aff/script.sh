
# Find the Tapped method in hyperlink
cd /app && grep -n "Tapped" widget/hyperlink.go | head -10
