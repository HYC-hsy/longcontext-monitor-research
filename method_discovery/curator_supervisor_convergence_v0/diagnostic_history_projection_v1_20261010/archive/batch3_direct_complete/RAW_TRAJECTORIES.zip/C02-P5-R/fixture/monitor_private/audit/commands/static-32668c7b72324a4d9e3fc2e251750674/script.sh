
# Check Hyperlink.OnTapped behavior - must call OnTapped INSTEAD OF opening URL when non-nil
cd /app && grep -A 15 "func (h \*Hyperlink) Tapped" widget/hyperlink.go
