
# Final build verification to confirm no compilation errors
cd /app && go build ./... 2>&1 | tail -20
echo "=== EXIT CODE: $? ==="
