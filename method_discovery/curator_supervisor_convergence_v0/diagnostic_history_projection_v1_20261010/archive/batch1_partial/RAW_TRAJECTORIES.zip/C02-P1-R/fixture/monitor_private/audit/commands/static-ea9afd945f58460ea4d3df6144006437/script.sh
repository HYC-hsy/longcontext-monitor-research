
# Check toolbar constructors return types
cd /app && grep -B 2 "func NewToolbarAction\|func NewToolbarSpacer\|func NewToolbarSeparator" widget/toolbar.go | head -20
