
# Verify MenuItem has Icon and Shortcut fields
cd /app && grep -A 3 "type MenuItem struct" menu.go
