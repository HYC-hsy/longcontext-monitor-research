
# Check if testApp has Metadata implementation
cd /app && grep -A 6 "func (a \*testApp) Metadata" test/testapp.go
