
# Check the openURL implementation to see if OnTapped is handled
cd /app && grep -A 10 "func (hl \*Hyperlink) openURL" widget/hyperlink.go
