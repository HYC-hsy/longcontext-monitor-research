
# Check Hyperlink OnTapped implementation behavior
cd /app && grep -A 20 "func (h.*Tapped\|h.OnTapped" widget/hyperlink.go | grep -A 15 "func.*Tapped"
