
# Verify critical behavioral aspects that must be present
cd /app

echo "=== Checking MenuItem Icon and Shortcut fields ==="
grep -A 2 "type MenuItem struct" menu.go | head -20

echo -e "\n=== Checking toolbar return types ==="
grep "func NewToolbar" widget/toolbar.go | head -5

echo -e "\n=== Checking Hyperlink.OnTapped behavior (should call OnTapped INSTEAD of opening URL when set) ==="
grep -B 2 -A 10 "func (h \*Hyperlink) Tapped" widget/hyperlink.go | head -15
