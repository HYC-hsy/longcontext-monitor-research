def map(g):
    """
    Transform a 2D array by creating a diagonal tiling pattern.
    
    Algorithm:
    1. Extract all unique non-zero values from input
    2. Build a dictionary mapping (i+j) % n to values found in input
    3. Fill output grid using the dictionary
    
    Args:
        g: 2D list of integers
        
    Returns:
        2D list of integers with diagonal tiling pattern
    """
    num_rows = len(g)
    num_cols = len(g[0]) if num_rows > 0 else 0
    
    # Find unique non-zero values
    unique_values = set()
    for i in range(num_rows):
        for j in range(num_cols):
            if g[i][j] != 0:
                unique_values.add(g[i][j])
    
    n = len(unique_values)
    
    # Handle edge case: all zeros
    if n == 0:
        return [[0] * num_cols for _ in range(num_rows)]
    
    # Build dictionary: map (i+j) % n to the value found at that diagonal
    d = {}
    for i in range(num_rows):
        for j in range(num_cols):
            if g[i][j] != 0:
                key = (i + j) % n
                d[key] = g[i][j]
    
    # Build result using the dictionary
    result = []
    for i in range(num_rows):
        row = []
        for j in range(num_cols):
            key = (i + j) % n
            row.append(d.get(key, 0))
        result.append(row)
    
    return result
