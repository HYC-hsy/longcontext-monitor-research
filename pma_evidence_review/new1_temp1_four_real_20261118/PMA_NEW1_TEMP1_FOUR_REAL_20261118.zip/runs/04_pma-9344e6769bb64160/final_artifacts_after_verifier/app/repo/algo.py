def map(g):
    """
    Maps a 2D integer array by extracting non-zero values and 
    creating a repeating pattern based on (i+j) % 3.
    """
    num_rows = len(g)
    num_cols = len(g[0])
    d = {}
    
    # Scan input grid and build key-value mapping
    # Key is (i+j) % 3, value is the non-zero cell value
    for i in range(num_rows):
        for j in range(num_cols):
            c = g[i][j]
            if c != 0:  # Only map non-zero values
                key = (i + j) % 3
                d[key] = c
    
    # Fill output grid using the mapping
    result = []
    for i in range(num_rows):
        row = []
        for j in range(num_cols):
            value = d.get((i + j) % 3, 0)
            row.append(value)
        result.append(row)
    
    return result
