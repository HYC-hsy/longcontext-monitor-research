# External-memory temperature-1 two-run archive

Execution 1a8a18c9d524f4ac98992dda1494ac53f3d402f1; base c7bb1941222955980539d5290511242dd1800c39. Dataset 2fd12b88aafdd04a52c298e3940bcb189f9766d6; Harbor 459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc.

This is a redacted visible projection, not raw HTTP bytes or a restorable private runtime. The four original CTRF and native test stdout files remain local because they may disclose hidden tests. Their paths, sizes and hashes are in the external index. Task final code/CSV files are captured before native evaluation and independently read back after evaluation; the identities matched. Hidden provider thinking/signatures, credentials, endpoints and private profile contents are excluded.
