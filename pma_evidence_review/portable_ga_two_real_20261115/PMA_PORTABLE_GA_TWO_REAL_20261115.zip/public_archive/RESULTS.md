# Run results

| Task | run_id | Task steps | Manager wakes | Read/add calls | Reminders sent | Native tests | Reward | Cleanup |
| --- | --- | ---: | ---: | --- | ---: | --- | ---: | --- |
| rstan-to-pystan | pma-30a25a49a0c24fc1 | 43 | 11 | 13/15 | 5 | 5/6 | 0.0 | True |
| reshard-c4-data | pma-1599ae59394e47ae | 22 | 6 | 4/8 | 0 | 0/1 | 0.0 | True |

Counts are observed records, not a semantic-effect judgment.
