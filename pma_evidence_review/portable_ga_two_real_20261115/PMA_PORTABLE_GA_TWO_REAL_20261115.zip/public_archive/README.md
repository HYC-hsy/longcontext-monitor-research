# Portable GA input: two real tasks

Execution: `6575d8497e7b0e4da31804c2860f34405852588a`. Dataset: `2fd12b88aafdd04a52c298e3940bcb189f9766d6`. Harbor: `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`.

One fresh episode per task, in rstan-to-pystan then reshard-c4-data order. Each completed native evaluation and owned-resource cleanup. No retry or method change.

This ZIP is a redacted visible projection, not raw HTTP bytes or a restorable private runtime. Source hashes in the external index refer to local originals. Excluded: credentials, private endpoints/profiles, provider-private thinking and signatures, hidden verifier bodies and runtime source bundles. If an embedded raw provider block contains private material, that response section is excluded and the structured visible counterpart is retained.
