"""Build a visible, redacted two-task archive without changing run originals."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(r"E:\LongContext\_pma_portable_ga_6575_20261115")
DEST = ROOT / "public_archive"
STEM = "PMA_PORTABLE_GA_TWO_REAL_20261115"
EXECUTION_SHA = "6575d8497e7b0e4da31804c2860f34405852588a"
DATASET_SHA = "2fd12b88aafdd04a52c298e3940bcb189f9766d6"
HARBOR_SHA = "459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc"
LABELS = ("01-rstan-to-pystan", "02-reshard-c4-data")

spec = importlib.util.spec_from_file_location(
    "previous_projector",
    Path(r"E:\LongContext\_pma_prompt_guided_20261114\build_public.py"),
)
previous = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(previous)
previous.ROOT = ROOT
previous.DEST = DEST
previous.STEM = STEM
previous.SHA = EXECUTION_SHA
previous.LABELS = LABELS

PRIVATE_IN_RAW = re.compile(
    r"ThinkingBlock\(|RedactedThinkingBlock\(|(?i:\b(?:thinking|signature)\s*=)|"
    r"(?i:[\"'](?:thinking|signature)[\"']\s*:)",
)
RESPONSE_SECTION = re.compile(
    r"=== Response ===\n.*?(?=\n\n=== Prompt ===|\Z)", re.DOTALL
)
SECRET_BYTES = (
    re.compile(rb"sk-[A-Za-z0-9_-]{12,}"),
    re.compile(rb"(?i)Bearer\s+[A-Za-z0-9._-]{12,}"),
    re.compile(rb"(?i)cc-vibe\.com"),
    re.compile(rb"ThinkingBlock\(|RedactedThinkingBlock\("),
    re.compile(rb'(?i)["\x27](?:thinking|signature)["\x27]\s*:\s*["\x27](?!\[EXCLUDED_)'),
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def run_slots():
    for label in LABELS:
        slot = ROOT / "prepared_host" / label
        item = json.loads((slot / "selection_result.json").read_text(encoding="utf-8"))["slots"][0]
        arm = item["result"]["arm"]
        if arm["disposition"] != "completed" or arm["status"]["cleanup_confirmed"] is not True:
            raise RuntimeError(f"run or cleanup incomplete: {label}")
        if arm["status"]["native_result"] is None:
            raise RuntimeError(f"native evaluation missing: {label}")
        run = next(slot.glob(f"*/runs/{arm['run_id']}"), None)
        if run is None:
            raise RuntimeError(f"missing run directory: {label}")
        yield label, slot, item, arm, run


previous.run_slots = run_slots


def safe_embedded(text: str) -> str:
    if not PRIVATE_IN_RAW.search(text):
        return text

    def replace_section(match: re.Match[str]) -> str:
        section = match.group(0)
        if PRIVATE_IN_RAW.search(section):
            return "=== Response ===\n[PRIVATE_PROVIDER_BLOCKS_EXCLUDED; visible response is in structured Task records]"
        return section

    projected = RESPONSE_SECTION.sub(replace_section, text)
    if PRIVATE_IN_RAW.search(projected):
        return "[PRIVATE_RAW_FIELD_EXCLUDED; visible counterpart retained in structured records]"
    return projected


def safe_value(value):
    value = previous.project(value)
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if str(key).lower() in {"log_response", "raw_response"} and isinstance(item, str):
                result[key] = safe_embedded(item)
            else:
                result[key] = safe_value(item)
        return result
    if isinstance(value, list):
        return [safe_value(item) for item in value]
    if isinstance(value, str):
        return safe_embedded(value)
    return value


def projection(path: Path) -> bytes:
    raw = path.read_text(encoding="utf-8-sig", errors="replace")
    if path.suffix == ".jsonl":
        output = "\n".join(
            json.dumps(safe_value(json.loads(line)), ensure_ascii=False, separators=(",", ":"))
            for line in raw.splitlines() if line
        ) + "\n"
    elif path.suffix == ".json":
        output = json.dumps(safe_value(json.loads(raw)), ensure_ascii=False, indent=2) + "\n"
    else:
        output = safe_embedded(previous.clean_string(raw))
    return output.encode("utf-8")


def main() -> None:
    DEST.mkdir(exist_ok=True)
    archive_path = DEST / f"{STEM}.zip"
    index_path = DEST / f"{STEM}.index.json"
    if archive_path.exists() or index_path.exists():
        raise RuntimeError("archive already exists; originals and previous output are not overwritten")

    facts = previous.make_facts()
    (DEST / "README.md").write_text(
        "# Portable GA input: two real tasks\n\n"
        f"Execution: `{EXECUTION_SHA}`. Dataset: `{DATASET_SHA}`. Harbor: `{HARBOR_SHA}`.\n\n"
        "One fresh episode per task, in rstan-to-pystan then reshard-c4-data order. "
        "Each completed native evaluation and owned-resource cleanup. No retry or method change.\n\n"
        "This ZIP is a redacted visible projection, not raw HTTP bytes or a restorable "
        "private runtime. Source hashes in the external index refer to local originals. "
        "Excluded: credentials, private endpoints/profiles, provider-private thinking "
        "and signatures, hidden verifier bodies and runtime source bundles. "
        "If an embedded raw provider block contains private material, that response "
        "section is excluded and the structured visible counterpart is retained.\n",
        encoding="utf-8",
    )
    table = [
        "# Run results", "",
        "| Task | run_id | Task steps | Manager wakes | Read/add calls | Reminders sent | Native tests | Reward | Cleanup |",
        "| --- | --- | ---: | ---: | --- | ---: | --- | ---: | --- |",
    ]
    for row in facts:
        tests = row["native_test_counts"]
        calls = row["memory_tool_calls"]
        table.append(
            f"| {row['task']} | {row['run_id']} | {row['task_actor_steps']} | "
            f"{row['memory_wakes']} | {calls.get('memory_read', 0)}/{calls.get('memory_add', 0)} | "
            f"{row['reminders_sent']} | {tests.get('passed')}/{tests.get('tests')} | "
            f"{row['native_reward']} | {row['cleanup_confirmed']} |"
        )
    table.extend(["", "Counts are observed records, not a semantic-effect judgment.", ""])
    (DEST / "RESULTS.md").write_text("\n".join(table), encoding="utf-8")

    files = [path for path in dict.fromkeys(previous.selected_files())
             if path.is_file() and path.is_relative_to(ROOT)]
    files.extend(path for path in (ROOT / "build_public_archive.py", ROOT / "offline_check.log") if path.is_file())
    records = []
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            original = path.read_bytes()
            public = projection(path)
            member = path.relative_to(ROOT).as_posix()
            if member in archive.namelist():
                raise RuntimeError(f"duplicate member: {member}")
            if any(pattern.search(public) for pattern in SECRET_BYTES):
                raise RuntimeError(f"potential private material in {member}")
            archive.writestr(member, public)
            records.append({
                "path": member,
                "source_sha256": digest(original), "source_bytes": len(original),
                "public_sha256": digest(public), "public_bytes": len(public),
                "projection": "redacted-visible-projection",
            })
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC check failed")
        for record in records:
            data = archive.read(record["path"])
            if len(data) != record["public_bytes"] or digest(data) != record["public_sha256"]:
                raise RuntimeError(f"ZIP member hash mismatch: {record['path']}")
    index = {
        "schema": "pma-portable-ga-visible-index-v1",
        "execution_sha": EXECUTION_SHA, "dataset_sha": DATASET_SHA,
        "harbor_sha": HARBOR_SHA,
        "runs": [{"task": row["task"], "run_id": row["run_id"]} for row in facts],
        "zip": archive_path.name, "zip_bytes": archive_path.stat().st_size,
        "zip_sha256": digest(archive_path.read_bytes()), "crc": "ok",
        "files": records,
    }
    index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"zip_bytes": index["zip_bytes"], "zip_sha256": index["zip_sha256"], "members": len(records)}))


if __name__ == "__main__":
    main()
