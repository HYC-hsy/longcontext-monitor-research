# bee280 two complete task runs

Financial then RStan, each once, native evaluation and cleanup. Full redacted visible Task and manager records are organized by run. This is a projection, not raw HTTP bytes. Provider response originals, private profiles, credentials, private thinking/signatures, and hidden verifier bodies remain local.
