# Financial afb one-task diagnostic

One complete Task, native evaluation, and cleanup. This is a redacted visible projection, not raw HTTP bytes. Credentials, private profiles/endpoints, provider-private thinking/signatures, and hidden verifier bodies are excluded; private originals remain local.
