# Slot results

- rstan-to-pystan: `pma-75f2409660a64010`; started, engineering stop; Task terminal unknown; native evaluation not run; no reward; run cleanup unconfirmed at stop, orphaned owned volume subsequently removed.
- merge-diff-arc-agi-task: not started; no Task/PMA calls or evaluation.

See `failure_summary.json` and the complete visible records in the ZIP.
