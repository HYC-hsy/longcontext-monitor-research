# First real evidence-first audit: private analysis notes

Scope: only the frozen SQLite C14 and HTML C2 development packets. These notes use the packet, captured visible responses, and reports. They do not use later Task behavior, rewards, hidden tests, or a semantic gold label. No model material was changed between the two runs.

## SQLite C14

The extractor produced 14 claims across all three operations (9 status, 1 deletion, 4 procedural); coverage marked every operation complete, but that flag is a model assertion. All 15 calls returned. Report: 13 supported, 1 insufficient, 0 contradicted, 0 item engineering failures.

- Claim 13 correctly marked the broader assertion that the PATH approach works across sessions `insufficient`: the visible verification script first ran `export PATH="/app/bin:$PATH"` and then `which sqlite3`/`sqlite3 --version` in that same session. There is no visible independent-shell test in this frozen packet. The report's explanation explicitly preserves that limitation; it does not prove the cross-session setup fails.
- Yet claims 9 (`system-wide` accessibility), 10 (deleting the system-wide PATH gap), and 1 (`Task completed successfully`) were all marked `supported` from the same current-session result and profile.d script creation. Claim 1 says all task requirements were met. These broad decisions conflict with the narrower insufficiency on claim 13 and are overconfident relative to the cited evidence.
- Claim 3, that compilation used the pre-vendored tarball, was marked supported using the task instruction plus derived memory. Its explanation concedes that the actual extraction command receipt was not visible in this packet. An instruction to use a source and a derivative summary are not independent evidence of actual use. This is a second concrete over-support case within the frozen visibility boundary.
- Claims about a symlink, installed files and `.gcno` presence cited tool observations. These are more local claims than cross-session PATH availability. The reviewed report includes tool command and observation roles; having an exact quote does not make an interpretation correct.

## HTML C2

The extractor produced 17 claims across all four operations (6 status, 1 deletion, 4 gap, 6 procedural); no nonfactual claim kind, condition, or dependency was emitted. All 18 calls returned. Report: 14 supported, 1 insufficient, 2 null due to `evidence_not_bound`, 0 contradicted. Top-level errors were empty; the two item-level engineering failures must not be counted as supported.

- Claim 7 supported deletion of the narrow `file not yet created` gap using the `file_write` command and success receipt (`5216` bytes). That only supports file creation, not functional correctness.
- Claims 3–5 and related procedural claims treated regex definitions in the written script as support for removal behavior and for a `comprehensive` on-attribute list. The frozen period has a successful write receipt, but no execution/behavioral test. This supports a narrower claim that code was written with these patterns; it does not independently establish that every relevant input is filtered or that the list is complete.
- Claim 11 about numerous other potential vectors was `insufficient`. The current visible code's absence of handlers is suggestive but is not a full verified negative across all listed vectors. The extractor bundled many distinct vectors into one claim, so this single verdict cannot assess each one separately.
- For claims 6 (`awaiting verification`) and 17 (`preserves formatting`), the verifier tried to cite the memory operation text itself as proof and returned a raw supported reason. The locator found no corresponding visible source, so the final verdict correctly remained null with `evidence_not_bound`. This is a useful engineering separation, not a successful semantic audit. The `awaiting verification` status was classified as a factual claim rather than an explicit plan/hypothesis/question.

## Shared limits

Both packets validate as `exact_public_prompt` while retaining explicit historical omission markers. All operations have at least one extracted claim; that does not independently prove extraction completeness. No explicit `conditions` or `dependencies` were emitted, even for the SQLite cross-session scope. The outputs are first real model behaviors on two previously discussed development samples, without a baseline or holdout. They do not estimate accuracy or comparative improvement.

Client-boundary logical calls were 15 and 18. Native HTTP attempts/retries, provider usage tokens, per-call latency, and dollar cost were not captured by this standalone transport. File creation-to-report modification spans were approximately 158.3 and 131.0 seconds; these are filesystem timing proxies, not provider latency measurements. All private originals and SHA-256 mappings are recorded in `PRIVATE_INDEX.json`. No Task, official evaluator, online memory write, curator retry, or judge was invoked.
