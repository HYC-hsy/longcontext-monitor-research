OFFLINE ENGINEERING ACCEPTANCE, NOT MODEL DIAGNOSIS.
Only synthetic raw inputs/responses; public sample summary has hashes/readiness, no new raw excerpts.
Model projection is quote-only; host provenance is synthetic and is never sent.
