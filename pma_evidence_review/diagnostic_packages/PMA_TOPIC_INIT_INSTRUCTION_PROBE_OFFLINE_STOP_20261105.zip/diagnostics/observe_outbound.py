"""Read-only digest capture at httpx.AsyncClient.send; never log endpoint or headers."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys

import httpx

capture_path = Path(os.environ['PMA_OUTBOUND_CAPTURE_PATH'])
script = sys.argv[1]
script_args = sys.argv[2:]
records = []
original_send = httpx.AsyncClient.send

def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def text_of(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        chunks = [item.get('text') for item in value if isinstance(item, dict) and isinstance(item.get('text'), str)]
        return ''.join(chunks) if chunks else None
    if isinstance(value, dict) and isinstance(value.get('text'), str):
        return value['text']
    return None

async def observed_send(self, request, *args, **kwargs):
    try:
        body = json.loads(request.content)
        if isinstance(body, dict):
            messages = body.get('messages')
            messages = messages if isinstance(messages, list) else []
            system_roles = [item for item in messages if isinstance(item, dict) and item.get('role') == 'system']
            user_roles = [item for item in messages if isinstance(item, dict) and item.get('role') == 'user']
            system_text = text_of(body.get('system'))
            if system_text is None and system_roles:
                system_text = text_of(system_roles[-1].get('content'))
            user_text = text_of(user_roles[-1].get('content')) if user_roles else None
            tools = body.get('tools')
            tools = tools if isinstance(tools, list) else []
            names = []
            for item in tools:
                if isinstance(item, dict):
                    fn = item.get('function')
                    names.append(item.get('name') or (fn.get('name') if isinstance(fn, dict) else None))
            records.append({'stage':'httpx.AsyncClient.send',
                            'system_field_present':'system' in body,
                            'system_role_present':bool(system_roles),
                            'system_text_sha256':digest(system_text) if system_text is not None else None,
                            'user_role_present':bool(user_roles),
                            'user_text_sha256':digest(user_text) if user_text is not None else None,
                            'tool_names':names,
                            'capture_status':'parsed_json'})
    except Exception as exc:
        records.append({'stage':'httpx.AsyncClient.send','capture_status':'unavailable',
                        'capture_error_type':type(exc).__name__})
    return await original_send(self, request, *args, **kwargs)

httpx.AsyncClient.send = observed_send
try:
    sys.argv = [script, *script_args]
    runpy.run_path(script, run_name='__main__')
finally:
    capture_path.write_text(json.dumps({'schema':'read-only-outbound-hashes-v1','records':records},
                                       ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
