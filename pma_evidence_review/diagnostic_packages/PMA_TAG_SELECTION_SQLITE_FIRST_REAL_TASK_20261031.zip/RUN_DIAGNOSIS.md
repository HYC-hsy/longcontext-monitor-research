# Tag selection: first complete SQLite episode

Production code: `48babf4302563bbe6e8f0d47e8c617d041a392b1`.
Task: `sqlite-with-gcov`; method `pma-gap-evidence`, gate `gate-one-repair`,
review strategy `claim-split-same-evidence-v4`. The task and PMA profiles,
effective model parameters, `uncapped/uncapped/official` runtime policy, and
`persistent_bundle_v1` SQLite evaluation cache were reused from the prior
successful SQLite setup. Private profile content is excluded from this package.

The new-method run `pma-d20b47d2d9684daa` completed normally. Phase 1 made
25 proposed operations, 14 committed; the citation gate recorded 32 split,
32 grouped-review and 17 repair logical requests. These are logical client
calls, not an HTTP-attempt count. All 13 phase-2 responses were bare
`<no_intervention/>`, formally parsed as deliberate silence. There were zero
selection errors, zero delivery errors and zero Task reminder injections.
Thus the full Task did not exercise the positive reminder-delivery path.

Native evaluation executed: 3 tests, 0 passed, 3 failed; reward `0.0`.
Worker and Harbor returned 0, task end was saved, and owned containers,
sidecar and model-channel volume were confirmed clean. The score alone does
not isolate selection quality, phase-1 memory quality, or Task execution.

Before the user's scope change, the old synthetic-reminder baseline had
already started as `pma-ff02c3fe780743c8` and reached four actor attempts.
It was interrupted when the user requested new-method-only execution.
It has no native evaluation or reward; its private partial record was
retained, and the run-owned residual volume was removed after confirming
no run-owned containers remained. It is **not** a completed control episode
and is not included in the semantic comparison or this public Task package.

Separately, the real-client selector-only smoke made two phase-2 requests
using the existing PMA profile. The needed-reminder scene produced a valid
`<intervene>TASK,M1</intervene>`; the production parser accepted it, and the
prepared (not sent) Task request decoded to exactly the frozen catalogue
content. The quiet scene produced a valid `<no_intervention/>`. The smoke
did not run the Task or evaluator and does not establish semantic quality.
Its first string-substring check was a false negative because JSON escaped
the newline; a read-only decoded-payload check confirmed exact content
without another model request.

The public ZIP is a visible-data projection, not raw HTTP bytes. It excludes
profiles, private client logs, hidden reasoning, hidden verifier assertions
and secret endpoints. Per-file source/public hashes allow mapping to private
originals kept on this machine. The archived old 17 JSON-protocol errors
remain unmodified and are not retroactively counted as successes.
