# Split batch v2 targeted offline acceptance

- Fixed tested code: `8c5f6ee0a9d64db39cee82df686bbf616f8e5ff3`.
- Independent detached worktree: `E:\pmasplitv2a29`; production source unchanged.
- Python: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe` (3.13.14); `regex` 2026.9.29.
- Targeted `test_split_protocol_v2`: 8 passed, 0 failed/skipped. Raw stdout and stderr are included.
- Historical ZIP source: public commit `c40f191878d1c45afccba4098ba4a16c14129c2f`, `PMA_CLAIM_SPLIT_EIGHT_REAL_TASKS_20261029.zip`, 103996503 bytes, SHA-256 `a30ff99e694d645a507c1841c33960765cb3bd0baceb17369118a43855b76e25`. The old ZIP is not duplicated in this package; `REPLAY_INDEX.json` maps each historical attempt to that source.
- Read-only replay: 108 attempts; 71 eligible for a batch but without historical batch output, 35 archived batch outputs parse under v2, 2 still fail. Parsing does not retroactively approve a historical write or establish semantic correctness.
- `sqlite_call_19` direct/v2 exported plans have the same `input_sha256`, exact original operation, submitted evidence ordering/content and empty normative context. Export includes only the initial request; the batch is constructed after a valid split.
- V2 fake recorded one `citation_claim_split` request and one `citation_claim_verify_batch` request, two synthetic responses, `client_calls=2`, `network_calls=0`, `memory_mutated=false`. It tests protocol wiring only.
- Not executed: all 352 full regressions, Docker/Harbor lifecycle certification, real model, Task and official evaluation. These were explicitly outside this acceptance scope.
- Initial Git HTTPS fetches failed at TLS connection; a per-command `http.sslBackend=schannel` fetch succeeded. No global Git setting was changed.
- No profile, authorization, private client, credential or unrelated personal file is in this package. The historical source ZIP remains at its existing public commit.
