# PMA upstream compatibility: Windows offline acceptance

- Checkout: `8b7a87021c5cf033daa2cd92b4ff20e1b8b3feed`, detached, clean, created with `core.autocrlf=false`. The delivery's `SOURCE_IDENTITY.json` names earlier source commit `5920dd0d1fa6131d2aa07cfd173e39714577e783`; the later fixed commit changes seven delivery-document files and no runtime source files. The byte verifier passed on the actual fixed checkout.
- Interpreter: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, Python 3.13.14. `dirhash` 0.5.0, `litellm` 1.86.2, `pydantic` 2.12.5, `httpx` 0.28.1; Git 2.49.0.windows.1. These are the actual local versions, not the delivery author's Python 3.12 / newer LiteLLM-Pydantic environment. No software was installed or upgraded.
- Strict imports: `PMA_TEST_STRICT_IMPORTS=1`. The 207 tests ran from this checkout and imported the pinned PMA/vendor Harbor under this checkout. No dependency substitutes or fake import modules were injected; the LLMs in the test suite are fake clients by design.
- Byte/source identity: `identity.exit.txt` is 0; `identity.stdout.txt` reports 113 manifest files and 69 runtime files matched, with no failures.
- `identity.stdout.txt` is the untouched UTF-16LE capture produced by Windows PowerShell redirection; `strict-native.*` uses direct process stream redirection. The package preserves each file's captured bytes and records its hash.
- Strict suite: `strict-native.exit.txt` is 0. `strict-report.json` records 207 tests, 207 distinct IDs, zero failures/errors/skips. Complete captured terminal streams are `strict-native.stdout.txt` and `strict-native.stderr.txt`.

## Behavior covered by this offline acceptance

- `test_prompts_keep_entire_original_system_and_only_feature_appendices` checks that P1/P2 systems begin with upstream PMA phase systems while GAP, requirements and optional P2 browse/source additions remain.
- `test_three_archived_visible_outputs_match_original_pma_extraction` uses the three frozen visible responses in `pma_p2_three_visible_outputs.json`, verifies each text hash, compares actual delivery with the upstream PMA parser and retains the original visible output. The delivery's `REPLAY_RESULTS.json` records two no-intervention extractions and one intervention; this is protocol replay, not factual correctness.
- `test_conflicts_are_logged_before_classification_and_execute_no_tools` and the Task-adapter conflict test cover multiple/conflicting decision tags and tool/final-output mixtures: no tool is executed and `selection_error` is recorded, not a normal silence.
- Provider and read-tool error tests preserve error class, attempts and prior committed P1 records; corrupt source/bank, dirty or running cycles and state-validation failures remain fail-stop rather than being recoded as a model no-op.
- `test_original_task_plus_eight_steps_is_query_and_raw_history_stays_visible` checks the full original task and recent eight visible steps without re-ingesting old wrappers. The Task-adapter fake test checks that a returned reminder can be appended to a constructed next Task request; it explicitly marks the host return `returned_not_confirmed_in_ga_request`. No actual Task provider request was sent in this acceptance.
- The Task adapter's internal failure paths were exercised with fake events. The separate serial launcher used in the earlier real attempt checked `task_terminal.result` and stopped before the second slot on `EXCEPTION`; no new multi-slot run was launched in this acceptance.

## Command-capture incident and limits

The first strict-suite invocation used PowerShell `ErrorActionPreference=Stop`; a LiteLLM optional-Bedrock import warning on native stderr caused PowerShell to abort the wrapper before it recorded a child exit code. `strict.stdout.txt` and `strict.stderr.txt` were created empty. No test result is claimed for that interrupted wrapper. The same fixed code and dependencies were then run once via `Start-Process` with independent raw stdout/stderr capture; that run produced the complete 207-test result above.

No real profile, model, Task, native evaluation, or old-method comparison was run. This verifies engineering behavior only, not real-model adherence, reminder utility or task outcome. No production source was modified in the acceptance worktree.
