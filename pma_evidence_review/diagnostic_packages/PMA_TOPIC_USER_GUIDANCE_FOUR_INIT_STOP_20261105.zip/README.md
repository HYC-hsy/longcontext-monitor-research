# Topic user-guidance initialization: stopped offline

This package records the attempted four-task offline acceptance for execution code `2683b68b8724fc62672dd22ba542e8244d0e59da` on 2026-11-05. It is a diagnostic of an early stop, **not** a completed initialization experiment.

## Fixed identity

- Repository: `HYC-hsy/longcontext-monitor-research`
- Code branch: `pma/topic-user-guidance-experiment`
- Code checkout: `2683b68b8724fc62672dd22ba542e8244d0e59da`; clean before and after the attempt
- Dataset checkout: `2fd12b88aafdd04a52c298e3940bcb189f9766d6`
- Native Harbor checkout: `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`
- Python: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, version 3.13.14
- Script: `pma_evidence_review/topic_suffix_experiment/run_suffix_init.py`, SHA-256 `64d7917eb97d781af7b9321dcfa08e3c01994d8567730c2632193243ab43b4b3`
- Existing `claude_monitor_opus48` profile key was found, but the offline attempt did not load the profile.

## Attempt and stop

The script was invoked once in `offline` mode with `--task-ids mcmc-sampling-stan rstan-to-pystan nginx-request-logging reshard-c4-data`, in that script's frozen order. Environment variables `PMA_CODE_DIR`, `PMA_HARBOR_DIR`, `PMA_DATASET_DIR`, and `PMA_CODE_SHA` pointed to the identities above; UTF-8 and no-bytecode settings were enabled. The exit code was 1. Full stdout and stderr are under `logs/`.

Import failed with `ModuleNotFoundError: No module named 'pma_evidence_review'` before the script loaded tasks, created the offline output directory, or ran request assertions. The likely launch-path issue was not corrected in this fixed attempt because the instruction required stopping on offline failure. No real mode was started; no real model, maintenance, P2, Task, or native evaluation call occurred. Logical initialization calls: 0 for each task. Actual HTTP attempts: 0 from this script.

The four `frozen_raw_instructions/*.md` files are byte-for-byte copies of public dataset `instruction.md` files for source traceability. They are **not** Harbor-loaded task strings or actual model requests. No `input_index.json`, `source_identity.json`, `offline_report.json`, per-task request/response, topics, usage, or real summary was produced. Those materials are absent, not replaced by hashes or summaries.

This package contains only public source task text, a diagnostic statement, and exact command logs. It contains no profile, credential, private endpoint, or hidden model reasoning. The source task files and script already exist at the fixed public commits; the package does not claim to contain private HTTP bytes.
