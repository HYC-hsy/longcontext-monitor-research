# Source-links v1: six frozen real P1 cases

Execution code eb406f2a4b1cc74d8d4a34f21fe958d558fa0c4e. All six cases ran once in frozen INDEX order with explicit source-links-v1 and the existing Claude Opus 4.8 profile. All six completed; seven logical P1 calls and one source read were observed. Logical calls are not the underlying HTTP attempt count. No Task, P2, native evaluation, old-method comparison or semantic scoring ran.

All produced visible requests, responses, tool calls/receipts, source pages, event/link records, bank changes, usage, stdout/stderr, result and terminal are preserved as redacted projections with original SHA-256 and JSONL line hashes. The source_links.json secret field is explicitly removed from every projection; private originals remain local. Hidden reasoning/signatures, credentials, private profile and endpoints are excluded. Projections are not raw HTTP bytes. Page sequence completeness is not presented as proof of complete source provenance.
