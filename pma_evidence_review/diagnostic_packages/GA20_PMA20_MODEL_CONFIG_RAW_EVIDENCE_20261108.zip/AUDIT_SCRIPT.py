"""Offline consistency and disclosure checks for the generated evidence ZIP."""
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

base = Path(__file__).resolve().parent
with zipfile.ZipFile(base / "GA20_PMA20_MODEL_CONFIG_RAW_EVIDENCE_20261108.zip") as archive:
    assert archive.testzip() is None
    index = json.loads(archive.read("MODEL_PARAMETER_EVIDENCE_INDEX.json"))
    rows = index["rows"]
    assert len(rows) == 40
    print("rows", len(rows))
    print("task_requests", {cohort: sum(row["task_request_count"] for row in rows
                                         if row["cohort"] == cohort) for cohort in ("GA", "PMA")})
    print("PMA_stage_payloads", {phase: sum(row[phase]["stage_payloads"] for row in rows
                                               if row["cohort"] == "PMA") for phase in ("p1", "p2")})
    print("PMA_profile_names", sorted({row["p1"]["profile_name_recorded"] for row in rows
                                       if row["cohort"] == "PMA"}))
    for key in ("model", "max_tokens", "thinking", "temperature", "top_p", "api_mode"):
        print("Task", key, Counter(row["task_request_fields"][key]["status"] for row in rows),
              {json.dumps(value, sort_keys=True) for row in rows
               for value in row["task_request_fields"][key]["values"]})
    print("GA_code_commits", Counter(row["code_commit"] for row in rows if row["cohort"] == "GA"))
    print("dataset_commits", Counter(row["dataset_commit_in_manifest"] for row in rows))
    print("runtime_policies", {json.dumps(row["runtime_policy_in_plan"], sort_keys=True) for row in rows})
    ga_by_task = {row["task"]: row for row in rows if row["cohort"] == "GA"}
    pma_by_task = {row["task"]: row for row in rows if row["cohort"] == "PMA"}
    differences = {}
    for task in ga_by_task:
        a = ga_by_task[task]["task_asset_identity"]
        b = pma_by_task[task]["task_asset_identity"]
        changed = {key: [a.get(key), b.get(key)] for key in set(a) | set(b) if a.get(key) != b.get(key)}
        if changed:
            differences[task] = changed
    print("asset_identity_differences", differences)
    print("event_count_totals", {cohort: dict(sum((Counter(row["task_event_counts"]) for row in rows
                                                    if row["cohort"] == cohort), Counter()))
                                 for cohort in ("GA", "PMA")})
    source_map = json.loads(archive.read("SOURCE_MAP.json"))
    print("unmodified_originals", sum(x["kind"] == "unmodified_original" for x in source_map.values()))
    hidden_pattern = re.compile(rb'"type"\s*:\s*"(?:thinking|redacted_thinking)"', re.I)
    hidden = [name for name in archive.namelist() if hidden_pattern.search(archive.read(name))]
    assert not hidden, hidden
    print("private_thinking_blocks_left", len(hidden))
    for number in range(1, 21):
        ga = next(row for row in rows if row["order"] == number and row["cohort"] == "GA")
        pma = next(row for row in rows if row["order"] == number and row["cohort"] == "PMA")
        print(f"{number:02d} {ga['task']} GA={ga['task_request_count']} "
              f"PMA={pma['task_request_count']} P1={pma['p1']['stage_payloads']} "
              f"P2={pma['p2']['stage_payloads']} GA_code={ga['code_commit'][:8]}")
