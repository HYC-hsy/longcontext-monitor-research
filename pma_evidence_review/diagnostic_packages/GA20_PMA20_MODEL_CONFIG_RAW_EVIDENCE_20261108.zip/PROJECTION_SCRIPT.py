"""Read-only source audit and redacted projection of GA20/PMA20 model configuration evidence."""
from __future__ import annotations

import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
GA_INDEX = Path(r"E:\ga20restoredata29\ga20-public-20261030\FINAL20_PRIVATE_INDEX.json")
PMA_SELECTION = Path(r"E:\LongContext\_pma_bankid_ga20_20261107\selection\selection_result.json")
GA_CONFIG = Path(r"E:\ga20data29\ga20.private.json")
PMA_CONFIG = Path(r"E:\LongContext\_pma_bankid_ga20_20261107\ga20.private.json")
ZIP_PATH = BASE / "GA20_PMA20_MODEL_CONFIG_RAW_EVIDENCE_20261108.zip"
INDEX_PATH = BASE / "GA20_PMA20_MODEL_CONFIG_RAW_EVIDENCE_20261108.index.json"

DROP_KEYS = {
    "signature", "api_key", "apikey", "authorization", "auth_header", "access_token",
    "refresh_token", "secret", "password", "provider_url", "provider_url_sha256",
    "private_endpoint", "base_url", "apibase", "profile_file", "profile_path",
    "private_client", "headers", "private_failures", "cookie", "cookies", "token",
}
PRIVATE_BLOCK_TYPES = {"thinking", "redacted_thinking", "signature"}
SECRET_PATTERNS = (
    re.compile(r"(?i)bearer\s+[a-z0-9._~+/-]{8,}"),
    re.compile(r"(?i)\bsk-[a-z0-9_-]{12,}\b"),
    re.compile(r"(?i)(?:api[_-]?key|password|secret)\s*[:=]\s*[^\s,;]+"),
)
FILE_MAP: dict[str, dict[str, object]] = {}
FILES: dict[str, bytes] = {}
REDACTIONS: Counter[str] = Counter()
endpoint_values: set[str] = set()
credential_values: set[str] = set()


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def encoded(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def load(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def source_name(path: Path) -> str:
    text = str(path)
    if text.lower().startswith("e:\\longcontext\\"):
        return "LongContext/" + text[len("E:\\LongContext\\"):].replace("\\", "/")
    if text.lower().startswith("e:\\ga20restoredata29\\"):
        return "ga20restoredata29/" + text[len("E:\\ga20restoredata29\\"):].replace("\\", "/")
    if text.lower().startswith("e:\\ga20data29\\"):
        return "ga20data29/" + text[len("E:\\ga20data29\\"):].replace("\\", "/")
    return "private_profile_file"


def scrub(value: object, where: str) -> object:
    if isinstance(value, dict):
        if str(value.get("type", "")).lower() in PRIVATE_BLOCK_TYPES:
            REDACTIONS["provider_private_block"] += 1
            return None
        result = {}
        for key, child in value.items():
            low = key.lower()
            if low in DROP_KEYS or low.endswith("_signature") or low.endswith("_secret") or low.startswith("private_"):
                REDACTIONS["sensitive_field"] += 1
                continue
            if low in {"analysis", "chain_of_thought", "internal_thought"} or low.startswith("reasoning_"):
                REDACTIONS["private_reasoning_field"] += 1
                continue
            # Keep a request's thinking *configuration* (e.g. {"type":"adaptive"}),
            # not hidden thinking content or a free-text thinking field.
            if low == "thinking" and not (isinstance(child, dict) and
                                            set(child).issubset({"type", "budget_tokens"})):
                REDACTIONS["private_thinking_field"] += 1
                continue
            clean = scrub(child, f"{where}.{key}")
            if clean is not None:
                result[key] = clean
        return result
    if isinstance(value, list):
        return [clean for i, item in enumerate(value)
                if (clean := scrub(item, f"{where}[{i}]")) is not None]
    if isinstance(value, str):
        clean = value
        for private in sorted(endpoint_values | credential_values, key=len, reverse=True):
            if len(private) >= 8 and private in clean:
                clean = clean.replace(private, "[REDACTED_PRIVATE_VALUE]")
        for pattern in SECRET_PATTERNS:
            clean = pattern.sub("[REDACTED_SECRET]", clean)
        clean = re.sub(r"(?i)[A-Z]:[/\\]Users[/\\][^/\\\s]+", "[LOCAL_USER_PATH]", clean)
        if clean != value:
            REDACTIONS["sensitive_string"] += 1
        return clean
    return value


def add_projection(name: str, source: Path, value: object, kind: str) -> None:
    original = source.read_bytes()
    public = encoded(scrub(value, name))
    FILES[name] = public
    FILE_MAP[name] = {
        "kind": kind, "source": source_name(source), "original_bytes": len(original),
        "original_sha256": sha(original), "public_bytes": len(public), "public_sha256": sha(public),
        "byte_identical_to_original": public == original,
    }


def add_raw_if_safe(name: str, source: Path) -> None:
    original = source.read_bytes()
    data = [json.loads(line) for line in original.decode("utf-8-sig").splitlines() if line.strip()]
    if scrub(data, name) != data or any(p.search(original.decode("utf-8-sig")) for p in SECRET_PATTERNS):
        add_projection(name, source, data, "redacted_projection")
        return
    FILES[name] = original
    FILE_MAP[name] = {
        "kind": "unmodified_original", "source": source_name(source),
        "original_bytes": len(original), "original_sha256": sha(original),
        "public_bytes": len(original), "public_sha256": sha(original),
        "byte_identical_to_original": True,
    }


def read_jsonl_with_line_hashes(path: Path) -> list[dict[str, object]]:
    records = []
    for number, line in enumerate(path.read_bytes().splitlines(), 1):
        if line.strip():
            records.append({"source_line": number, "source_line_sha256": sha(line),
                            "event": json.loads(line.decode("utf-8-sig"))})
    return records


def safe_manifest(manifest: dict[str, object]) -> dict[str, object]:
    keys = ("schema", "status", "execution_authorized", "official_source_git_commit",
            "pma_vendor_commit", "task_profile_sha256", "pma_profile_sha256",
            "profile_identity_status", "resolved_models_public", "config_sha256",
            "planned_order", "runtime_startup_identity")
    result = {key: manifest[key] for key in keys if key in manifest}
    asset_keys = ("official_commit", "task", "image_id", "repo_digest", "platform",
                  "public_task_tree_sha256", "native_tests_tree_sha256", "native_test_sh_sha256",
                  "native_agent_seconds", "native_verifier_seconds", "verifier_environment_mode")
    result["assets_identity"] = {
        task: {key: record[key] for key in asset_keys if key in record}
        for task, record in manifest.get("assets", {}).items()
    }
    return result


def parameter_values(requests: list[dict[str, object]], key: str) -> dict[str, object]:
    values = []
    for row in requests:
        content = row["event"].get("payload", {}).get("content", {})
        if isinstance(content, dict) and key in content:
            value = content[key]
            if value not in values:
                values.append(value)
    return {"status": "explicit_in_captured_request" if values else "not_sent_in_captured_request",
            "values": values}


ga_rows = load(GA_INDEX)
pma_selection = load(PMA_SELECTION)
assert len(ga_rows) == len(pma_selection["slots"]) == 20
ga_cfg = load(GA_CONFIG)
pma_cfg = load(PMA_CONFIG)
assert [x["task"] for x in ga_rows] == [x["task"] for x in pma_selection["slots"]]
assert len({x["task"] for x in ga_rows}) == 20

task_profile = Path(pma_cfg["environment"]["profiles"]["task_profile_file"])
pma_profile = Path(pma_cfg["environment"]["profiles"]["pma_profile_file"])
assert task_profile.read_bytes() == Path(ga_cfg["environment"]["profiles"]["task_profile_file"]).read_bytes()
assert pma_profile.read_bytes() == Path(ga_cfg["environment"]["profiles"]["pma_profile_file"]).read_bytes()
profile_data = load(pma_profile)["claude_monitor_opus48"]
for key in ("apibase", "apikey"):
    value = profile_data.get(key)
    if isinstance(value, str) and value:
        (endpoint_values if key == "apibase" else credential_values).add(value)
safe_profile_keys = ("provider", "api_mode", "model", "thinking_type", "reasoning_effort",
                     "temperature", "max_tokens", "context_win", "timeout", "read_timeout", "max_retries")
profile_projection = {key: profile_data[key] for key in safe_profile_keys if key in profile_data}
add_projection("profiles/PMA_PROFILE_SAFE_PROJECTION.json", pma_profile,
               {"profile_name": "claude_monitor_opus48", "declared_values": profile_projection,
                "excluded": ["apikey", "apibase", "transport_route"],
                "not_a_wire_request": True}, "redacted_projection")
FILES["profiles/TASK_PROFILE_NOT_UPLOADED.json"] = encoded({
    "kind": "private_original_withheld", "source": source_name(task_profile),
    "original_bytes": task_profile.stat().st_size, "original_sha256": sha(task_profile.read_bytes()),
    "reason": "Python profile contains credentials or private transport configuration; actual Task request structure is included per task",
})

all_rows = []
missing = []
for ordinal, (ga, pma) in enumerate(zip(ga_rows, pma_selection["slots"]), 1):
    task = ga["task"]
    assert task == pma["task"]
    for cohort, root, expected_run in (
        ("GA", Path(ga["private_run_root"]), ga["run_id"]),
        ("PMA", Path(pma["result"]["arm"]["run_root"]), pma["result"]["arm"]["run_id"]),
    ):
        assert root.is_dir() and root.name == expected_run, (cohort, task, root)
        slot_root = root.parents[1]
        manifest_path = slot_root / "manifest.json"
        manifest = load(manifest_path)
        assert manifest["task_profile_sha256"] == sha(task_profile.read_bytes())
        assert manifest["pma_profile_sha256"] == sha(pma_profile.read_bytes())
        agent_files = list((root / "jobs").glob("*/public_task__*/agent/research_events.jsonl"))
        assert len(agent_files) == 1, (cohort, task, agent_files)
        event_path = agent_files[0]
        source_events = read_jsonl_with_line_hashes(event_path)
        wanted = {"provider_request_ready", "provider_request_attempt", "provider_response",
                  "provider_response_content", "provider_usage", "provider_error", "termination"}
        selected = [row for row in source_events if row["event"].get("event_type") in wanted]
        requests = [row for row in selected if row["event"].get("event_type") == "provider_request_ready"]
        assert requests, (cohort, task, "no request evidence")
        for row in requests:
            endpoint = row["event"].get("payload", {}).get("provider_url")
            if isinstance(endpoint, str) and endpoint:
                endpoint_values.add(endpoint)
        prefix = f"{cohort}/{ordinal:02d}-{task}"
        add_projection(f"{prefix}/task_provider_events.json", event_path,
                       {"run_id": expected_run, "task": task, "selected_event_types": sorted(wanted),
                        "source_event_file_sha256": sha(event_path.read_bytes()), "events": selected},
                       "redacted_projection")
        add_projection(f"{prefix}/slot_manifest_safe.json", manifest_path,
                       safe_manifest(manifest), "redacted_projection")
        for name in ("plan.json", "run_identity.json", "frontend_binding.json"):
            path = slot_root / name
            if path.is_file():
                add_projection(f"{prefix}/{name}", path, load(path), "redacted_projection")
            else:
                missing.append({"cohort": cohort, "task": task, "file": name})
        for name in ("live_command_public.json", "runtime_policy_effective.json"):
            path = root / "archive" / name
            if path.is_file():
                add_projection(f"{prefix}/{name}", path, load(path), "redacted_projection")
            else:
                missing.append({"cohort": cohort, "task": task, "file": name})
        ident_path = agent_files[0].parent / "m4_agent_identity.json"
        if ident_path.is_file():
            add_projection(f"{prefix}/m4_agent_identity.json", ident_path, load(ident_path),
                           "redacted_projection")
        transport_modes = sorted({row["event"].get("payload", {}).get("api_mode")
                                  for row in selected if row["event"].get("event_type") == "provider_usage"
                                  and row["event"].get("payload", {}).get("api_mode")})
        task_evidence = {key: parameter_values(requests, key) for key in
                         ("model", "max_tokens", "thinking", "temperature", "top_p",
                          "stream", "context_management")}
        task_evidence["api_mode"] = {"status": "observed_in_provider_usage_event" if transport_modes else "unknown",
                                     "values": transport_modes}
        row = {
            "order": ordinal, "task": task, "cohort": cohort, "run_id": expected_run,
            "code_commit": ga["code_commit"] if cohort == "GA" else "b17151b8d57c61cfb4e058ad1601225f9fa2ea15",
            "manifest_profile_hashes": {"task": manifest["task_profile_sha256"],
                                        "pma": manifest["pma_profile_sha256"]},
            "manifest_declared_models": manifest.get("resolved_models_public"),
            "task_asset_identity": safe_manifest(manifest)["assets_identity"].get(task),
            "task_request_count": len(requests), "task_request_fields": task_evidence,
            "task_event_counts": dict(Counter(item["event"].get("event_type") for item in selected)),
            "dataset_commit_in_manifest": manifest.get("official_source_git_commit"),
            "runtime_policy_in_plan": load(slot_root / "plan.json").get("runtime_policy"),
            "p1": None, "p2": None,
        }
        if cohort == "PMA":
            private = root / "host_private" / "archive"
            payload_path = private / "memory_payload.jsonl"
            transport_path = private / "memory_transport.jsonl"
            trajectory_path = private / "trajectory_memory.json"
            payloads = read_jsonl_with_line_hashes(payload_path)
            add_projection(f"{prefix}/pma_stage_request_payloads.json", payload_path,
                           {"run_id": expected_run, "task": task, "source_file_sha256": sha(payload_path.read_bytes()),
                            "records": payloads}, "redacted_projection")
            add_raw_if_safe(f"{prefix}/pma_stage_transport_original.jsonl", transport_path)
            trajectory = load(trajectory_path)
            responses = [{key: step.get(key) for key in
                          ("step_id", "timestamp", "trigger_step", "step_count", "raw_response_phase1",
                           "raw_response_phase2", "should_inject") if key in step}
                         for step in trajectory.get("steps", [])]
            add_projection(f"{prefix}/pma_stage_visible_responses.json", trajectory_path,
                           {"run_id": expected_run, "task": task,
                            "memory_model_name_recorded": trajectory.get("memory_model_name"),
                            "source_file_sha256": sha(trajectory_path.read_bytes()), "steps": responses},
                           "redacted_projection")
            phase_counts = Counter(item["event"].get("phase") for item in payloads)
            for phase, label in (("bank_management", "p1"), ("context_decision", "p2")):
                row[label] = {
                    "stage_payloads": phase_counts[phase], "profile_name_recorded": trajectory.get("memory_model_name"),
                    "model_and_parameters": "declared_by_same_profile_and_manifest_not_per_call_wire_verified",
                    "declared_profile_sha256": manifest["pma_profile_sha256"],
                    "profile_fields": profile_projection,
                    "actual_client_object_identity": "unknown_not_logged",
                }
        all_rows.append(row)

assert len(all_rows) == 40
FILES["MODEL_PARAMETER_EVIDENCE_INDEX.json"] = encoded({
    "kind": "per_task_model_parameter_evidence_with_provenance",
    "note": "Request fields are client-side captured, not server attestation. A missing request field is not a confirmed server default.",
    "task_profile_sha256": sha(task_profile.read_bytes()),
    "pma_profile_sha256": sha(pma_profile.read_bytes()),
    "p1_p2_shared_profile": True,
    "p1_p2_same_client_instance": "unknown_not_logged",
    "official_or_server_defaults_confirmed": [],
    "rows": all_rows,
})
FILES["MISSING_AND_WITHHELD.json"] = encoded({
    "missing_expected_files": missing,
    "private_originals_retained_locally": True,
    "withheld_originals": [
        {"source": source_name(GA_CONFIG), "reason": "complete private run configuration"},
        {"source": source_name(PMA_CONFIG), "reason": "complete private run configuration"},
        {"source": source_name(task_profile), "sha256": sha(task_profile.read_bytes()),
         "reason": "credentials and transport configuration"},
        {"source": source_name(pma_profile), "sha256": sha(pma_profile.read_bytes()),
         "reason": "credentials and private endpoint"},
        {"source": "all native provider HTTP bytes", "reason": "not retained as verifiable raw wire requests"},
        {"source": "P1/P2 per-call model kwargs and client-object IDs", "reason": "not present in archived stage payload/transport records"},
    ],
})
FILES["PROVENANCE_AND_LIMITS.json"] = encoded({
    "GA_final_private_index": {"source": source_name(GA_INDEX), "sha256": sha(GA_INDEX.read_bytes())},
    "PMA_selection_result": {"source": source_name(PMA_SELECTION), "sha256": sha(PMA_SELECTION.read_bytes())},
    "GA_private_config_sha256": sha(GA_CONFIG.read_bytes()),
    "PMA_private_config_sha256": sha(PMA_CONFIG.read_bytes()),
    "classification": "client-side captured request structures, stage payloads, transport and visible responses",
    "not_raw_http_bytes": True,
    "server_effective_parameters_not_attested": True,
    "GA_code_commits": dict(Counter(row["code_commit"] for row in all_rows if row["cohort"] == "GA")),
    "PMA_code_commit": "b17151b8d57c61cfb4e058ad1601225f9fa2ea15",
    "comparison_differences": ["GA-only versus PMA with P1/P2 calls", "different execution batches and code commits",
                               "historic GA task model request settings do not confirm all server defaults"],
})
FILES["SOURCE_MAP.json"] = encoded(FILE_MAP)
FILES["REDACTION_COUNTS.json"] = encoded(dict(REDACTIONS))
FILES["PROJECTION_SCRIPT.py"] = Path(__file__).read_bytes()
FILES["AUDIT_SCRIPT.py"] = (BASE / "audit_package.py").read_bytes()

for name, content in FILES.items():
    if any(pattern.search(content.decode("utf-8")) for pattern in SECRET_PATTERNS):
        raise RuntimeError(f"secret-like text remains in {name}")
    for private in endpoint_values | credential_values:
        if len(private) >= 8 and private.encode("utf-8") in content:
            raise RuntimeError(f"private value remains in {name}")
    if re.search(rb'(?i)"(?:api_key|apikey|authorization|signature|apibase|provider_url|private_endpoint)"\s*:', content):
        raise RuntimeError(f"sensitive key remains in {name}")

with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, content in sorted(FILES.items()):
        archive.writestr(name, content)
with zipfile.ZipFile(ZIP_PATH) as archive:
    assert archive.testzip() is None
    for name, content in FILES.items():
        assert archive.read(name) == content
index = {"zip": ZIP_PATH.name, "bytes": ZIP_PATH.stat().st_size,
         "sha256": sha(ZIP_PATH.read_bytes()),
         "files": {name: {"bytes": len(content), "sha256": sha(content),
                           "kind": FILE_MAP.get(name, {}).get("kind", "generated_index")}
                   for name, content in sorted(FILES.items())},
         "source_map_member": "SOURCE_MAP.json", "redaction_counts": dict(REDACTIONS)}
INDEX_PATH.write_bytes(encoded(index))
print(json.dumps({"status": "prepared_read_only_source_audit", "zip_bytes": index["bytes"],
                  "zip_sha256": index["sha256"], "public_files": len(FILES),
                  "redactions": dict(REDACTIONS), "missing": len(missing)}, ensure_ascii=False))
