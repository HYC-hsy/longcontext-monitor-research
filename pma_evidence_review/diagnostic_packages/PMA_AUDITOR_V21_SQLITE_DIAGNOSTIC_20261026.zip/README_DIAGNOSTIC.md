# PMA independent evidence review: SQLite C14 source-use-v2.1 diagnostic

This is a **private package** for read-only protocol and semantic inspection. It contains the actual saved visible reviewer requests and public responses from one SQLite C14 real-model audit, not a rerun or a corrected response. No Task, evaluator, memory maintenance, or HTML reviewer call is part of this package.

## Identity and scope

- Executed source commit: `9d174fbe71b7500e4315abf922b2a02cc31db175`.
- Review mode: `evidence-first`; request policy: `source-use-v2.1`; profile identity: `claude_monitor_opus48` / `claude-opus-4-8` (no profile or secrets included).
- Frozen SQLite `review_input_sha256`: `0aa854b8a7c7eb98ae5e412cdf78180597ca3400e0884046db397e9e4c2cdb90`. This canonical packet identity differs from the input file's byte SHA-256 in `PACKAGE_INDEX.json`.
- SQLite: 15 saved requests, 15 saved responses, 14 extracted claims for 3 operations, and one final report. No second SQLite request series was launched.
- HTML C2: **not started; 0 requests**. Its prior-version responses/report are not present or substituted.
- The original frozen input retains its explicit earlier-history omission markers. No future trajectory or evaluation result was added.

## Files and provenance

| Package path | Role |
| --- | --- |
| `sqlite/input.json` | Existing frozen input, copied byte-for-byte from the location recorded in `FILE_INDEX.json`. |
| `sqlite/requests.jsonl` | This v2.1 run's actual saved full system/prompt/tools request records, phase and request identity included. |
| `sqlite/responses.jsonl` | This run's saved raw reviewer response text or call status, including extraction and each verification. |
| `sqlite/report.json` | This run's final parsed report; no verdict has been altered. |
| `SQLITE_C14_DIAGNOSIS.md` | **Posthoc human reading**, covering all 14 claims, mapped by operation and original fragment. It was not model input. |
| `FILE_INDEX.json` | Existing run index, unmodified; it also mentions validated HTML input and the HTML stop note, which are not required in this SQLite-only ZIP. |
| `README_DIAGNOSTIC.md` | This new packaging explanation, not a runtime artifact. |
| `PACKAGE_INDEX.json` | New package member identity and hash list, not a runtime artifact. |

`FILE_INDEX.json` was read first. All seven file entries it lists, including the two files not placed in this ZIP, were found and matched their recorded bytes and SHA-256 before packaging. `PACKAGE_INDEX.json` maps included copies to exact original paths and distinguishes runtime originals from posthoc notes. No original file was modified, and no redaction was necessary after the stated privacy scan.

## Protocol and semantic inspection guide

The original `sqlite/report.json` gives these **engineering** counts: `citation_missing=5` for claims **1, 2, 4, 5, 9**; `citation_unknown_document=4` for **6, 7, 11, 14**; `citation_ambiguous_or_unmatched=2` for **8, 12**; and `ok=3` for **3, 10, 13**. Thus **11 formal verdicts are null**. Inspect each matching raw response rather than treating its `model_verdict` as the formal result. The three valid formal results are `insufficient`; no null has been rewritten as supported or insufficient.

The vendored document formatter visibly labels `Document 1…N`, while the appended PMA contract and binder require a **zero-based** `document_index`. For example, the model returned index 24 against a 24-document execution registry (valid indices 0–23). This may explain several failures, but do not automatically subtract one or fabricate citations: five outputs contain multiple evidence strings without corresponding individual citations, and claim 12 cites command text for an execution assertion. The complete requests and responses are included to examine whether these are model protocol errors, prompt/interface conflict, or both.

For semantics, `SQLITE_C14_DIAGNOSIS.md` separately evaluates the source-tarball claim, PATH export and later-session scope, gap deletion, build-directory binary, and narrow symlink/`.gcno`/`which` observations. Source alignment is not entailment; a binding error is not evidence that a claim is false. This is a development sample and the posthoc reading is not blind gold.

## Known record gaps and privacy boundary

- The fixed worktree's HEAD was read again during packaging and equaled the executed SHA; `git status --short` was empty. There is no separate saved **runtime-time** source/worktree terminal transcript. The runtime `FILE_INDEX.json` records the executed SHA.
- The final offline unittest run was observed as 47 passed, 0 failed, 0 skipped and recorded in `FILE_INDEX.json`, but its raw terminal stdout/stderr was **not independently saved**. Therefore no file in this ZIP is presented as the original test transcript, and tests were not rerun merely to manufacture one.
- The archive contains no model profile, API key, environment dump, authentication header file, unrelated trajectory, or client-log directory. Prior to packaging, the exact configured key and endpoint values plus common key/Bearer/Authorization patterns, email addresses and user-home paths were checked in the six source files intended for inclusion; no findings were returned. A negative pattern scan cannot prove the absence of every possible secret.
- `responses.jsonl` contains captured client-boundary response text; it is not claimed to be a byte-for-byte HTTP wire capture. No hidden reasoning is included by this exporter.
