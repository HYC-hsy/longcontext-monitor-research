# Two-task GA + predictive PMA diagnostic

Execution code: 3786386f991a0d4a080ef6ff11da5cc29a9901b4
Dataset: 2fd12b88aafdd04a52c298e3940bcb189f9766d6
Harbor: 459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc

Both tasks were started exactly once in this new batch, reached internal CURRENT_TASK_DONE, and were evaluated natively. rstan-to-pystan passed 4/6 native tests with reward 0; nginx-request-logging passed 8/8 with reward 1. Both tasks report confirmed resource cleanup. The previous subscription-failed batch was deleted locally at the user's request and was not uploaded. These two single episodes do not establish method effectiveness.

All files here are public visible projections, not original HTTP bytes. Private original files remain on the local machine. The original-to-projection SHA-256 map is in FILE_HASHES.json. Omitted: private profiles, authorization original, source bundles, container filesystem, hidden thinking/signatures, and hidden native test names/assertions/stdout. The raw verifier reports remain local; only counts and raw report hashes are published.
