# Citation-only semantic clarity A/B: same-round real-model diagnostic

Execution code: `9d3d497e3730f78846ba6f23b9eec2d06fd88570` (detached full worktree). Parent baseline code: `ae31a01fb94535d7fb11bbd8b7adfdb639bdb446`. Frozen manifest SHA-256: `dcadeb1fabe2c2518307e8763ea5f6118688027394e514b575ce07d4fe482928`.

A strategy `baseline-a`; B strategy `semantic-paraphrase-role-clarity-v1`. Both used the existing `claude_monitor_opus48` profile identity (Anthropic Messages, `claude-opus-4-8`, adaptive thinking), without publishing the profile or credential. Runs occurred serially, A then B, once per arm and once per frozen sample. These are development samples, not a held-out estimate. No Task, official evaluator, or memory maintenance was run.

The dataset's `evaluation-only.json` contains frozen reference labels and was **not** model input. Model requests contained only the current operation and its submitted citations, with empty normative context. `A-plan.json` and `B-plan.json` are pre-run request plans. The `real-A` and `real-B` files are actual request/response/result records; the benchmark captures visible model response text, not raw HTTP bytes or hidden reasoning. `PER_ITEM_COMPARISON.json` preserves all 29 original operations, submitted citations, frozen labels, both explanations and request identities, and post-hoc notes. These notes are analysis, not model input. Original frozen data bytes and runtime files are included as-is.

Local offline tests: 120 passed, 0 failed, 0 skipped. Frozen data validation, A/B exports, both runs, and both scores exited 0. Plan check: A exactly matched frozen baseline requests; B differed only in approved system clarification plus strategy/hash identity. Both plans had 29 requests and the pinned experiment-plan hashes. Actual requests and result identities matched the plans. Each real arm recorded 29 requests, 29 responses, and 29 formally valid results with `engineering_status=ok`. These are logical calls; the available records do not establish the number of underlying HTTP attempts.

| Stratum | A reference agreement | B reference agreement | B change |
| --- | ---: | ---: | --- |
| historical_original (9) | 9/9 | 8/9 | one insufficient became supported |
| trace_derived_control (20) | 20/20 | 20/20 | none |

The sole verdict change is `h-html-1-0`: A correctly judged insufficient, whereas B wrongly treated the stronger claim of preserving formatting *exactly* as entailed by a requirement to preserve as much legitimate formatting as possible. `h-html-1-1` was supported by both arms in this same round; its old failure cannot be credited as a B improvement. Both same-conclusion/different-evidence pairs retained supported with sufficient evidence and insufficient with weak evidence. There were no insufficient/contradicted confusions. Two B explanations improved without changing verdict: `h-sqlite-3-2` avoided conflating memory-content support with proof of tool execution, and `d-regex-same-conclusion-weak-evidence` no longer treated a success string in command text as proof that filtering occurred. A/B both kept narrow code and receipt positives while rejecting the broad write/PATH claims.

See `FILE_INDEX.json` for exact bytes and hashes. `plan_identity_check.json` and per-run identity checks document pre-run and actual-request matching. The included stdout/stderr/exit-code files are the original local acceptance and execution outputs. No files are fabricated for absent stages. No profile, secret endpoint, client-private trace, hidden thoughts, Task output, or official evaluation is included.
