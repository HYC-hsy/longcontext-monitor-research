# Eight-slot PMA citation gate preparation (2026-10-28)

Production source is fixed at `6d2304ddea84a489ad0c0c9fcbad9a3cbdc8ca88`.
The prepared execution worktree HEAD is
`5bed874cc89e3397146c194285105bf09faa0dfe`; the difference from the
production commit consists only of previously archived material and four
committed synthetic gate certificates. No production source was changed.

`SAFE_MATRIX.json` lists the eight frozen slots, run IDs, strategy, gate,
profile hashes, public model identity, requested runtime policy, native
evaluation preparation, plan/manifest hashes, and certificate index hashes.
All eight private manifests, plans, run identities and profile files remain
on the local machine. Their hashes are published, but the full private
configuration is not. No live authorization exists at this preparation
boundary.

Four current-source combinations were certified: direct/gate-only,
split/gate-only, direct/gate-one-repair, split/gate-one-repair. The last
combination reuses the already committed and verified certificate; the
source-identical common A/U zero-model fixture was also reused. The other
three B fixtures each ran once, were collected with the existing redacting
collector, committed, and passed the certificate verifier. The collector's
selected synthetic requests, responses, memory, receipt and cleanup records
are in `certifications`. Full unselected raw fixture directories remain local
and are not represented as public complete snapshots.

The earlier 344/344 isolated regression result is included as its original
two-process reports and streams in `offline-regression`; the suite was not
mechanically rerun because the production source, Python, and pinned Harbor
identities did not change. The local native Harbor is pinned to
`459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`, and the task pool to
`2fd12b88aafdd04a52c298e3940bcb189f9766d6`.

The first private preparation attempt failed before importing the project
module because the helper lived outside the repository. Its error is kept in
`logs/prepare-matrix.log`. The corrected new Python process received a
temporary repository `PYTHONPATH`; `logs/prepare-matrix-retry.log` records
the eight successful new preparations. No old prepared run was overwritten.
The prior OCaml run ID was not reused because its preparation HEAD differed.

At the time represented by this package: zero real model calls, zero real
Task starts, zero official evaluations, and zero live authorizations. The
synthetic certificates establish engineering wiring, not review accuracy or
Task effectiveness. A later live-run authorization does not retroactively
change this preparation evidence.
