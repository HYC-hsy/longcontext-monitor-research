import hashlib
import json
from pathlib import Path
import subprocess

root = Path(r"E:\pma-source-links-offline-20261102")
delivery = root / "pma_evidence_review/source_links_delivery_20261102"
manifest = json.loads((delivery / "MANIFEST.json").read_bytes())
saved = json.loads((delivery / "SOURCE_IDENTITY.json").read_bytes())
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
assert head == "eb406f2a4b1cc74d8d4a34f21fe958d558fa0c4e"
assert len(manifest["files"]) == 93 and len(saved["source_files"]) == 61
assert manifest["runtime_files"] == 61
bad = []
for name, expected in manifest["files"].items():
    path = root / name
    if not path.is_file():
        bad.append([name, "missing"])
        continue
    data = path.read_bytes()
    if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
        bad.append([name, "manifest mismatch"])
for name, expected in saved["source_files"].items():
    path = root / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        bad.append([name, "source identity mismatch"])

from pma_evidence_review.tools.run_p1_source_case import source_identity
actual = source_identity(root=root, candidate="source-links-v1")
if actual["code_commit"] != head or actual["source_files"] != saved["source_files"]:
    bad.append(["source_identity(candidate=source-links-v1)", "runtime mismatch"])
report = {"checkout_sha": head, "clean": not bool(subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=root)),
          "manifest_files_checked": len(manifest["files"]), "saved_source_files_checked": len(saved["source_files"]),
          "rebuilt_source_files_checked": len(actual["source_files"]),
          "saved_source_commit": saved["code_commit"], "rebuilt_source_commit": actual["code_commit"],
          "failures": bad}
out = Path(__file__).parent / "identity-check.json"
assert not out.exists()
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"manifest_files": len(manifest["files"]), "source_files": len(actual["source_files"]),
                  "failures": len(bad), "clean": report["clean"]}))
raise SystemExit(0 if not bad and report["clean"] else 1)
