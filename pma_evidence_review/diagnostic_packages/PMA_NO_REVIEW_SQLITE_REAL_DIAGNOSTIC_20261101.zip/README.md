# SQLite no-review candidate: completed real run

Run `pma-c818075eb46b4272` used production code `d28d0ed75741f3a627721766a29745ab3ae2da9d`.
Task finished normally; native reward 1.0, three tests passed and none failed.
The 17 maintenance and 17 selection calls completed, with no split/review/repair calls.
Every selection was no_intervention, and zero reminders were actually delivered.
The 43 maintenance operations succeeded, including two gap deletions; see
ANALYSIS.json for observed scope and gap-churn issues. No model verdict checks
were performed under this candidate policy.

The public `visible/` files preserve complete *visible* request/response and
Task event records as source-mapped, redacted JSONL projections. They are not
the original HTTP bytes. Deep hidden reasoning/signatures, credentials,
private profile values/endpoints, complete profiles and hidden verifier test
names/assertions/output are excluded. Source file hashes and line hashes link
each projection to the unmodified local original. The verifier is represented
only by its count summary and native result. `PACKAGE_INDEX.json` describes
all included files and projection boundaries.

The earlier failed run `pma-3059c4460c434473` remains separate in archive
commit `9eff93eef864eb814505cca59648f26f332a7ddd`; it is not counted as a
Task result or spliced into this successful run.
