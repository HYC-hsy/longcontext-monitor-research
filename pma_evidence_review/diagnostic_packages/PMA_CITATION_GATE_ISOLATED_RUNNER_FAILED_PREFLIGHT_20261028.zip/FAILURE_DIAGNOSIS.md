# PMA citation gate runner isolation: preflight stopped on dirty native Harbor

Fixed execution code: `57b204aefeaf3768b47a698dabde3a7880a93f49`. Full new clean worktree: `E:\pmagate2`. `FETCH_HEAD` matched the fixed SHA. No production source, tests, frozen benchmark files or historical results were edited.

Interpreter: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, Python 3.13.14, `regex` 2026.9.29. Runner was invoked once with `--native-harbor-source-root E:\LongContext\bench_runtime\m4\harbor-src` and fresh `--report-dir E:\LongContext\pma-gate-isolated-acceptance-20261028-01\reports`, with `PYTHONUTF8=1`, `PYTHONDONTWRITEBYTECODE=1`, and `LITELLM_LOCAL_MODEL_COST_MAP=True`.

The coordinator exit code was **1**. The PMA subprocess ran 266 tests: 266 passed, 0 failures/errors/skips, exit 0. Its report records the Harbor import from this fixed worktree's pinned PMA vendor. The native subprocess exited 2 **before discovering/running its 16 tests**. Its Harbor source root was at fixed HEAD `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`, but the runner's required `git status --porcelain -- src/harbor` check found three pre-existing modifications:

- `src/harbor/environments/docker/harbor-docker-egress-control-sidecar/Dockerfile`
- `src/harbor/models/task/config.py`
- `src/harbor/trial/single_step.py`

Consequently the native identity guard raised `RuntimeError: native Harbor source is not clean` before the 16 native tests could run. The two child processes were isolated as intended; this failure does not establish a gate-mode or native-verifier test result. Raw coordinator and child stdout/stderr, `pma.json`, `native.json`, and `summary.json` are included unchanged. The PMA/native test inventories and PIDs are in those reports. No assertions, modules, or source files were patched to bypass the guard.

Per the requested fail-stop ordering, Docker Engine was **not checked this round** because the regression prerequisite failed. No A, gate-only, or gate-one-repair fixture, collector, certificate, committed certification evidence, or real-task `prepare` ran. No fake/real authorization, model, Task, evaluator, container, volume or worker was launched by this attempt; there is nothing from this attempt to clean up. No 29-sample benchmark was run.

To continue in a later, separately controlled acceptance attempt, supply an independent clean checkout/worktree of the same pinned native Harbor commit (preserving the existing three modifications), then rerun both subprocess regressions and only after passing check Docker. This suggestion is not an action taken in this run.
