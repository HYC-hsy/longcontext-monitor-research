# Citation-only benchmark: first real 29-item review

Execution code: `ae31a01fb94535d7fb11bbd8b7adfdb639bdb446` (the fixed `f21f4660070992b407bcadd3984a76aa926f3138` plus a scoped Git-for-Windows long-path compatibility fix and its assertion). The frozen dataset and trusted MANIFEST SHA-256 `dcadeb1fabe2c2518307e8763ea5f6118688027394e514b575ce07d4fe482928` did not change. The profile identity was `claude_monitor_opus48` / `anthropic` / `claude-opus-4-8`; secret values are not in this package.

## Engineering and input boundary

The new Windows worktree had all five frozen files at `text: unset`; both the frozen dataset and a fresh rebuild validated against the externally fixed MANIFEST pin. All five rebuilt files were byte-identical. The final source passed 115/115 local tests. The single real run exited 0, with 29 actual requests, 29 raw responses, 29 journal rows and 29 final results. Every engineering status was `ok`; there were no unrun or missing items. Actual request system/prompt/tools and request digests were identical to the pre-exported plan, in frozen order. The plan was identical to the dataset's frozen `requests.json`; the projected normative context was empty. The evaluation-only labels and rationales were not model input. There were 29 logical client calls; separate underlying HTTP-attempt totals are not available from the published records and are not inferred.

## Reference comparison (development labels, not gold)

Rows below are frozen reference labels; columns are this run's formal model verdicts.

Historical originals (9 valid, 0 engineering errors/missing/unrun):

| Reference | supported | insufficient | contradicted |
|---|---:|---:|---:|
| supported | 1 | 1 | 0 |
| insufficient | 0 | 7 | 0 |
| contradicted | 0 | 0 | 0 |

Trace-derived controls (20 valid, 0 engineering errors/missing/unrun):

| Reference | supported | insufficient | contradicted |
|---|---:|---:|---:|
| supported | 7 | 0 | 0 |
| insufficient | 0 | 6 | 0 |
| contradicted | 0 | 0 | 7 |

The raw verdict distribution was 8 supported, 14 insufficient and 7 contradicted. Reference agreement was 8/9 historical and 20/20 derived, but this is a small, two-task development set and is **not** a generalization or accuracy claim.

The one apparent false rejection is `h-html-1-1`: the quoted task instruction categorically says not to alter HTML formatting and to retain functional identity except harmful substrings. The model correctly noticed this core equivalence, but then rejected the memory because its prefatory words “Critical constraint:” and minor articles were not literal matches, invoking the stored content hash as if it required verbatim prose. The reference `supported` label remains frozen. This is a semantic over-literalness concern, not an engineering error; no label was silently changed. No other label dispute was identified in the submitted-citation scope.

Both same-conclusion pairs responded to evidence strength: `d-write-positive` and `d-regex-positive` were supported with the relevant receipt/full code; `d-write-same-conclusion-weak-evidence` and `d-regex-same-conclusion-weak-evidence` were insufficient when only the source-code success string was submitted. The operation wording remained the same in each pair. Other controls distinguished task requirements from completed execution, current-shell `export PATH` success from future-session/system-wide claims, and narrow static code properties from universal HTML/XSS correctness. All seven frozen direct-contradiction controls received `contradicted`; no insufficient item was mislabeled contradicted in this run.

Several explanations appropriately preserve narrow positives within an overall insufficient judgment (for example symlink/version/.gcno receipts and the HTML file-write receipt). Those positives do not establish broad completion or complete functional quality. `PER_ITEM_DIAGNOSIS.json` preserves every original operation, submitted citation, source role, model explanation, raw response, frozen label and retrospective reason. The latter is post-run analysis, never sent to the model.

Historical inventory preparation remains separate from the 29 reviewed samples: 15 ready, 7 no evidence, 4 citation-set ineligible, 3 delete-protocol not applicable and 17 unverifiable public cycle inputs among 46 original operations; 6 other ready items were not selected for this main development set. These are not model verdicts or errors in this 29-item run.
