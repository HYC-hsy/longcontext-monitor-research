$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:LITELLM_LOCAL_MODEL_COST_MAP = 'True'
$env:GIT_CONFIG_COUNT = '2'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = 'E:/pma_d1_tb2_source_20261017'
$env:GIT_CONFIG_KEY_1 = 'safe.directory'
$env:GIT_CONFIG_VALUE_1 = 'E:/pma-harbor-459ff6e-clean'
$checkout = 'E:\LongContext\p3'
$base = 'E:\LongContext\_pma_simple_8ed_five_20261108\wake3_five'
$py = 'E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe'
if ((git -C $checkout rev-parse HEAD).Trim() -ne 'e5a7a10d5a8d17c8c831ad23fd46db2e40142028') {
    throw 'Execution code changed'
}
Set-Location $checkout
foreach ($task in @('kv-store-grpc', 'reshard-c4-data', 'rstan-to-pystan',
                    'largest-eigenval', 'filter-js-from-html')) {
    $output = Join-Path $base ($task + '.selection')
    if (Test-Path (Join-Path $output 'selection_result.json')) { throw "Already attempted: $task" }
    Write-Output ("SLOT_START " + $task + " " + (Get-Date -Format o))
    & $py -X utf8 -B -m experiment_runner run --config (Join-Path $base ($task + '.private.json')) --output $output
    $exit = $LASTEXITCODE
    $resultPath = Join-Path $output 'selection_result.json'
    if (!(Test-Path $resultPath)) { throw "No selection result for $task; launcher exit $exit" }
    $selection = Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($selection.slots.Count -ne 1 -or $selection.slots[0].task -ne $task) {
        throw "Selection identity mismatch for $task"
    }
    $arm = $selection.slots[0].result.arm
    $status = $arm.status
    Write-Output ("SLOT_END " + $task + " run_id=" + $arm.run_id + " disposition=" +
        $arm.disposition + " cleanup=" + $status.cleanup_confirmed + " exit=" + $exit +
        " " + (Get-Date -Format o))
    if ($exit -ne 0 -or $arm.disposition -ne 'completed' -or
        $status.cleanup_confirmed -ne $true -or
        $status.native_result.status -ne 'native_recorded') {
        throw "Unsafe or unevaluated slot $task; next Task not started"
    }
}
