# Direct-operation audit prompt A/B: complete real record

This package preserves byte-for-byte the two shared frozen development inputs,
the four A/B exported request plans, actual full model-visible requests and
captured public responses, four reports, both offline-test stdout/stderr pairs,
four CLI stdout/stderr pairs, the private preflight identity record and the
retrospective operation-by-operation A/B diagnosis. It has no profile contents,
API key, private endpoint, hidden reasoning, Task run, or official evaluation.

A source: 77f0f91dc4f508c9ef8e39c9f01e1d50c59eebd7
B source: 76b9e4708b3162c8354b906003eb84e4432ae161
A strategy: direct-operation-v4.1
B strategy: direct-operation-v4.2-entailment-candidate
Shared evidence policy: source-use-v3
Report schema: pma-operation-review-report-v2
Nonsecret model identity: claude_monitor_opus48 / claude-opus-4-8
SQLite review_input_sha256: 0aa854b8a7c7eb98ae5e412cdf78180597ca3400e0884046db397e9e4c2cdb90
HTML review_input_sha256: 4760d69e0e47f1e0ede15e9fd800270b89768a6307c45b4c8d4223803cc1494b
The review-input identities are protocol content hashes, not input-file byte hashes.

Execution order was SQLite A, SQLite B, HTML A, HTML B, one run each. Request,
response and result counts are 3/3/3, 3/3/3, 4/4/4, 4/4/4. Every engineering
status is ok. The model gave supported for every operation in both arms, but
this is not a human accuracy judgment. OPERATION_AB_DIAGNOSIS.md is a post-run
assessment never sent to either model. The raw returned response and model
explanation are retained in the corresponding run directory.

FILE_INDEX.json is the original local index. PACKAGE_INDEX.json maps every ZIP
member to byte count, SHA-256 and its original relative path. All 32 indexed
files were included unchanged after exact-profile-value and common credential
pattern checks found no hits. There are no missing items or redactions. The
captured responses are not represented as raw HTTP wire bytes. PowerShell
redirected unittest output to stderr; its original encoding is preserved.
