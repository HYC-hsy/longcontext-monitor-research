# Source and execution identity

- Repository: `HYC-hsy/longcontext-monitor-research`.
- Fixed executed code SHA: `51f12dba77b920f8a563c023eb24de217b9236b1`, detached full worktree `E:\pfocus52`, clean after the run.
- Fixed whole comparison SHA: `77f0f91dc4f508c9ef8e39c9f01e1d50c59eebd7`. All seven exported whole `{system,prompt,tools}` payloads and their request hashes were checked equal to this A baseline's frozen plans; the v4.2 candidate comparison paragraph was absent.
- Runtime interpreter: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, Python 3.13.14. `pma_evidence_review.focus_review` imported from `E:\pfocus52\pma_evidence_review\focus_review.py`; `PYTHONPATH` and `PYTHONHOME` were removed in each model invocation shell.
- Model profile identity only: `claude_monitor_opus48` / `claude-opus-4-8`, provider `anthropic`, API mode `messages`, thinking type `adaptive`. The existing private profile file was used by the original CLI; neither its contents nor its endpoint/key are included here.
- Offline test command: `python -X utf8 -B -m unittest discover -s pma_evidence_review/tests -v` in the fixed worktree. Actual result: 87 passed, 0 failed, 0 skipped. Original PowerShell-redirected stdout/stderr files are included unchanged.
- Inputs: SQLite C14 `0aa854b8a7c7eb98ae5e412cdf78180597ca3400e0884046db397e9e4c2cdb90`; HTML C2 `4760d69e0e47f1e0ede15e9fd800270b89768a6307c45b4c8d4223803cc1494b`. Both validated as `exact_public_prompt`, with original omission markers.
- SQLite used `--review-mode whole-focus` once. Actual request phases: three `verify_operation`, six `verify_focus`; nine captured public responses. HTML request plan was exported but **no HTML real run** was initiated after SQLite's local citation-binding failure.
- The embedded SQLite `whole_report` was copied to `sqlite-A-whole-report-from-current-run.json` by JSON reserialization. That file is a derivative from this same run, not a second model call or original HTTP bytes. The unchanged original report and request/response JSONL are also included.
- No Task, official evaluator, online memory maintenance, source-code mutation, prompt repair, model probe, or retry was performed in this diagnostic.
