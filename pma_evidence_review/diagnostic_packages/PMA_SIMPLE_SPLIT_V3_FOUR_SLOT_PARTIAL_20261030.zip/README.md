# Simple-split v3 partial real batch

Two SQLite Task episodes ran once each. Both Task agents reported CURRENT_TASK_DONE; the native verifier failed before tests at apt_install (return code 100). No reward exists. The two OCaml slots were not started. No episode or native evaluation was retried.

slot-01 and slot-02 are allowlisted, redacted visible projections from the existing export_gap_batch20_visible exporter. Each nested INDEX maps every source file and line hash to the corresponding public gzip file and row hash. Private originals remain local. Public JSON is re-encoded and redacted, not original HTTP bytes. URLs, profile values, hidden reasoning and private metadata may be excluded; see per-file redaction counts. Original private manifest/config and authorization material are not included.

STATUS.json distinguishes Task completion from unavailable native evaluation. The archived bootstrap stages show apt_update completed, apt_install returned 100, and test_starts remained 0. Captured stage receipts contain output hashes, not full apt stdout, so the exact apt failure cause cannot be established from this package alone.
