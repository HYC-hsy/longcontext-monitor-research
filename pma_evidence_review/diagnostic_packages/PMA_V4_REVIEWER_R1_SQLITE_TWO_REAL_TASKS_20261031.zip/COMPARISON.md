# SQLite full-episode v4 reviewer-prompt comparison (2026-10-31)

Two independent, serial `sqlite-with-gcov` Task episodes used
`pma-gap-evidence / pma_gap_evidence_v1`, `gate-one-repair`, and
`claim-split-same-evidence-v4`. The baseline source is
`be44ce85fd2ec1ce116e34a8683cbcb7a113f35e`; r1 source is
`cba49dedb1ed5f1ca7d26f9a30a183697434b7ea`. Apart from the
reviewer system prompt and its ancillary reviewer-only preparation code,
the intended Task method/configuration is the same. Both used the prior
complete SQLite configuration with only `ga_source` and `bench_root`
pointed to their separate worktrees. Task/PMA profile paths, task snapshot,
runtime policy (`uncapped / uncapped / official`) and the identical
`persistent_bundle_v1` cache object were retained. The config files remain
private; public identities and source hashes are in this package.

| Arm | Run ID | Cycles | Proposed / committed | Split / batch / repair logical requests | Native tests | Reward | Cleanup |
| --- | --- | ---: | ---: | ---: | --- | ---: | --- |
| Original v4 | `pma-56b78b0c9cd546be` | 32 | 105 / 31 | 152 / 152 / 86 | 0 passed, 3 failed | 0.0 | confirmed |
| v4-reviewer-r1 | `pma-770994a4f5cc48a9` | 14 | 33 / 20 | 50 / 50 / 22 | 0 passed, 3 failed | 0.0 | confirmed |

Both runs reached `native_recorded`, had no primary failure, and cleaned
their owned containers and volumes. The request counts are logical calls,
not underlying HTTP attempt counts. A result of zero is a recorded native
result here, not a missing evaluation. Native test names, assertions, and
stdout are omitted from this public projection; the private originals remain
unchanged. The same cache identity was used only in evaluation, not to alter
the Task Agent's environment beforehand.

## Examples and limits of interpretation

- The original v4 accepted an early task-requirement knowledge operation with
  a task-instruction citation. This is an appropriate distinction between
  what was requested and what was already completed. It later accepted a
  deletion of the compiler-unavailable gap after cited `gcc --version` and
  `gcov` receipts; the deletion used a repair attempt. The chain is preserved
  in `baseline/review/gate_cycles.jsonl` with the exact A, submitted B,
  split/batch verdicts, repair, and final bank.
- The r1 run also accepted the task requirement and, after a repair attempt,
  deleted its compiler gap using `gcc --version` and a configure receipt
  showing the compiler with coverage flags. Both runs' final banks contain
  no active gaps. This does not independently prove every Task completion
  criterion or persistent PATH behavior.
- Both final status memories say the Task is complete, yet the native verifier
  recorded 0/3 tests. This is a substantive completion-evidence/Task-outcome
  tension, not a reason to retroactively alter the model's statements.
- The baseline and r1 trajectories differ substantially in length and actions
  (32 vs 14 cycles), so they are not matched event-by-event. The two zero
  rewards do not establish equal behavior, and differences in commits or
  reminders cannot be causally assigned to the reviewer prompt from one
  stochastic episode per arm.
- SQLite does not exercise the HTML “where possible” versus “exactly” case
  that motivated the reviewer-only development comparison. That correction
  remains a separate small-sample observation, not a Task-level result here.

The package includes the complete *visible JSON projection* of Task events,
maintenance and review transports, gate cycles, operation receipts, final
memory, and evaluation/cleanup status for each arm. Original-byte and public
projection SHA-256 mappings are in `INDEX.json`. This is not raw HTTP or
hidden reasoning. The private source files and full verifier report were
retained locally; the public verifier projection contains counts and hashes,
not hidden test bodies. No extra model judge, prompt tuning, rerun, or third
episode was performed.
