# Independent PMA evidence auditor: first source-use-v3 real diagnostic

This package preserves the two frozen development inputs, the actual full
model-visible requests and public responses, the program reports, raw offline
test output, and post-run human diagnostic notes. No Task, official evaluation,
or online memory maintenance was performed. No profile, credentials, or hidden
reasoning are included.

Source commit: 79708fd7531956e067094fa8d2ca2c00fd226bd9
Policy: source-use-v3; mode: evidence-first; model identity: claude_monitor_opus48 / claude-opus-4-8.
SQLite C14 review_input_sha256: 0aa854b8a7c7eb98ae5e412cdf78180597ca3400e0884046db397e9e4c2cdb90.
HTML C2 review_input_sha256: 4760d69e0e47f1e0ede15e9fd800270b89768a6307c45b4c8d4223803cc1494b.
These input identities are protocol content hashes, not the JSON files' byte hashes.

SQLite completed with 15 requests and 15 responses, 14 formal claims and no
engineering errors. HTML made one extraction request and received one response;
its 24 proposed claims included invalid claim kinds, so extraction parsing failed
before individual verification. The HTML failure and raw response are retained.
The two *_DIAGNOSIS.md files are retrospective opinions, not model responses.

FILE_INDEX.json is the original local index; PACKAGE_INDEX.json maps every ZIP
member to its SHA-256 and identity. The offline unittest output is in stderr,
stored in its original UTF-16 LE redirection encoding; stdout is empty. Both
files are deliberately preserved. The included model-visible content is not
raw HTTP wire bytes. No package content was redacted; the original indexed
files were included byte-for-byte after local exact-profile-value and common
credential-pattern scans returned no findings. This does not waive review
before redistribution beyond the intended repository.
