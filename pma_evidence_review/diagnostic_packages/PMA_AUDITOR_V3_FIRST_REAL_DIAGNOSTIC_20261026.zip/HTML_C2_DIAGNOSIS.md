# HTML C2 — source-use-v3, extraction failure

Frozen input identity `4760d69e0e47f1e0ede15e9fd800270b89768a6307c45b4c8d4223803cc1494b`. Exactly one real v3 extraction request returned. `report.json` records `extraction_parse_failure:claim_kind`, zero **accepted** claims/results and no verification request. This does **not** mean the model returned no claims: its raw response contains 24 proposed claim rows and four `coverage=complete` entries. The response is preserved without alteration in `html-real/responses.jsonl`. All proposed rows below have **no model verification verdict, no bound citation and no formal semantic status**; later rows were not independently validated after parsing stopped at the first invalid kind.

| Raw row | Operation | Raw kind | Proposed assertion (readable projection; exact bytes in response) | Review status |
| --- | --- | --- | --- | --- |
| 1 | 0 status | fact | `/app/filter.py` was created with a regex-based JavaScript-removal approach | Not verified |
| 2 | 0 status | fact | Removes script tags | Not verified |
| 3 | 0 status | fact | Removes inline event handlers | Not verified |
| 4 | 0 status | fact | Removes `javascript:` URLs in named attributes | Not verified |
| 5 | 0 status | fact | Implementation awaits verification | Not verified |
| 6 | 1 delete gap | deletion | Deletion of “script not created” gap justified by file creation | Not verified |
| 7 | 2 save gap | fact | Defines harmful substrings to include script tags, including self-closing | Not verified |
| 8 | 2 save gap | fact | Defines harmful substrings to include event handlers | Not verified |
| 9 | 2 save gap | fact | Defines harmful substrings to include `javascript:` URLs in named attributes | Not verified |
| 10 | 2 save gap | **gap** | `data:` URLs not yet addressed | **Invalid kind; first parser failure** |
| 11 | 2 save gap | **gap** | `vbscript:` not yet addressed | Invalid kind |
| 12 | 2 save gap | **gap** | `about:` not yet addressed | Invalid kind |
| 13 | 2 save gap | **gap** | Meta refresh tags not yet addressed | Invalid kind |
| 14 | 2 save gap | **gap** | Base tags not yet addressed | Invalid kind |
| 15 | 2 save gap | **gap** | `iframe srcdoc` not yet addressed | Invalid kind |
| 16 | 2 save gap | **gap** | SVG event handlers not yet addressed | Invalid kind |
| 17 | 2 save gap | **gap** | CSS `expression()` styles not yet addressed | Invalid kind |
| 18 | 2 save gap | **gap** | CSS import statements not yet addressed | Invalid kind |
| 19 | 3 procedural | fact | Regex approach chosen | Not verified |
| 20 | 3 procedural | fact | `re.sub` with `IGNORECASE|DOTALL` used for script tags | Not verified |
| 21 | 3 procedural | fact | Separate event-handler patterns with different quoting forms | Not verified |
| 22 | 3 procedural | fact | Attribute-specific URL patterns preserve empty attribute structure | Not verified |
| 23 | 3 procedural | fact | Example transforms `href="javascript:alert(1)"` to `href=""` | Not verified |
| 24 | 3 procedural | fact | Matched-substring removal preserves formatting without HTML restructuring | Not verified |

The source input includes a file-write action/receipt and visible code, so the narrow “file created” closure and static implementation assertions are meaningful audit targets. However, this run never verified them: it cannot demonstrate either correct positive recognition or false rejection. The raw nine `gap` kinds violate the contract (`fact|plan|hypothesis|question|deletion`); do not silently convert them to facts, delete them, or treat the four `coverage=complete` self-reports as an accepted extraction. Neither broad functional correctness nor the old H6/H17 self-reference issue can be evaluated from this run's formal results.
