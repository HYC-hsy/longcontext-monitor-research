# Reviewer-only stability repeat (2026-10-31)

Fixed execution SHA `cba49dedb1ed5f1ca7d26f9a30a183697434b7ea`; first-round archive `1f6a1d9eb3d774e373746dce4daf5c9fcfeb9e63`.
Round 2 order: candidate → baseline. Round 3: baseline → candidate.
Each new group has 22 returned, parsed batch responses, zero engineering failures; all config identities and actual request payloads match the first round for that arm.
These are repeated calls on 22 development cases, not new independent samples.

Verdict abbreviations: S=supported, I=insufficient, C=contradicted. Acceptance means S; I and C are both rejections. Full reasons for every round are in `THREE_ROUND_CASES.json` and original results.

| Case | Ref | Baseline R1/R2/R3 | Candidate R1/R2/R3 | Accept change / note |
| --- | --- | --- | --- | --- |
| h-sqlite-1-0 | S | S/S/S | S/S/S | same admission in both arms |
| h-html-1-1 | S | S/S/S | S/S/S | same admission in both arms |
| h-html-1-0 | I | S/S/S | I/I/I | admission differs |
| h-sqlite-3-0 | I | I/I/I | I/I/I | same admission in both arms |
| sqlite_call_19 | I | I/I/I | I/I/I | same admission in both arms |
| sqlite_call_61 | I | I/I/I | I/I/I | same admission in both arms |
| derived-cause-direction | I | I/I/I | S/I/I | admission differs |
| derived-cause-supported | S | S/S/S | S/S/S | same admission in both arms |
| derived-comparison-reversed | C | C/C/C | C/C/C | same admission in both arms |
| derived-condition-requirement | S | S/S/S | S/S/S | same admission in both arms |
| derived-condition-overreach | I | I/I/I | I/I/I | same admission in both arms |
| derived-delete-installed | S | S/S/S | S/S/S | same admission in both arms; deletion |
| derived-delete-cross-session | I | I/I/I | I/I/I | same admission in both arms; deletion |
| r1-requirement | S | S/S/S | S/S/S | same admission in both arms |
| r1-completion-unverified | I | I/I/I | I/I/I | same admission in both arms |
| r1-completion-verified | S | S/S/S | S/S/S | same admission in both arms |
| r1-practical | S | S/S/S | S/S/S | same admission in both arms |
| r1-verbatim-overreach | I | C/C/C | I/I/I | same admission in both arms |
| r1-verbatim-supported | S | S/S/S | S/S/S | same admission in both arms |
| r1-alpha | S | S/S/S | S/S/S | same admission in both arms |
| r1-beta-unverified | I | C/I/I | I/I/I | same admission in both arms |
| r1-beta-verified | S | S/S/S | S/S/S | same admission in both arms |

## Group counts (three-state / admission agreement out of group size)

| Group | Baseline R1/R2/R3 | Candidate R1/R2/R3 |
| --- | --- | --- |
| prior 13 | 12:12 / 12:12 / 12:12 | 12:12 / 13:13 / 13:13 |
| new 9 | 7:9 / 8:9 / 8:9 | 9:9 / 9:9 / 9:9 |
| deletions separately | 2:2 / 2:2 / 2:2 | 2:2 / 2:2 / 2:2 |

Each cell is three-state:admission agreement; the three slash-separated cells are R1/R2/R3.
Delete case `derived-delete-installed` retains a frozen supported label with a known “required tool” referent ambiguity; no label was changed.
Engineering failures are zero in these four new groups. No Task, native evaluation, new splitter calls, prompt edits, parameter changes, majority vote or model adjudicator.

## Interpretation of reasons, not just verdicts

- `h-html-1-0`: baseline admitted the stronger “exactly preserved” statement in all
  three rounds. Candidate rejected it all three times and explicitly distinguished
  “as much as possible” from “exactly”. This local correction repeated.
- `derived-cause-direction`: baseline rejected unsupported causation in all three
  rounds. Candidate inferred causation from patch → installer exit 0 in round 1,
  but explicitly rejected that inference in rounds 2 and 3. The regression did
  **not** repeat, and this case shows candidate judgment variability.
- `h-sqlite-1-0`: both arms supported the task requirement in all three rounds.
  This is not a candidate-only repair.
- `r1-completion-unverified`, `r1-verbatim-overreach`, and `r1-beta-unverified`:
  candidate consistently rejected unsupported completion, absolute footnote
  retention and beta success. Baseline also rejected all three; its three-state
  classification was “contradicted” for the footnote case in every round, while
  the beta case changed from contradicted in R1 to insufficient in R2/R3.
  Candidate used insufficient in all rounds. All newly constructed strong-evidence
  positives remained supported in both arms across all rounds; no new false
  rejection was observed.
- `h-sqlite-3-0`: both arms correctly kept the whole operation insufficient in
  all rounds because a lone directory listing does not establish source extraction,
  provenance or full path. Candidate R2 additionally said the future-step plan
  had “no relevant evidentiary support”, a questionable demand for execution
  evidence for an intention; the overall refusal is still justified by the
  unsupported extraction claim. This reason-quality issue is not counted as a
  new false admission or rejection.

The repeated HTML correction is real for this fixed input, but the candidate's
causal mistake and reason-quality issue prevent a blanket claim of better
reviewing. The 22 samples and three calls per arm are too small and too
development-exposed for statistical or generalization claims. Do not majority-vote
away the R1 causal false admission or relabel the frozen references.
