# One-sentence citation reviewer: prespecified C-only repeat

This package records one new run of `semantic-support-one-sentence-v1` on all 29 frozen development samples, in frozen order, under execution code `ef773664f74c08619cb76ca2daeb69d0c192df16`. No A arm, Task, official evaluation, or memory maintenance ran in this repeat. The previous C material under `previous-C/` was extracted unchanged from archive commit `58424cc66e6d971321a27c066a8f014cf899e541`; it is not a new model run.

The frozen MANIFEST SHA-256 is `dcadeb1fabe2c2518307e8763ea5f6118688027394e514b575ce07d4fe482928`. `evaluation-only.json` holds reference labels and was **not** model input. The new exported plan exactly equals the prior C plan. All 29 actual new requests equal the corresponding previous C requests, including system, prompt, tools and identities. The repeat recorded 29 visible requests, 29 visible raw response records, 29 journal rows, 29 formal results, all engineering status `ok`; the score identity check passed. These are logical calls, not a count of underlying HTTP attempts.

Local preflight: 122 tests passed, 0 failed, 0 skipped. Frozen dataset validation returned 29 valid. Export, run and score exited 0; original stdout/stderr and exit-code files are included.

| Stratum | Previous C agrees with frozen label | Repeat C agrees with frozen label |
| --- | ---: | ---: |
| historical_original (9) | 9/9 | 8/9 |
| trace_derived_control (20) | 19/20 | 20/20 |

Only two verdicts changed. `h-html-1-0` moved from insufficient to supported: the repeat explanation treats the stronger *formatting exactly* statement as mere emphasis of *preserve as much as possible*, losing the prior round's correct distinction. `d-argv-positive` moved from contradicted to supported: the repeat reads “fewer than two arguments” as `len(sys.argv) < 2`, whereas the prior round read “arguments” as user-supplied values excluding `sys.argv[0]`. The frozen supported label is retained; that terminology ambiguity is separately flagged rather than relabeled. `h-html-1-1` stayed supported. Both same-conclusion/different-evidence pairs again distinguished sufficient from weak citations correctly. Each round has 28/29 agreement, but on different strata and samples; this is evidence of local instability, not statistical significance.

All 29 explanations changed wording. `PER_ITEM_REPEAT_COMPARISON.json` preserves each original operation, submitted citations, frozen label, both complete explanations, formal verdict/engineering status, change flags and post-hoc comparison. A notable reason-only problem in the repeat is `d-regex-same-conclusion-weak-evidence`: despite the correct insufficient verdict, the explanation says a success string confirms filtering occurred, although the string is `tool_command` content and is not execution evidence. `previous-C/` and `real-C-repeat/` preserve their original request/response/result files separately; these are captured visible payloads, not raw HTTP bytes or hidden reasoning. `FILE_INDEX.json` maps package members to source and byte hashes.

The samples informed prompt development and are not held-out. This one repeat does not establish stable causal or generalizable improvement. No output was selected or rewritten to combine the better judgments from separate rounds.
