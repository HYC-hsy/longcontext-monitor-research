Execution code SHA: `ef773664f74c08619cb76ca2daeb69d0c192df16`. Full clean detached worktree: `E:\pmaonesent2`. Actual module import: `E:\pmaonesent2\pma_evidence_review\benchmark\experiment.py`.

Python: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, version 3.13.14. `regex` 2026.9.29. Existing private profile key `claude_monitor_opus48` selected the same Anthropic Messages `claude-opus-4-8` adaptive configuration as the prior C round; profile bytes, API key and endpoint are excluded.

Frozen MANIFEST SHA-256: `dcadeb1fabe2c2518307e8763ea5f6118688027394e514b575ce07d4fe482928`. Five benchmark data files returned `text: unset` in `git check-attr`. No newline normalization or global Git configuration change was made.

Experiment plan identity: `ffb2999ed6f2da818ca554157b98974e230ed8977687ed12ac6a6abe25503451`. Previous one-sentence A/C archive commit: `58424cc66e6d971321a27c066a8f014cf899e541`; verified previous ZIP SHA-256: `4fa71c379ceb7efb139eebf858acd0053516591105189bee1accabe5f247210f`.
