# Submitted-citation diagnostic (development samples)

Tested code: `a4aeb1fb940bda72df8558c1dc6b935019ae36d9`.
Strategy: `submitted-literal-citation-v1`. The scope is only each operation's originally submitted citations; unsubmitted history is not supplementary proof.

## SQLite C14

`op0/update_status` was ready with three unique exact submitted citations, all from `tool_observation` stdout. E1 is the `/app/bin/sqlite3` symlink listing pointing to the installed binary. E2 contains `/app/bin/sqlite3` and the SQLite 3.50.4 version output. E3 lists `.gcno` files. The full submitted status says “Task completed successfully” and also claims specific build flags, use of the pre-vendored source archive, build/install locations, a profile.d PATH change, and system-wide command availability. See `sqlite/input.json`, `sqlite/requests.jsonl`, and `sqlite/report.json` for the unabridged operation and quotes.

The raw model verdict and formal verdict were both `insufficient`; engineering status was `ok`. The model explicitly recognized the symlink, version, and `.gcno` narrow positives, while finding the other assertions unsupported by the submitted three quotes. In particular, a path printed in the same script does not alone establish access across sessions or system-wide. This is a defensible citation-set judgment; it is not a finding that the broader history disproves completion. The model's explanation is preserved verbatim in `sqlite/responses.jsonl` and `sqlite/report.json`.

`op1/delete_gap` was `not_applicable_delete_protocol`: this submitted-citation protocol does not judge whether a deletion is warranted. `op2/save_procedural` was `citation_set_not_eligible`: its set includes fuzzy candidates, including nonidentical visible excerpts. Neither operation was sent to the model; neither has a semantic verdict.

## HTML C2

`op0/update_status` was ready with one unique exact citation from `tool_command` source code: `Successfully filtered JavaScript from {html_file}`. The submitted status asserts creation of `/app/filter.py` and multiple implementation details. The code string is not a file-write receipt, execution receipt, or the full implementation.

The raw model verdict and formal verdict were both `insufficient`; engineering status was `ok`. Its explanation correctly refuses to promote a source-code success string into an observed successful run or proof of file creation, and notes that this narrow string does not establish the broad implementation assertions. The complete original wording is in `html/responses.jsonl` and `html/report.json`.

`op1/delete_gap` was `not_applicable_delete_protocol`. `op2/save_gap` and `op3/save_procedural` were `citation_set_not_eligible` because their submitted sets include fuzzy citations. These three were not sent to the model and have no semantic verdict.

## Interpretation boundary

The two ready operations both received `insufficient`, with no protocol or binding error. This does not establish accuracy or absence of false rejections on other examples. Five preparation-skipped operations are neither semantic successes nor failures. Exact quotation location is not equivalent to semantic support; this experiment did not widen citations, repair fuzzy items, or inspect hidden/future evidence for the model.
