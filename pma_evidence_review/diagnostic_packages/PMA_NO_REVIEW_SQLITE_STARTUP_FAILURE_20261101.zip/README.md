# Candidate SQLite startup diagnostic: no Task or model request

Fixed source `1a439dd2363f0523d62383e08526b4ded365cdc4`, run ID
`pma-3059c4460c434473`. The strict targeted candidate suite passed 13/13;
91 delivered source-file hashes matched actual checkout bytes. The inherited
broad regression has a separately disclosed old A-carrier error and was not
repeated for this targeted acceptance.

New config opted into `maintain-scoped-latest-no-review-v1` under
`pma-gap-evidence`, omitted gate/strategy, and reused the prior SQLite Task and
PMA profiles, uncapped Agent/time-turn policy, official verifier limit and
`persistent_bundle_v1` cache. A fresh committed runtime identity and 70-file
maintenance source identity were prepared. No old source hash list was reused.

The single explicit run attempt failed before worker_ready: worker_main imported
episode.py, which could not import `pma_evidence_review.private_faults` because
the host worker PYTHONPATH omits the repository root when gate is absent. The
launcher currently includes that root only when `gate is not None`; this new
candidate requires it even without a gate. This is a host import seam, not a
model verdict. No Task agent start, maintenance/selection request, native test or
reward exists. No second episode was started.

The worker stopped and no run-owned container was observed. However the
launcher recorded `cleanup_confirmed=false` and owned-volume clearance
`unknown: mount_identity_unavailable`; this package does not upgrade that to
clean. Private complete traceback and configuration remain local. The public
worker error is a minimal projection with the original log hash. No semantic
GAP/status/selection/reminder effect was observed.

This ZIP is a safe diagnostic projection, not raw HTTP or a complete private
run. Profiles, endpoints, credentials, hidden thinking, hidden tests and
authorization material are excluded. See PACKAGE_INDEX.json for file hashes
and projection-to-original SHA-256 mappings.
