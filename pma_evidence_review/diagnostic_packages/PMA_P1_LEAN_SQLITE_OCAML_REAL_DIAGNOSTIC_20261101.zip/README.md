# Lean P1: two serial real episodes

Fixed code: e79f57b359124fe061bd603310ba1c45973cf97b. SQLite then OCaml ran once each, with no shadow review. Both episodes completed and received native evaluations; both rewards were 0.0. The Task agent issued completion in both cases, but native tests did not pass. Cleanup for each run was confirmed before the next task began.

SQLite: 0/3 native tests passed; sqlite3 was unavailable by name in the independent verifier process. P1 retired a compiler gap before the package installation succeeded and later recorded broad completion without cross-process PATH proof. P2 returned no_intervention 14 times and delivered no reminder.

OCaml: 0/1 native tests passed; required testsuite success output was absent. Six fix attempts failed. P2 selected one committed gap, and its verbatim text appeared in a subsequent actual Task provider request. This did not solve the task. P1 repeatedly expanded a procedural entry and a gap despite its lean prompt.

The `visible/`-style JSONL files under each run preserve complete captured visible role requests/responses and Task events as line-mapped, redacted projections. They are not original HTTP bytes. Source file and row hashes appear in PACKAGE_INDEX.json. Private originals remain local. Hidden reasoning/signatures, credentials, private endpoint/profile data, and hidden verifier test names/assertions/output are not published. See ANALYSIS.json for counts, limitations and evidence-backed observations.
