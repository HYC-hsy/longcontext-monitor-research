# SQLite gate-one-repair repeat, visible projection

Run pma-31761d2f2de64fa6 completed once under the split-v2 gate-one-repair policy. The native evaluation produced reward 0.0. No rerun is represented here.

Selected Task-visible events, maintenance/selection transport, gate requests and raw visible responses, memory, evaluation receipts, and cleanup are projected with the existing Sanitizer. Gzip streams are not original HTTP bytes. INDEX.json records the private source byte hashes and per-line original-to-public hash mapping. Private originals remain local. Hidden thinking, secrets, authorization, and hidden verifier content are excluded.
