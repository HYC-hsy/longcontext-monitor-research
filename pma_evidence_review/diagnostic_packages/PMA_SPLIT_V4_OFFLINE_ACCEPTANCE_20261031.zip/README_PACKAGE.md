# Split v4 offline diagnostic

Code and documentation HEAD: 29b54922978f9c080834933c83d46fcb586ff049
Baseline: 3f607a37335433126bf8cfbf40613c169902bfb0
No real model, Task, evaluator or online memory call occurred in this delivery.
The focused test stderr is raw, including expected fixture exceptions.
The baseline probe is a known unchanged failure and is not counted as passing.
The plans are development preparation, not real model results.
See source/pma_evidence_review/split_v4_delivery/README.md for scope and limits.
