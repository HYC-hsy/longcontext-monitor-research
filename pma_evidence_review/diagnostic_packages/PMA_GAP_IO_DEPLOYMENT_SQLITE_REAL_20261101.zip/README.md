# SQLite e529 candidate: one real Task, visible projection

Code SHA `e52908b1ca68b62e35ba8bec67ff106434503f4a`; run ID
`pma-17ded442e35c47f5`. One pma-gap-evidence / gate-one-repair /
claim-split-same-evidence-v4 episode. No old method, reviewer-only repeat or Task retry.
The Task agent declared completion and the runner reached native evaluation.
Reward 0.0; all three native tests failed. The public error summaries report that
the verifier could not locate `sqlite3` by name. The selected evidence showed
`sqlite3` reachable after sourcing `/app/sqlite-env.sh` in one shell, which does
not establish availability in the separate verifier environment.

There were 17 maintenance cycles, 39 proposed operations, 61 split requests,
61 batch review requests and 29 repair requests. All 151 visible review responses
returned. There was no reviewed-attempt parse failure; one final operation was
not reviewed after an unbound/fuzzy repaired citation. 24 operations committed.
The 17 phase-2 outputs were all `<no_intervention/>`; no reminder was delivered.
The final phase-2 window retained eight action and eight result records and one
latest framework checkpoint. Actual phase-2 prompt characters total 249,973;
characters are not tokens.

The reviewer rejected two initial GAP saves using only task requirements because
their literal wording asserted current absence without an observation. A later
compiler-unavailability GAP with a direct receipt was saved. One status update
about a failed configure attempt was rejected; the earlier, now stale status
remained visible until a later update. A compiler GAP deletion was supported
after gcc/gcov and build evidence. A later PATH GAP repair could not be published
because its citation was fuzzy/unbound. The final completion status was accepted
although its PATH evidence was conditional on sourcing a setup script and did not
establish the verifier's independent environment. The final reviewer also cited
the prior status for some installation/library details; old status is context,
not independent evidence. These are post-run diagnostic judgments, not gold labels.

This ZIP is a redacted visible projection, not raw HTTP bytes or a complete host
snapshot. Original private records remain local. Hidden thinking, hidden tests,
profile/credentials/endpoints, host full witness and unselected bodies are not
published. PACKAGE_INDEX.json maps every file to source hashes; the original
CTRF hash is recorded but its hidden test body is excluded. No method or Task
effect improvement is inferred from this single development episode.
