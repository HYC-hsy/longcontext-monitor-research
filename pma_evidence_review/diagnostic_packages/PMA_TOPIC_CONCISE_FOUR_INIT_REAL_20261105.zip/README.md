# Concise work-topic initialization: four-task run

This is the full public visible projection of the fixed four-task initialization run on 2026-11-05. No theme semantic scoring was performed.

## Fixed identity

- Repository and code: `HYC-hsy/longcontext-monitor-research`, commit `605fed3eac626f2bb83d9069ed2a11deca0d6be3`, branch `pma/topic-concise-no-general`; clean checkout before and after execution.
- Dataset: terminal-bench-2 commit `2fd12b88aafdd04a52c298e3940bcb189f9766d6`.
- Native Harbor: `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`.
- Existing Python: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, version 3.13.14.
- Script: `pma_evidence_review/topic_suffix_experiment/run_suffix_init.py`, SHA-256 `2466615fecc231cf4d11c5a1cabe3649b4686ea89e328f29e10e2a0f7406db0e`.
- Existing private profile key: `claude_monitor_opus48`; the profile and endpoint are excluded.
- Reported public client parameters: `anthropic/claude-opus-4-8`, messages API, temperature 1, reasoning effort high, max tokens 8192, read timeout 300, adaptive thinking. Unknown hidden provider defaults are not inferred.

## Actual checks and calls

The script ran in `offline` mode with only `mcmc-sampling-stan`, `rstan-to-pystan`, `nginx-request-logging`, and `reshard-c4-data`, retaining its frozen order. Offline exit was 0; the report contains 6 fake-client checks (four valid task requests plus empty and invalid-output cases for the first task). Its request assertions checked the Harbor-loaded original task, complete initialization system prompt, one initialization tool, and the same complete guidance at the end of the user assignment. Full offline artifacts and exact stdout/stderr/exit code are included.

The same script then ran in `real` mode. All four tasks started and completed, in the order above, with one completed logical initialization call each. The real exit code was 0. There were zero script-classified format or engineering errors and no unrun tasks. Every `real/<task>/` folder includes the complete visible request and response/tool arguments, frozen input, run configuration, final topic state, bank and source archive. The model-visible full system and user text and tool definition are preserved, not replaced by hashes. Full real stdout/stderr and the per-task progress and summary are included.

Recorded per-task prompt/completion/cache tokens are respectively: `mcmc-sampling-stan` 889/45/20; `rstan-to-pystan` 1008/74/43; `nginx-request-logging` 998/90/61; `reshard-c4-data` 829/76/98. Totals: 3,724 prompt, 285 completion, 222 cache tokens. These are client-exposed usage fields, not independent billing measurements. Physical HTTP attempts and billable cost are unknown; the client's `cost_usd: 0` is not proof of zero cost.

## Projection, missing material and scope

Private originals remain on the local machine. All visible requests, responses, tool arguments, topics, stdout/stderr, and task artifacts are byte-identical to their private records except ten `source_archive/source_links.json` files. Their host signing `data.secret` was removed. Those files have an explicit `public_projection` marker and retain the original data hash only as a reference; they cannot be used as original runtime archives. `FILE_HASHES.json` maps original to public byte counts and SHA-256 for every included file. No credential, profile, authentication header, private endpoint or hidden reasoning is included. This ZIP is not raw HTTP bytes.

Unavailable: a verified physical HTTP request count, independently verified cost, and any maintenance, P2, full Task, native evaluation or display/empty-topic integration results, because those phases were not part of this run. In particular, successful initialization does not validate the separate display and empty-topic changes on which this candidate was based.
