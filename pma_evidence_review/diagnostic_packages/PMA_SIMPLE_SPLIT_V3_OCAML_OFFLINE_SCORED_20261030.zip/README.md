# Completed fix-ocaml-gc split-v3 offline runs

Both runs completed their Task and one native evaluation with a pinned, task-specific offline dependency bundle. They are new episodes, not retroactive evaluation of earlier failed episodes. The other task is in a separate package.

Each slot contains complete recorded public-visible Task and auxiliary event streams, memory operations and transport receipts as gzip JSONL projections. INDEX.json maps each source relative path and source-line SHA-256 to a public row SHA-256. Private originals remain local. The public JSON was sanitized and re-serialized; it is not original HTTP bytes. CTRF is represented by its private hash and public test-count summary, not hidden test text. Profile, authorization, headers, hidden reasoning and evaluator test bodies are excluded.
