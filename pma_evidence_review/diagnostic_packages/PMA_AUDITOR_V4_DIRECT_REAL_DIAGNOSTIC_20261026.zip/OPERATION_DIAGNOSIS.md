# Direct-operation-v4.1: first real diagnostic (development samples)

Execution source: `77f0f91dc4f508c9ef8e39c9f01e1d50c59eebd7`.
Policy: `source-use-v3`. Report schema: `pma-operation-review-report-v2`.
Model profile identity: `claude_monitor_opus48` / `claude-opus-4-8`; secrets and endpoint are not reproduced here.
The seven formal verdicts below are model-plus-engineering outputs, not human gold labels. This note is retrospective and was never supplied to the model. Full unabridged content, model response, citation coordinates, and visible request are in each sample's `report.json`, `responses.jsonl`, and `requests.jsonl`.

Offline unittest: 73 passed, 0 failed/skipped. Both frozen inputs validated as `exact_public_prompt`, with explicit omission markers retained. SQLite review-input identity `0aa854b8a7c7eb98ae5e412cdf78180597ca3400e0884046db397e9e4c2cdb90`; HTML identity `4760d69e0e47f1e0ede15e9fd800270b89768a6307c45b4c8d4223803cc1494b`. Export produced three SQLite and four HTML `verify_operation` requests, no extract stage. Actual requests/responses: SQLite 3/3, HTML 4/4. All seven `engineering_status=ok`; no memory mutation.

## SQLite C14

### Operation 0 — `update_status`, memory `status`, revision `rev_00387c0a79a9497eb68d9a44792d35e7`

Complete proposed content:

> Task completed successfully. SQLite 3.50.4 compiled with gcov instrumentation (CFLAGS=-fprofile-arcs -ftest-coverage, LDFLAGS=--coverage) from pre-vendored source at /app/vendor/sqlite-fossil-release.tar.gz. Built binaries located in /app/sqlite/sqlite directory, installed to /app/sqlite/install. Symlink created at /app/bin/sqlite3 and /app/bin added to PATH via /etc/profile.d/sqlite-gcov.sh. Gcov instrumentation verified (.gcno files present). Binary accessible system-wide via 'sqlite3' command.

Model `SUPPORTED`; formal `supported`; engineering `ok`. Citations: Document 6 task instruction; 34 and 66 tool commands; 46, 54, 62 and 70 tool observations. The build flags, artifacts, install output, symlink, `.gcno`, and successful invocation in the command's current shell have direct support. But Document 6 states *where the source should come from*; it does not prove the actual source provenance. The frozen visible window contains prior agent/derived-memory assertions about extraction, not an independent extraction receipt. Document 66 explicitly runs `export PATH="/app/bin:$PATH"` before `which sqlite3`; Document 70 therefore proves access in that shell, not a fresh session or every system context. The profile script was written, but activation in a separate execution context was not observed. The explanation calls all requirements complete by promoting these narrower facts. Retrospective judgment: whole-operation support is **not established**; do not mistake this for proof the underlying build failed.

### Operation 1 — `delete_gap`, memory `gap_Atcxxa4p`, revision `rev_e15e3f220c354470b587cda765837dc7`

Complete target content:

> Compiled SQLite binary installed to /app/sqlite/install/bin/sqlite3 - directory not yet added to PATH for system-wide availability

Model `SUPPORTED`; formal `supported`; engineering `ok`. Citations: Document 70 tool observation, 66 tool command, 1 derived prior status. Document 66 creates `/app/bin/sqlite3`, writes a profile script, then explicitly exports `/app/bin` for the same shell. Document 70 shows `which sqlite3` and `sqlite3 --version` succeeded there. It is **not necessary** that `/app/sqlite/install/bin` itself be the PATH entry; a working symlink would suffice. However, no independent new-session activation is shown, and Document 1 is a prior derived claim, not new proof. The model answered the deletion question (an improvement over reviewing whether the *old gap was once true*) but closed its broader system-wide condition on insufficient observed scope. Retrospective judgment: local/same-shell remedy supported; full deletion **premature or at least unverified**.

### Operation 2 — `save_procedural`, memory `4BBQc5iW`, revision `rev_477e1a469b654f039042929b1eaf2f62`

Complete proposed content:

> PATH modification for compiled binaries: Created symlink in /app/bin pointing to actual binary location, then added /app/bin to PATH via /etc/profile.d/*.sh script. This approach works for system-wide availability across sessions. Verified with 'which' and direct execution showing /app/bin/sqlite3 accessible.

Model `SUPPORTED`; formal `supported`; engineering `ok`. Citations: Document 66 command and 70 observation. The symlink, script creation, and same-shell verification are supported. The sentence about working "across sessions" is not established by the same-shell `export` and response; no new shell/profile loading check is visible. The target ID previously held a different procedural note about minimal build packages; the direct audit checked the new content, not whether replacing that old useful note was desirable. Retrospective judgment: **partially supported**, not sufficient for whole-operation `supported`.

## HTML C2

### Operation 0 — `update_status`, memory `status`, revision `rev_e1277af7f65144aca7c2d888a89a8505`

Complete proposed content:

> Script /app/filter.py created with regex-based approach to remove JavaScript. Implementation removes: script tags, inline event handlers (comprehensive list of on* attributes), and javascript: URLs from href/src/action/formaction/data/xlink:href attributes. Awaiting verification.

Model `SUPPORTED`; formal `supported`; engineering `ok`. Citations: Document 13 file-write success receipt; 11 submitted source text (tool command); 8 agent report. The file-creation claim is supported by the receipt, and the written code visibly contains the named regex branches and attributes. "Awaiting verification" accurately preserves the absence of observed behavior tests. But the receipt is not execution evidence, the enumerated event-handler list is not proof of a *comprehensive* set of all `on*` attributes, and "removes" can overstate the behavior of an unexecuted regex implementation. Retrospective judgment: **narrow static implementation description supported; unrestricted behavior/comprehensiveness not established**. This is not a finding that the file was absent.

### Operation 1 — `delete_gap`, memory `gap_KDFwgACm`, revision `rev_a15c5374f3494e4f8be33f52cc3f2fa0`

Complete target content:

> Script /app/filter.py not yet created.

Model `SUPPORTED`; formal `supported`; engineering `ok`. Citations: Document 9 file-write command and 13 successful file-write receipt (`writed_bytes: 5216`). These establish creation of the file and make the narrowly worded old gap obsolete. They do not prove filtering correctness, nor did the deletion question require that. Retrospective judgment: **reasonable deletion**. This is a valuable non-overrejection case.

### Operation 2 — `save_gap`, memory `gap_ZBJGdVGb`, revision `rev_7b0ff1a9cf514e5dbda7d53c24a972b5`

Complete proposed content:

> Implementation defines JavaScript/harmful substrings as: script tags (including self-closing), comprehensive list of inline event handlers (onabort through onwheel), and javascript: URLs in href/src/action/formaction/data/xlink:href. Other potential XSS vectors not yet addressed: data: URLs, vbscript:, about:, meta refresh tags, base tags, iframe srcdoc, SVG event handlers, style attributes with expression(), import statements in CSS.

Model `SUPPORTED`; formal `supported`; engineering `ok`. All three citations are to Document 11, submitted code text. The listed script and URL patterns are visible. The source can suggest absence of some listed patterns, but it does not by itself prove every item is an applicable JavaScript/XSS requirement or entirely unhandled; "SVG event handlers" particularly overlaps with the code's tag-agnostic event-attribute regex for enumerated handlers. The word "comprehensive" is again stronger than the source warrants. Retrospective judgment: **useful gap hypothesis with overbroad, insufficiently differentiated assertions**, not fully proven.

### Operation 3 — `save_procedural`, memory `ZkMPD3su`, revision `rev_3e6cf7fe719144609d7250071fdee20b`

Complete proposed content:

> Regex approach chosen for JavaScript removal: re.sub with IGNORECASE|DOTALL flags for script tags, separate patterns for each event handler with different quote types (double, single, backtick, unquoted), attribute-specific patterns for javascript: URL removal that preserve empty attribute structure (e.g., href="javascript:alert(1)" becomes href=""). This preserves formatting by removing only matched substrings without restructuring HTML.

Model `SUPPORTED`; formal `supported`; engineering `ok`. Citations are three excerpts from Document 11, submitted code text. Those excerpts support the intended regex construction and capture-group replacement. They do not show actual execution on the example or guarantee formatting preservation across HTML inputs; the task's strong "do not alter formatting" requirement remains untested in this frozen cycle. Retrospective judgment: **mechanism largely supported, observed outcome/general formatting guarantee unverified**. Avoid calling static code a failed behavior test.

## Cross-operation conclusion and boundaries

The direct strategy removes the prior extraction-stage loss: all 3/4 original operations, including the SQLite completion sentence, received their own request and response. Both deletion operations were framed as whether the specific entry can now be removed. Source references resolved cleanly; the earlier v3 `kind=gap` extraction parse failure did not recur. There were no formal engineering failures or visible new mistaken rejection of the narrow HTML file-creation/deletion fact.

The semantic error is **whole-operation overapproval**: SQLite's completion, deletion, and cross-session procedure were accepted using same-shell PATH evidence and a task instruction/derived memory as stronger proof than they are. HTML preserved a justified narrow deletion but promoted submitted static code into broader behavior claims. This is a retrospective judgment on two known development samples, not blinded accuracy, generalization, or Task effect. The packet contains explicit historical omission markers; conclusions apply only to its visible scope. No Task, official evaluation, online memory write, refactoring, prompt tuning, or extra sample was performed.
