# Independent PMA evidence auditor: direct-operation-v4.1 real diagnostic

This package contains both unchanged frozen development inputs, exported request
plans, actual model-visible requests, captured public model responses, original
program reports, raw offline-test and CLI output, a retrospective per-operation
diagnosis, and byte-level indexes. No Task, official evaluation, online memory
maintenance, or extra model sample was performed. No profile, key, private
endpoint, hidden reasoning, or client environment dump is included.

Source commit: 77f0f91dc4f508c9ef8e39c9f01e1d50c59eebd7.
Strategy: direct-operation-v4.1; evidence policy: source-use-v3.
Report schema: pma-operation-review-report-v2.
Nonsecret model identity: claude_monitor_opus48 / claude-opus-4-8.
SQLite C14 review_input_sha256: 0aa854b8a7c7eb98ae5e412cdf78180597ca3400e0884046db397e9e4c2cdb90.
HTML C2 review_input_sha256: 4760d69e0e47f1e0ede15e9fd800270b89768a6307c45b4c8d4223803cc1494b.
These protocol content hashes differ from input-file byte hashes; both are recorded.

Offline tests: 73 passed, 0 failed, 0 skipped. Test output went to stderr
under PowerShell redirection; its original encoding is preserved. SQLite has
3 actual requests, 3 responses and 3 formal results; HTML has 4/4/4. All
7 formal engineering statuses are ok. The seven supported model verdicts are
not human gold: OPERATION_DIAGNOSIS.md explains retrospective semantic concerns.
That note was not sent to the model. Full original content and raw responses
remain in the respective sample files. Captures are not raw HTTP wire bytes.

FILE_INDEX.json is the local-run index. PACKAGE_INDEX.json gives every ZIP
member's byte count, SHA-256, original relative path and role. Indexed files
were included byte-for-byte after exact-profile-value and common credential
pattern checks found no hits. There are no redactions or missing items.
