# Split-v2 four-task real-run visible projection

This package contains the four completed, serial split-v2 runs from the 2026-10-29 comparison: SQLite and fix-ocaml-gc, each with `gate-only` and `gate-one-repair`. Production source: `8c5f6ee0a9d64db39cee82df686bbf616f8e5ff3`; executed repository HEAD: `a40731ba4670681949de7b6f1173ef8f7e0f1c53` (evidence-only commits differ from production code).

Each numbered directory has a safe `IDENTITY.json`, an `INDEX.json`, and complete redacted JSONL/JSON projections for the selected visible Task, maintenance/selection, review, memory, and evaluation records. Every projected row retains the original file/line SHA-256 separately from the public row hash. Gzip streams are projections, **not original HTTP bytes**. Original private files remain at the local run roots; they are not in this package.

Slot 01 SQLite / gate-only: `pma-3f01d5e4889b42e5`, native reward 1.0. Slot 02 SQLite / gate-one-repair: `pma-3f6568ba9b3f4109`, Task completed but native evaluation was unavailable after `apt_update` bootstrap failure; no reward is imputed. Slot 03 fix-ocaml-gc / gate-only: `pma-809c59f3e2e84772`, native reward 1.0. Slot 04 fix-ocaml-gc / gate-one-repair: `pma-a116e38b95414dfb`, native reward 1.0. These single runs do not establish a statistical advantage.

`archive/native_reports_checked.json` was not produced for slot 02 because native evaluation did not reach report checking. The original failed bootstrap receipt and stage receipts are included as public projections. Profiles, credentials, authorization files, private client traffic, hidden thinking, verifier scripts, hidden tests, and raw headers are excluded. The projection used the existing `export_gap_visible_audit.Sanitizer`, including private-profile value and generic secret/endpoint scans; see `QA.json` and each slot's `INDEX.json` for redaction, source hashes, row counts, and missing files.

The subsequent authorized SQLite gate-one-repair repeat is a separate run and is not part of this four-slot package.
