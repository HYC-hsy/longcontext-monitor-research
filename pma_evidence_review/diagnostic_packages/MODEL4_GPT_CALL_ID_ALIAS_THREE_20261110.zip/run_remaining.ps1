$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:LITELLM_LOCAL_MODEL_COST_MAP = 'True'
$env:GIT_CONFIG_COUNT = '3'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = 'E:/pma_d1_tb2_source_20261017'
$env:GIT_CONFIG_KEY_1 = 'safe.directory'
$env:GIT_CONFIG_VALUE_1 = 'E:/LongContext/pc_model4_fix'
$env:GIT_CONFIG_KEY_2 = 'safe.directory'
$env:GIT_CONFIG_VALUE_2 = 'E:/pma-harbor-459ff6e-clean'

$root = 'E:\LongContext\_pma_model4_gpt_alias_ef441_20261109'
$repo = 'E:\LongContext\pc_model4_fix'
$python = 'E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe'
$expected = 'ef441618a0be740eccc15755940c5450597796dd'
$profileHash = 'bad779ae3cc41c60aef1b1e393229b3739777b06a02d29d2c93a26ca35892ad7'
$expectedSlots = @(10, 13, 20)
Set-Location $repo
if ((git rev-parse HEAD).Trim() -ne $expected -or (git status --porcelain)) {
    throw 'execution source identity changed'
}
if ((Get-FileHash (Join-Path $root 'private_profiles\gpt-6-sol.json') -Algorithm SHA256).Hash.ToLower() -ne $profileHash) {
    throw 'GPT profile bytes changed'
}
$batch = Get-Content -Raw -Encoding UTF8 (Join-Path $root 'batch_plan.json') | ConvertFrom-Json
$slots = @($batch.slots | Where-Object { $_.slot -in $expectedSlots } | Sort-Object slot)
if (($slots.Count -ne 3) -or (($slots.slot -join ',') -ne ($expectedSlots -join ','))) {
    throw 'three frozen slots differ'
}
foreach ($slot in $slots) {
    $name = ('{0:d2}-{1}-{2}' -f [int]$slot.slot, $slot.task, $slot.model)
    $output = Join-Path $root ('runs\' + $name)
    if ($slot.model -ne 'gpt-6-sol' -or -not (Test-Path -LiteralPath $slot.config) -or
        (Test-Path -LiteralPath $output)) { throw "slot configuration/output conflict: $($slot.slot)" }
    $plan = Get-Content -Raw -Encoding UTF8 (Join-Path $root ('plan-' + $slot.slot + '.json')) | ConvertFrom-Json
    $policy = $plan.slots[0].effective_runtime_policy
    if ($plan.config.dataset.commit -ne '2fd12b88aafdd04a52c298e3940bcb189f9766d6' -or
        $plan.config.method -ne 'pma-predictive-read-context' -or
        $policy.effective_agent_seconds -ne $null -or
        $policy.effective_task_turns -ne $null -or
        $policy.outer_timeout_seconds -ne $null) { throw "slot plan identity/limits differ: $($slot.slot)" }
}
Write-Output ('BATCH_ORDER ' + (($slots | ForEach-Object { '{0}:{1}:{2}' -f $_.slot, $_.task, $_.model }) -join ','))
foreach ($slot in $slots) {
    if ((git rev-parse HEAD).Trim() -ne $expected -or (git status --porcelain)) {
        throw 'execution source changed between slots'
    }
    $name = ('{0:d2}-{1}-{2}' -f [int]$slot.slot, $slot.task, $slot.model)
    $output = Join-Path $root ('runs\' + $name)
    $log = Join-Path $root ('slot-' + ('{0:d2}' -f [int]$slot.slot) + '.console.log')
    Write-Output ('SLOT_START {0} {1} {2} {3}' -f $slot.slot, $slot.task, $slot.model, (Get-Date -Format o))
    & $python -X utf8 -B -m experiment_runner run --config $slot.config --output $output *>&1 |
        Tee-Object -FilePath $log
    $code = $LASTEXITCODE
    Write-Output ('SLOT_END {0} exit={1} {2}' -f $slot.slot, $code, (Get-Date -Format o))
    if ($code -ne 0) { exit $code }
}
Write-Output ('BATCH_COMPLETED {0}' -f (Get-Date -Format o))
