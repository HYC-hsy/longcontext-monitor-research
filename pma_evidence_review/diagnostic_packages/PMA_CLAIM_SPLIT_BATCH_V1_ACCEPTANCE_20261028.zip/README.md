# Claim-split same-evidence v1: local acceptance

Execution source: `6d2304ddea84a489ad0c0c9fcbad9a3cbdc8ca88`.
Direct comparison strategy: `semantic-support-one-sentence-v1`.
Candidate strategy: `claim-split-same-evidence-v1`.

The isolated PMA/native regression passed 344 tests with zero failures, errors,
or skips. Both historical trace projections (`sqlite_call_19` and
`sqlite_call_61`) have matching direct/candidate input hashes. Each direct
fake used one audit request; each candidate fake used one split request and
one batch-verification request. These are synthetic protocol checks, not
model judgments or task results. The full multi-claim case is covered by
the regression suite, not asserted from these two canned fake responses.

The native A/U and candidate B/gate-one-repair zero-model fixtures completed.
The collector copied only selected redacted fixture evidence, and the
committed certificate verifier passed. The fixture authorization was removed.

`fix-ocaml-gc` was prepared with a new run ID, condition B, candidate
`pma_gap_evidence_v1`, gate-one-repair, and claim-split-same-evidence-v1.
Agent time and Task turns are uncapped; verifier timeout is official.
The task pool is pinned to `2fd12b88aafdd04a52c298e3940bcb189f9766d6`.
The new preparation is not authorized for execution. Private profiles and
the full prepared configuration are not included; `PREPARED_IDENTITY.json`
contains the safe identity projection and hashes.

No real model call, real Task, or official evaluation occurred. No live
authorization was created. These checks do not establish semantic accuracy.

`FILE_INDEX.json` lists each included file's byte length and SHA-256. The
`regression` directory contains the original two-process test reports and
streams; `fakes` and `plans` contain the two fixtures under both strategies;
`certification` contains selected zero-model lifecycle evidence; and `logs`
contains command outputs. The historical trace projections are sanitized
development material, not hidden tests or a blind evaluation.
