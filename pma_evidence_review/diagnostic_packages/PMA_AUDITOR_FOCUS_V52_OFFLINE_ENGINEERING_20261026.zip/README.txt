ENGINEERING ACCEPTANCE ONLY: synthetic fake responses, no real model diagnosis.
Whole baseline: 77f0f91dc4f508c9ef8e39c9f01e1d50c59eebd7.
Reproduce from the code SHA in INDEX.json using FOCUS_HANDOFF.md.
