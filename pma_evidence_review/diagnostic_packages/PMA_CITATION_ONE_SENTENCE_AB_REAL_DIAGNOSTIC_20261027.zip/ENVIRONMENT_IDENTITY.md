Execution code SHA: `ef773664f74c08619cb76ca2daeb69d0c192df16`.

Worktree: full detached checkout at `E:\pmaonesent1`; clean before running. Module import: `E:\pmaonesent1\pma_evidence_review\benchmark\experiment.py`. Remote: `https://github.com/HYC-hsy/longcontext-monitor-research.git`.

Python: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, 3.13.14 (Anaconda build). `regex` 2026.9.29. Git 2.49.0.windows.1.

Profile key: `claude_monitor_opus48`; existing local profile specifies Anthropic Messages, `claude-opus-4-8`, adaptive thinking. No profile bytes or private endpoint are included.

Dataset manifest file SHA-256: `dcadeb1fabe2c2518307e8763ea5f6118688027394e514b575ce07d4fe482928`. The five frozen benchmark JSON files each returned `text: unset` in `git check-attr`; no newline conversion was applied.

A plan identity: `a1282f49e8538a991419eafcc2e7ca49704c15fbc1363c57cbb496317ec5b3f1`. Candidate plan identity: `ffb2999ed6f2da818ca554157b98974e230ed8977687ed12ac6a6abe25503451`.
