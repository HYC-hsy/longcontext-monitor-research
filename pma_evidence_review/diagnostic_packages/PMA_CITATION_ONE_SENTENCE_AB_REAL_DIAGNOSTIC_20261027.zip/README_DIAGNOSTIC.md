# Citation-only one-sentence A/C same-round diagnostic

Fixed execution code: `ef773664f74c08619cb76ca2daeb69d0c192df16`. Frozen MANIFEST SHA-256: `dcadeb1fabe2c2518307e8763ea5f6118688027394e514b575ce07d4fe482928`.

A (`baseline-a`) and C (`semantic-support-one-sentence-v1`) each reviewed the same 29 frozen development samples once, serially A then C, using the same existing model profile. No Task, official evaluation, or memory maintenance was run. The candidate added only the approved one-sentence SYSTEM text; the pre-run identity check establishes that deleting it and its newline exactly recovers A, while prompts, tools, sample order and submitted citations match. `evaluation-only.json` contains frozen labels and was not model input. Normative context remained empty.

Local offline tests: 122 passed, 0 failed, 0 skipped. Dataset validation, A/C exports, runs and scores exited 0. Each actual run contains 29 requests, 29 responses, 29 journal rows and 29 formal results, all engineering status `ok`; request and result identities match its pre-export plan. These are logical client calls, not a measurement of underlying HTTP attempts.

| Stratum | A agreement with frozen reference | C agreement with frozen reference |
| --- | ---: | ---: |
| historical_original (9) | 8/9 | 9/9 |
| trace_derived_control (20) | 20/20 | 19/20 |

The only verdict changes are `h-html-1-0` and `d-argv-positive`. C correctly rejects the unsupported strengthening from preserving formatting *as much as possible* to preserving it *exactly*, whereas A in this run supported it. C also calls the static `sys.argv[1]` positive case contradicted: it interprets “fewer than two arguments” as fewer than two *user-supplied* arguments, excluding `sys.argv[0]`. The frozen reference treats the literal `len(sys.argv) < 2` check as support. This is a candidate regression against the frozen label, but the term “arguments” has a genuine wording ambiguity; no label was changed post hoc. `h-html-1-1` was supported by both same-round arms, so its correct result is not a candidate-only improvement. Both same-conclusion/different-evidence pairs remain correctly separated. Broad PATH and file-write claims stay insufficient; narrow source-code and execution-receipt positives are generally preserved except `d-argv-positive`.

Verdict correctness does not guarantee explanation correctness. For `d-regex-same-conclusion-weak-evidence`, both arms correctly refuse to infer implementation details from a success string, but their explanations describe the string as a success message/outcome rather than clearly as text inside a `tool_command` source. The full response and submitted evidence are retained for review.

`PER_ITEM_COMPARISON.json` records every original operation, submitted citation, frozen label, both model explanations and formal statuses, and separate post-hoc review notes. The original responses and actual requests are in `real-A` and `real-C`; these are captured visible payloads, not raw HTTP bytes or hidden reasoning. Original frozen data, pre-export plans, raw stdout/stderr/exit codes, scores and identity checks are also included. `FILE_INDEX.json` identifies the exact bytes and SHA-256 of every member. No profile, credential, private client trace, hidden thought, or unrelated personal file is included.

These 29 samples informed candidate development. This single A/C round supports a local regression comparison only; it is not held-out accuracy or stable causal improvement.
