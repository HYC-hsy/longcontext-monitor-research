# Four-task topic initialization: fixed launch and actual results

This package is a public visible projection of one corrected four-task topic-initialization run on 2026-11-05. No memory maintenance, P2, full Task, or native evaluation was run. It is not a semantic judgment of the topics.

## Identity and launch correction

- Execution code: `2683b68b8724fc62672dd22ba542e8244d0e59da` (`pma/topic-user-guidance-experiment`), unchanged and clean.
- Terminal-bench-2 dataset: `2fd12b88aafdd04a52c298e3940bcb189f9766d6`.
- Native Harbor: `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`.
- Existing Python: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe` (3.13.14).
- Existing private profile key: `claude_monitor_opus48`. The profile and endpoint are not in this package.
- Public client parameters recorded in each `real/*/run_config.json`: `anthropic/claude-opus-4-8`, messages API, temperature 1, reasoning effort high, max tokens 8192, read timeout 300, adaptive thinking. These are the available reported parameters, not a guarantee about hidden provider defaults.

The first offline attempt stopped at `ModuleNotFoundError: No module named 'pma_evidence_review'` before task loading or any model call. Its original logs are under `first_failed_attempt/`, and its earlier diagnostic archive remains at commit `e126290e780902cc19b871e35837302bc4ab4b97`. The corrected launch set `PYTHONPATH` to the same fixed checkout root. No code, prompt, task, tool, model, or parameter was changed. The corrected offline check returned exit 0 with 6 checks: four valid requests plus empty and invalid-output cases on the first task. Its full fake-client artifacts and original stdout/stderr are under `offline/` and `offline.*`.

## Real initialization

The script's frozen order was `mcmc-sampling-stan`, `rstan-to-pystan`, `nginx-request-logging`, `reshard-c4-data`. All four started once, each making one completed logical P1 call. The first, second, and fourth completed. `nginx-request-logging` returned a format error, `RequirementError` with code `empty_oversized_or_control_character_text`; its original visible response and tool arguments were preserved, not repaired or retried. There were no script-classified engineering errors and no unrun tasks.

Each `real/<task>/` contains the complete visible pre-request and actual request, full visible response/tool arguments, frozen input, run configuration, terminal status, final topics/state and bank, and source-archive records. The model-visible system, user assignment (including the appended full initialization guidance), and tool schema are in the request files. `real/summary.json`, `real/real_progress.json`, and the unedited command stdout/stderr record overall order and status. The script reports 4 logical calls; lower-level HTTP attempt counts remain unknown because inherited client retries are not counted here.

Recorded usage from the four `visible_response.json` files totals 4,004 prompt tokens, 1,000 completion tokens, and 216 cache tokens. These are the fields the client exposed; they are not independently measured billing. The client returned `cost_usd: 0`, which is not treated as proof of zero cost.

## Projection and completeness

Private originals remain in the local run directory. This ZIP does not claim to contain raw HTTP bytes or hidden model reasoning. All request, visible-response, stdout/stderr, state, and task artifacts are copied byte-for-byte except ten `source_archive/source_links.json` files: their host signing `data.secret` field was removed. In those files the original archive data hash is retained only as `public_projection.original_data_sha256`; the projected file is explicitly marked not runtime-restorable. `FILE_HASHES.json` maps each private original's SHA-256 and byte count to the public file's SHA-256 and byte count. No profile, credential, private endpoint, signing secret, or hidden reasoning was uploaded.

Unavailable materials: physical HTTP attempt count, independent billable cost, and any Task/P2/native evaluation records (those phases were not run). The public per-task visible returns and original tool arguments are present, including the format-error case.
