import json
from pathlib import Path

root = Path(__file__).parent
for output in sorted(root.glob("real-A-*")):
    windows = sorted((output / "source_archive/windows").glob("maintenance_1_r*.json"))
    result = json.loads((output / "result.json").read_bytes())
    state = json.loads((output / "source_archive/source_links.json").read_bytes())["data"]
    rows = []
    for window in windows:
        data = json.loads(window.read_bytes())
        rows.append({"window": window.name,
                     "input_memory_coverage": data.get("input_memory_coverage"),
                     "coverage_is_not_model_read_or_verified": True})
    reads = [{"window_id": turn.get("window_id"), "arguments": call.get("arguments"),
              "tool_call_id": call.get("tool_call_id")}
             for turn in result["turns"] for call in turn.get("tool_calls", [])
             if call.get("name") == "memory_read_source"]
    cited = {key: ref.get("cited_history_handles", []) for key, ref in state["refs"].items()
             if ref.get("cited_history_handles")}
    target = root / ("a-relations-" + output.name.removeprefix("real-A-") + ".json")
    assert not target.exists()
    target.write_text(json.dumps({"schema": "p1-context-history-relation-index-v1",
                                  "case_output": output.name,
                                  "input_coverage_by_window": rows,
                                  "cited_history_handles_by_memory": cited,
                                  "actual_model_read_tool_calls": reads,
                                  "read_count_from_result": result["reads_used"],
                                  "derived_after_run_not_model_input": True},
                                 ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(output.name, "coverage_windows", len(rows), "actual_reads", len(reads))
