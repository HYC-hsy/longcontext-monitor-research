import hashlib
import json
from pathlib import Path
import sys

repo = Path(r"E:\pma-p1-history-b-20261103")
stage = repo / "method_discovery/curator_supervisor_convergence_v0/pma_full_upstream_ga_v1_20261013"
for path in (repo, stage / "vendor/pma_89e5c0d/external/harbor/src",
             stage / "vendor/pma_89e5c0d/src", stage):
    sys.path.insert(0, str(path))
from p1_dms_gap_agent import GapIndexMaterialStore
from p1_dms_view import material_previews


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


root = Path(__file__).parent
for output in sorted(root.glob("real-B-*")):
    original = output / "source_archive/source_links.json"
    before = sha(original)
    copy = root / "dms-rebuild-copies" / output.name
    saved = json.loads((copy / "source_links.json").read_bytes())
    state = saved["data"]
    store = GapIndexMaterialStore(copy, task_id=state["task_id"], task=state["task"], bank=state["bank"])
    bank_after = json.loads((output / "bank_after.json").read_bytes())
    groups = []
    for memory_id, group in state["groups"].items():
        ref = state["refs"][memory_id]
        fields = [{"source_id": sid, "field": field, "encoding": encoding, "text": text}
                  for sid, field, encoding, text in store._fields(ref["sources"])]
        previews = material_previews(store, ref["sources"])
        index = next((row.get("content") for category in ("knowledge", "procedural", "gap")
                      for row in bank_after.get(category, []) if row.get("id") == memory_id), None)
        groups.append({"memory_id": memory_id, "category": group["category"],
                       "pending": group.get("pending"), "index_kind": group.get("index_kind"),
                       "bank_index_content": index,
                       "typed_legacy_references": ref.get("inherited_unassociated", []),
                       "cited_history_handles": ref.get("cited_history_handles", []),
                       "inherited_pending_indices": ref.get("inherited_pending_indices", []),
                       "source_references": ref["sources"], "full_original_fields": fields,
                       "display_preview_reconstruction": previews})
    assert sha(original) == before, "original archive changed during readback"
    target = root / ("dms-expansion-" + output.name.removeprefix("real-B-") + ".json")
    assert not target.exists()
    target.write_text(json.dumps({"schema": "dms-gap-material-expanded-visible-v1",
                                  "source_archive": output.name,
                                  "original_source_links_sha256": before,
                                  "expansion_tools": ["GapIndexMaterialStore._fields", "material_previews"],
                                  "readback_on_copy_not_model_read": True,
                                  "group_count": len(groups), "groups": groups},
                                 ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(output.name, "groups", len(groups), "fields", sum(len(g["full_original_fields"]) for g in groups))
