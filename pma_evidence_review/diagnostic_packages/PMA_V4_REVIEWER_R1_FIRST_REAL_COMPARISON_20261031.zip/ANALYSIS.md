# v4 reviewer-only first real comparison (2026-10-31)

Execution SHA: `cba49dedb1ed5f1ca7d26f9a30a183697434b7ea` (parent `c44bdb950e5d432bf02513cf2efc429d72bf288a`).
Both arms used the same existing `claude_monitor_opus48` client identity and generation
parameters, confirmed by their separate sanitized `run-config.json` files. The
only model-visible request difference per case was the reviewer system prompt.
No splitter, Task, native evaluation, or extra model trial was run. Each arm sent
22 batch-review requests and received 22 responses; all 44 parsed with
`engineering_status=ok`. The actual request hashes match the pre-exported plans.

The first 13 cases reuse actual prior v4 claims; the last nine are constructed
controls. References are development labels, not blind gold. Three-state agreement
and the supported-versus-rejected decision are distinct:

| Group | Baseline three-state | Candidate three-state | Baseline accept/reject | Candidate accept/reject |
| --- | ---: | ---: | ---: | ---: |
| Prior 13 | 12/13 | 12/13 | 12/13 | 12/13 |
| New 9 | 7/9 | 9/9 | 9/9 | 9/9 |

## Every case

| Case | Reference | Original v4 | v4-reviewer-r1 | Interpretation |
| --- | --- | --- | --- | --- |
| h-sqlite-1-0 | supported | supported | supported | Requirement correctly retained. |
| h-html-1-1 | supported | supported | supported | Normative formatting request retained. |
| h-html-1-0 | insufficient | supported | insufficient | Candidate fixes over-admission: “exactly” was stronger than “as much as possible”. |
| h-sqlite-3-0 | insufficient | insufficient | insufficient | No change. |
| sqlite_call_19 | insufficient | insufficient | insufficient | No change. |
| sqlite_call_61 | insufficient | insufficient | insufficient | No change. |
| derived-cause-direction | insufficient | insufficient | supported | New false admission: patch followed by installer exit 0 does not establish that the patch caused success. |
| derived-cause-supported | supported | supported | supported | Strong causal positive retained. |
| derived-comparison-reversed | contradicted | contradicted | contradicted | Direct reversal still caught. |
| derived-condition-requirement | supported | supported | supported | Conditional requirement retained. |
| derived-condition-overreach | insufficient | insufficient | insufficient | Conditional instruction still not treated as execution. |
| derived-delete-installed | supported | supported | supported | Synthetic narrow gap deletion positive retained; “required tool” has referent ambiguity. |
| derived-delete-cross-session | insufficient | insufficient | insufficient | Same-script export does not establish a fresh session. |
| r1-requirement | supported | supported | supported | Task requirement supported by instruction. |
| r1-completion-unverified | insufficient | insufficient | insufficient | Requirement not promoted to completed execution. |
| r1-completion-verified | supported | supported | supported | Complete receipt positive retained. |
| r1-practical | supported | supported | supported | Qualified requirement positive retained. |
| r1-verbatim-overreach | insufficient | contradicted | insufficient | Candidate corrects three-state reason; both reject unsupported stronger requirement. |
| r1-verbatim-supported | supported | supported | supported | Strong requirement with strong B retained. |
| r1-alpha | supported | supported | supported | Checked alpha result retained. |
| r1-beta-unverified | insufficient | contradicted | insufficient | Candidate corrects three-state reason; alpha does not prove or disprove beta. |
| r1-beta-verified | supported | supported | supported | Checked beta result retained without expanding to every container. |

The two deletions above are shown separately from ordinary saved-memory cases.
There are two acceptance changes in the prior 13: one corrected false admission
(`h-html-1-0`) and one new false admission (`derived-cause-direction`). There are
no new acceptance changes among the nine constructed controls. No new false
rejection was observed. The candidate did not show a net accept/reject improvement
on this tiny development set; it did improve the insufficiency-versus-contradiction
distinction in two new controls. It also failed its own caution against inferring
causation from temporal order in one prior control. Do not infer generalization,
stability, or Task reward effects from these 44 calls.

Raw requests, responses and results are retained privately at the run parent;
this package contains a checked public projection of the whitelisted files,
not raw provider HTTP bytes or private client logs. No labels were sent to models.
