$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:LITELLM_LOCAL_MODEL_COST_MAP = 'True'
$env:GIT_CONFIG_COUNT = '3'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = 'E:/pma_d1_tb2_source_20261017'
$env:GIT_CONFIG_KEY_1 = 'safe.directory'
$env:GIT_CONFIG_VALUE_1 = 'E:/LongContext/pc_model4_fix'
$env:GIT_CONFIG_KEY_2 = 'safe.directory'
$env:GIT_CONFIG_VALUE_2 = 'E:/pma-harbor-459ff6e-clean'

$root = 'E:\LongContext\_pma_model4_claude_first20_98b_20261109'
$source = 'E:\LongContext\_pma_model4_sol20_98b_20261109'
$repo = 'E:\LongContext\pc_model4_fix'
$python = 'E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe'
$expected = '98b166aa747da9f5b7e9f0f9d677c25d77d3611a'
Set-Location $repo
if ((git rev-parse HEAD).Trim() -ne $expected) { throw 'execution source SHA changed' }
if (git status --porcelain) { throw 'execution worktree is not clean' }
$plan = Get-Content -Raw -Encoding UTF8 (Join-Path $source 'batch_plan.json') | ConvertFrom-Json
$original = @($plan.slots)
$claude = @($original | Where-Object { $_.model -in @('claude-opus-4-8', 'claude-opus-5', 'claude-fable-5') })
$gpt = @($original | Where-Object { $_.model -eq 'gpt-6-sol' })
if ($original.Count -ne 20 -or $claude.Count -ne 15 -or $gpt.Count -ne 5) {
    throw 'frozen slot/model counts differ'
}
$slots = @($claude + $gpt)
if ((@($slots | Select-Object -ExpandProperty slot | Sort-Object -Unique)).Count -ne 20) {
    throw 'duplicate slot identity'
}
foreach ($slot in $slots) {
    if (-not (Test-Path -LiteralPath $slot.config)) { throw "config missing: $($slot.slot)" }
    $name = ('{0:d2}-{1}-{2}' -f [int]$slot.slot, $slot.task, $slot.model)
    $output = Join-Path $root ('runs\' + $name)
    if (Test-Path -LiteralPath $output) { throw "slot output already exists: $($slot.slot)" }
}
Write-Output ('BATCH_ORDER ' + (($slots | ForEach-Object { '{0}:{1}:{2}' -f $_.slot, $_.task, $_.model }) -join ','))
foreach ($slot in $slots) {
    $name = ('{0:d2}-{1}-{2}' -f [int]$slot.slot, $slot.task, $slot.model)
    $output = Join-Path $root ('runs\' + $name)
    $log = Join-Path $root ('slot-' + ('{0:d2}' -f [int]$slot.slot) + '.console.log')
    Write-Output ('SLOT_START {0} {1} {2} {3}' -f $slot.slot, $slot.task, $slot.model, (Get-Date -Format o))
    & $python -X utf8 -B -m experiment_runner run --config $slot.config --output $output *>&1 |
        Tee-Object -FilePath $log
    $code = $LASTEXITCODE
    Write-Output ('SLOT_END {0} exit={1} {2}' -f $slot.slot, $code, (Get-Date -Format o))
    if ($code -ne 0) { exit $code }
}
Write-Output ('BATCH_COMPLETED {0}' -f (Get-Date -Format o))
