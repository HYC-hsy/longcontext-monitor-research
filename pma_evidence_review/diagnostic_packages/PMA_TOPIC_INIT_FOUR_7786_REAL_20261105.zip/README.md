# Fixed four-task topic initialization at 7786ea43

This package contains the complete public visible projection of one four-task initialization run on 2026-11-05. No topic semantic scoring was performed.

## Version and scope

- Repository: `HYC-hsy/longcontext-monitor-research`.
- Execution code: `7786ea43d569f5048074a0b31c6e6d304cf013d8`, clean checkout before and after execution.
- Dataset: terminal-bench-2 commit `2fd12b88aafdd04a52c298e3940bcb189f9766d6`.
- Native Harbor: `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`.
- Compared with `605fed3eac626f2bb83d9069ed2a11deca0d6be3`, the only changed file is `p1_requirements.py` and the diff is limited to `INIT_SYSTEM` text. The `run_suffix_init.py` script is unchanged (SHA-256 `2466615fecc231cf4d11c5a1cabe3649b4686ea89e328f29e10e2a0f7406db0e`). The same complete guidance remains in the system and at the end of the user message; the original task and one initialization tool are preserved.
- Existing Python: `E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe`, version 3.13.14. The existing private `claude_monitor_opus48` profile was used only for real mode. It is not in this package.
- Public client parameters in each `real/*/run_config.json`: `anthropic/claude-opus-4-8`, messages API, temperature 1, reasoning effort high, max tokens 8192, read timeout 300, adaptive thinking. Hidden provider defaults are not inferred.

## Actual checks and calls

Offline mode ran only `mcmc-sampling-stan`, `rstan-to-pystan`, `nginx-request-logging`, and `reshard-c4-data` in the script's frozen order. Its exit code was 0. The report contains six fake-client checks: one valid case for each task plus empty-list and invalid-output cases for the first. The actual request assertions checked the Harbor-loaded original task, full initialization system, exactly one tool, and complete matching guidance at the end of the user assignment. Full offline artifacts, stdout, stderr and exit code are included.

Real mode ran the same four tasks in order. Each started once and completed with one completed logical initialization call. Real exit code was 0; there were no format errors, engineering errors, skipped or retried tasks. Each `real/<task>/` folder contains the complete visible pre-request and actual request, original visible response and tool arguments, frozen input, run configuration, final topics/state, bank, source archive and terminal record. Overall progress, summary and exact stdout/stderr/exit code are included.

Recorded prompt/completion/cache tokens: `mcmc-sampling-stan` 922/44/68; `rstan-to-pystan` 1041/60/61; `nginx-request-logging` 1031/74/25; `reshard-c4-data` 862/50/98. Totals: 3,856 prompt, 228 completion, 252 cache tokens. These are client-exposed usage fields, not independently measured billing. Physical HTTP attempts and billable cost remain unknown; `cost_usd: 0` returned by the client is not proof of zero cost.

## Public projection and limitations

Private originals remain on the local machine. All visible requests, responses, tool arguments, state, and logs are byte-identical to their private originals except ten `source_archive/source_links.json` files, whose host signing `data.secret` was removed. Those files are explicitly marked `public_projection` and not runtime-restorable; the original data hash is retained only as a reference. `FILE_HASHES.json` maps every original and public file's byte count and SHA-256. This package does not contain credentials, private configuration, authentication headers, private endpoints or hidden reasoning, and is not raw HTTP bytes.

Unavailable: verified physical HTTP attempt count and billable cost. No maintenance, P2, full Task or native evaluation records exist because those phases were not run. The run does not validate trajectory display or theme semantics.
