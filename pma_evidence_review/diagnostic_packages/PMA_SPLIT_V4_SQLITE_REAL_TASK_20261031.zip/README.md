# Public diagnostic projection

sqlite-with-gcov v4 gate-one-repair real Task and native evaluation. Production code: `be44ce85fd2ec1ce116e34a8683cbcb7a113f35e`; execution HEAD: `0fb8cc21453fdbc4f8037ca2988c5949786ea6ce`.

All data files are allowlisted JSON projections, not original HTTP bytes. INDEX.json maps each original file/line hash to its public projection hash. Private profile values, endpoint URLs and hidden reasoning were excluded; the private originals remain unchanged. Redactions may limit independent inspection of those excluded spans. Evaluation-only reference labels are never model input. No model call, Task, or verifier was made to build this package.
