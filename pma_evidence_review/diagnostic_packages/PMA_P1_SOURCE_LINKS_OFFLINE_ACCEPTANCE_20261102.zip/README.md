# Source-links v1 offline acceptance

Fixed checkout eb406f2a4b1cc74d8d4a34f21fe958d558fa0c4e. MANIFEST 93 files and SOURCE_IDENTITY 61 runtime files matched actual bytes, and the current source_identity(candidate='source-links-v1') rebuilt the same 61 hashes with the current checkout SHA. The targeted source-links suite passed 58/58 with no failures/errors/skips.

Two local preflight problems were preserved: first the external verification script lacked the checkout on sys.path; then its checkout-SHA assertion detected that the first worktree had moved to an archive commit. We added sys.path and used a fresh clean fixed-SHA worktree. No production source, prompt, fixture or test assertion was modified. The earlier stopped diagnostic is at commit 8b535214a68775861138e68c7ff39bdf11fa0921.

No real profile was loaded; real model, Task, P2 and native evaluation calls were zero. No separate scripted CLI repetition was needed because the targeted suite exercised all six frozen cases in scripted no-op mode. No secrets or private runtime data are included.
