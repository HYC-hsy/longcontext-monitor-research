$ErrorActionPreference='Stop'
$Root='E:\pma-p1-dual-followup-20261102'
$Python='E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe'
$Config=Get-Content -Raw -Encoding UTF8 -LiteralPath 'E:\pma-bank-display-two-real-20261101\rstan-to-pystan-private-config.json' | ConvertFrom-Json
$Profile=$Config.environment.profiles.pma_profile_file
if (-not (Test-Path -LiteralPath $Profile)) { throw 'Existing profile absent' }
$Model=Get-Content -Raw -Encoding UTF8 -LiteralPath $Profile | ConvertFrom-Json
if ($Model.claude_monitor_opus48.model -ne 'claude-opus-4-8') { throw 'Existing model identity changed' }
$Groups=@(
 @{Name='A';Repo='E:\pma-p1-context-fix-run-20261102';Code='19405c86d4081c0a48517608671265ff622f71bf';Candidate='source-links-context-v1';First=4},
 @{Name='B';Repo='E:\pma-p1-dms-fix-run-20261102';Code='183e67ae70592bb0f5b7d16e3db53750a4ff4b1c';Candidate='dms-inspired-v1';First=1}
)
$Logs=Join-Path $Root 'real-logs'
if (Test-Path -LiteralPath $Logs) { throw 'Real logs directory already exists' }
New-Item -ItemType Directory -Path $Logs | Out-Null
$env:PYTHONUTF8='1'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:LITELLM_LOCAL_MODEL_COST_MAP='True'
Start-Transcript -LiteralPath (Join-Path $Root 'real-serial-transcript.txt') -ErrorAction Stop | Out-Null
try {
 foreach ($Group in $Groups) {
  $Repo=$Group.Repo
  Set-Location -LiteralPath $Repo
  if ((git rev-parse HEAD).Trim() -ne $Group.Code -or (git status --porcelain)) { throw ('Execution checkout changed: '+$Group.Name) }
  $CaseDir=Join-Path $Repo 'pma_evidence_review\p1_source_read_delivery\cases'
  $Index=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $CaseDir 'INDEX.json') | ConvertFrom-Json
  if ($Index.cases.Count -ne 6) { throw 'Frozen case count changed' }
  for ($Number=$Group.First; $Number -le 6; $Number++) {
   $Entry=$Index.cases[$Number-1]
   $Stem=[IO.Path]::GetFileNameWithoutExtension($Entry.file)
   $Case=Join-Path $CaseDir $Entry.file
   if ((Get-FileHash -LiteralPath $Case -Algorithm SHA256).Hash.ToLower() -ne $Entry.sha256) { throw ('Frozen case bytes changed: '+$Entry.file) }
   $Out=Join-Path $Root ('real-'+$Group.Name+'-'+$Stem)
   if (Test-Path -LiteralPath $Out) { throw ('Output already exists: '+$Out) }
   $Stdout=Join-Path $Logs ($Group.Name+'-'+$Stem+'.stdout.txt')
   $Stderr=Join-Path $Logs ($Group.Name+'-'+$Stem+'.stderr.txt')
   Write-Output ('START '+$Group.Name+' '+$Number+'/6 '+$Entry.file)
   $Args=@('-B','pma_evidence_review/tools/run_p1_source_case.py','--candidate',$Group.Candidate,
     '--mode','real','--authorize-real-p1','--profile-file',$Profile,'--case',$Case,'--output',$Out)
   $Process=Start-Process -FilePath $Python -ArgumentList $Args -WorkingDirectory $Repo `
     -RedirectStandardOutput $Stdout -RedirectStandardError $Stderr -WindowStyle Hidden -Wait -PassThru
   $TerminalPath=Join-Path $Out 'terminal.json'
   $Terminal=if (Test-Path -LiteralPath $TerminalPath) { Get-Content -Raw -Encoding UTF8 -LiteralPath $TerminalPath | ConvertFrom-Json } else { $null }
   $Status=if ($null -eq $Terminal) { 'missing_terminal' } else { $Terminal.status }
   $Record=[ordered]@{group=$Group.Name;case=$Entry.file;exit_code=$Process.ExitCode;terminal_status=$Status;
     model_calls_attempted=$Terminal.model_calls_attempted;model_calls_completed=$Terminal.model_calls_completed;
     stdout_sha256=(Get-FileHash -LiteralPath $Stdout -Algorithm SHA256).Hash.ToLower();
     stderr_sha256=(Get-FileHash -LiteralPath $Stderr -Algorithm SHA256).Hash.ToLower()}
   $Record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $Logs ($Group.Name+'-'+$Stem+'.execution.json')) -Encoding UTF8
   Write-Output ('END '+$Group.Name+' '+$Number+'/6 exit='+$Process.ExitCode+' status='+$Status+' calls='+$Terminal.model_calls_attempted)
   if ($Process.ExitCode -ne 0 -or $Status -ne 'completed' -or $Terminal.model_calls_attempted -gt 3) { throw ('Engineering or call-budget stop at '+$Group.Name+' '+$Entry.file) }
   $Result=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $Out 'result.json') | ConvertFrom-Json
   if ($Result.status -ne 'completed' -or $Result.reads_used -gt 4 -or $Result.continuations_used -gt 2) { throw ('Result or read-budget stop at '+$Group.Name+' '+$Entry.file) }
  }
 }
 Write-Output 'ALL_NINE_COMPLETE'
} catch {
 Write-Output ('SERIAL_STOP '+$_.Exception.Message)
 exit 1
} finally {
 Stop-Transcript | Out-Null
}
