import json
from pathlib import Path
import sys

repo = Path(r"E:\pma-p1-dms-fix-run-20261102")
stage = repo / "method_discovery/curator_supervisor_convergence_v0/pma_full_upstream_ga_v1_20261013"
for path in (repo, stage / "vendor/pma_89e5c0d/external/harbor/src",
             stage / "vendor/pma_89e5c0d/src", stage):
    sys.path.insert(0, str(path))
from p1_dms_agent import DMSMaterialStore

root = Path(__file__).parent
for output in sorted(root.glob("real-B-*")):
    archive = output / "source_archive"
    raw = json.loads((archive / "source_links.json").read_bytes())
    state = raw["data"]
    store = DMSMaterialStore(archive, task_id=state["task_id"], task=state["task"], bank=state["bank"])
    bank_after = json.loads((output / "bank_after.json").read_bytes())
    rows = []
    for memory_id, group in state["groups"].items():
        ref = state["refs"][memory_id]
        fields = [{"source_id": sid, "field": field, "encoding": encoding, "text": text}
                  for sid, field, encoding, text in store._fields(ref["sources"])]
        preview = [{"source_id": field["source_id"], "field": field["field"],
                    "encoding": field["encoding"], "text": field["text"][:800],
                    "shown_characters": min(800, len(field["text"])),
                    "total_characters": len(field["text"]), "preview_only": len(field["text"]) > 800}
                   for field in fields]
        rows.append({"memory_id": memory_id, "category": group["category"],
                     "outcome": group.get("outcome", "unknown"),
                     "bank_index_content": next((row.get("content") for category in ("knowledge", "procedural", "gap")
                                                 for row in bank_after.get(category, []) if row.get("id") == memory_id), None),
                     "typed_legacy_references": ref.get("inherited_unassociated", []),
                     "source_references": ref["sources"], "full_original_fields": fields,
                     "display_preview_reconstruction": preview})
    target = root / ("dms-expansion-" + output.name.removeprefix("real-B-") + ".json")
    assert not target.exists()
    target.write_text(json.dumps({"schema": "dms-material-expanded-visible-v1",
                                  "source_archive": output.name,
                                  "expansion_tool": "DMSMaterialStore._fields",
                                  "group_count": len(rows), "groups": rows},
                                 ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(output.name, "groups", len(rows), "fields", sum(len(r["full_original_fields"]) for r in rows))
