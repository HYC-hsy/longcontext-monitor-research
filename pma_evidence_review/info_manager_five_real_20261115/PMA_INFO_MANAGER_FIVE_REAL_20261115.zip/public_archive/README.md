# Information-manager five-task real run

Execution: `f785096ca2c513201a6f23db928697d926ed7e50`. Dataset: `2fd12b88aafdd04a52c298e3940bcb189f9766d6`. Harbor: `459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc`.

One new episode per task in frozen order, using the unified runner, four-step manager wake period, uncapped Task agent and official per-task verifier limits. Every slot completed native evaluation and recorded owned-resource cleanup. No retry or method change.

The ZIP includes available complete visible Task and manager records, tool calls and receipts, memory, reminders and delivery evidence, run identity, effective policy, native evaluation metadata and cleanup. It is a redacted visible projection, not raw HTTP bytes or a restorable private runtime. Private originals remain local. Credentials, private profiles/endpoints, provider-private thinking/signatures, hidden verifier bodies and runtime source bundles are excluded. The external index maps each original file hash to its public projection hash.
