# Run results

| Task | run_id | Task steps | Manager wakes | Read/add calls | Reminders sent | Native tests | Reward | Cleanup |
| --- | --- | ---: | ---: | --- | ---: | --- | ---: | --- |
| rstan-to-pystan | pma-bdc343332a7847c0 | 27 | 7 | 13/8 | 2 | 4/6 | 0.0 | True |
| make-mips-interpreter | pma-da68506a698842d4 | 432 | 108 | 111/356 | 18 | 0/3 | 0.0 | True |
| merge-diff-arc-agi-task | pma-956eaf5cecd045d0 | 15 | 4 | 4/5 | 1 | 5/5 | 1.0 | True |
| reshard-c4-data | pma-ab72bd6c584e4411 | 24 | 6 | 6/9 | 0 | 1/1 | 1.0 | True |
| largest-eigenval | pma-3a35df8afa4a4f01 | 13 | 4 | 4/4 | 2 | 3/3 | 1.0 | True |

Mechanical observations only; no semantic-effect judgment.
