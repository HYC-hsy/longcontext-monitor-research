"""Isolated 22b manager-only A/B replay. Never starts a Task or verifier.

The runner is deliberately outside the fixed source worktree. The only method
override is the frozen A/B system string in each isolated child process.
"""
import argparse
import asyncio
import copy
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

PREP = Path("[PRIVATE_HOST_PATH]")
sys.path.insert(0, str(PREP))
from ab_zero_model_preflight import (  # noqa: E402
    WORKTREE, SOURCE, MANIFEST, RUNS, PROMPTS, SUFFIX, records, sha,
    canonical, inverse_history, bank_at_first_read, FakeClient,
)
from memory_agent.memory.reminder_tool_memory_agent import ReminderToolMemoryAgent  # noqa: E402
import memory_agent.memory.reminder_tool_memory_agent as manager_module  # noqa: E402
from episode import construct_upstream  # noqa: E402
from provider_response_sidecar import ResponseSidecar  # noqa: E402
from worker_main import install_transport_audit, install_http_wire_audit  # noqa: E402

OUTPUT = Path(os.environ.get("PMA_AB_OUTPUT_ROOT", "[PRIVATE_HOST_PATH]"))
CAPTURE_ROOT = Path(os.environ.get("PMA_AB_CAPTURE_ROOT", "[PRIVATE_HOST_PATH]"))
PROFILE_PATH = Path("[PRIVATE_HOST_PATH]")
PROFILE_SHA256 = "42ce7b4bd30a41c612ddefd9249e6bfb33ecb9ff2b989d8cf72a281735b7d39e"
MAX_LOGICAL_CALLS = 10
MAX_WAKE_SECONDS_SOFT = 30 * 60
EXPECTED_CODE_SHA = "d6d9b0c755f16782168f5bef2af82be220e11e85"


class ReplayBudgetExceeded(RuntimeError):
    pass


def write_new(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, default=str)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def source_data(case):
    root = RUNS[case["archive_run"]]
    call = case["first_call_sequence"]
    payloads = [x for x in records(root / "memory_payload.jsonl") if x["call_sequence"] == call]
    assert len(payloads) == 1
    payload = payloads[0]
    assert payload["cycle_step"] == case["wake"]
    assert sha(canonical(payload["message_history"])) == case["history_canonical_sha256"]
    assert sha(canonical(payload["tools"])) == case["tools_canonical_sha256"]
    assert "[provider-private blocks excluded]" not in canonical(payload["message_history"])
    bank, bank_text, count = bank_at_first_read(root, call)
    assert sha(bank_text) == case["initial_read_content_sha256"]
    native = inverse_history(payload["message_history"])
    anchor = native[0]["content"][0]["text"]
    assert anchor.startswith("<task_description>\n") and anchor.endswith("\n</task_description>")
    task = anchor[len("<task_description>\n"):-len("\n</task_description>")]
    prompt = payload["prompt"]
    assert prompt.startswith("<task_trajectory>\n") and prompt.endswith("\n</task_trajectory>")
    trajectory = prompt[len("<task_trajectory>\n"):-len("\n</task_trajectory>")]
    assert payload["system"] in {PROMPTS["A"], PROMPTS["B"],
                                  manager_module.REMINDER_TOOL_SYSTEM,
                                  manager_module.REMINDER_TOOL_SYSTEM + SUFFIX}
    return payload, native, bank, bank_text, count, task, trajectory


def fixed_identity():
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=WORKTREE).decode().strip()
    if actual != EXPECTED_CODE_SHA:
        raise RuntimeError("fixed code commit mismatch")
    dirty = subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=WORKTREE)
    if dirty.strip():
        raise RuntimeError("fixed code worktree is dirty")
    if hashlib.sha256(PROFILE_PATH.read_bytes()).hexdigest() != PROFILE_SHA256:
        raise RuntimeError("private profile hash changed")
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))["pma_model"]
    expected = {"model": "claude-opus-5", "temperature": 1,
                "max_tokens": 8192, "read_timeout": 300, "max_retries": 8}
    if any(profile.get(key) != value for key, value in expected.items()):
        raise RuntimeError("private profile effective fields changed")
    if sha(PROMPTS["A"]) != MANIFEST["prompt_sha256"]["A.txt"]:
        raise RuntimeError("A prompt changed")
    if sha(PROMPTS["B"]) != MANIFEST["prompt_sha256"]["B.txt"]:
        raise RuntimeError("B prompt changed")
    if sha(SUFFIX) != MANIFEST["prompt_sha256"]["legacy_explanation_suffix.txt"]:
        raise RuntimeError("legacy suffix changed")
    if len(MANIFEST["schedule"]) != 24:
        raise RuntimeError("schedule is not 24 slots")
    return profile


def prepare():
    profile = fixed_identity()
    if OUTPUT.exists():
        raise FileExistsError("replay output already exists; never overwrite or resume")
    if not CAPTURE_ROOT.is_dir():
        raise FileNotFoundError("controlled capture root must be prepared separately")
    OUTPUT.mkdir(parents=False)
    slots = []
    for item in MANIFEST["schedule"]:
        slots.append({**item, "run_id": "ab-" + uuid.uuid4().hex[:16],
                      "blind_id": uuid.uuid4().hex[:16]})
    write_new(OUTPUT / "private_plan.json", {
        "fixed_code_sha": EXPECTED_CODE_SHA,
        "source_archive_sha": MANIFEST["source_archive"],
        "profile_sha256": PROFILE_SHA256,
        "profile_safe": {key: profile.get(key) for key in (
            "provider", "api_mode", "model", "thinking_type", "reasoning_effort",
            "temperature", "max_tokens", "read_timeout", "max_retries")},
        "max_logical_calls_per_wake": MAX_LOGICAL_CALLS,
        "soft_wall_seconds_per_wake": MAX_WAKE_SECONDS_SOFT,
        "schedule": slots,
    })
    print(f"PREPARED slots={len(slots)} fixed_sha={EXPECTED_CODE_SHA} output={OUTPUT}", flush=True)


def run_all():
    plan_path = OUTPUT / "private_plan.json"
    if not plan_path.is_file():
        raise FileNotFoundError("prepare before run")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    fixed_identity()
    for item in plan["schedule"]:
        slot = item["slot"]
        slot_dir = OUTPUT / f"slot-{slot:02d}-{item['run_id']}"
        if slot_dir.exists():
            raise RuntimeError(f"slot {slot} already has an output directory; no replay")
        print(f"SLOT_START slot={slot} run_id={item['run_id']} case={item['case']}", flush=True)
        command = [sys.executable, "-B", str(Path(__file__).resolve()), "child", "--slot", str(slot)]
        proc = subprocess.run(command, cwd=WORKTREE, check=False)
        print(f"SLOT_EXIT slot={slot} run_id={item['run_id']} code={proc.returncode}", flush=True)
        if proc.returncode != 0:
            print(f"QUEUE_STOP slot={slot} infrastructure_or_uncertain_error", flush=True)
            return proc.returncode
    print("QUEUE_COMPLETE slots=24", flush=True)
    return 0


async def run_child(slot_number, *, fake=False):
    plan = json.loads((OUTPUT / "private_plan.json").read_text(encoding="utf-8"))
    item = next(x for x in plan["schedule"] if x["slot"] == slot_number)
    case = next(x for x in MANIFEST["cases"] if x["case"] == item["case"])
    group, run_id = item["group"], item["run_id"]
    profile = fixed_identity()
    payload, native, bank, bank_text, count, task, trajectory = source_data(case)
    slot_dir = OUTPUT / f"slot-{slot_number:02d}-{run_id}"
    slot_dir.mkdir(exist_ok=False)
    private = slot_dir / "private"
    archive = private / "archive"
    archive.mkdir(parents=True)
    write_new(private / "frozen_input.json", {
        "case": case, "run_id": run_id, "blind_id": item["blind_id"],
        "group": group, "payload": payload,
        "initial_bank": bank.to_dict(), "initial_read_content": bank_text,
        "initial_bank_entries": count,
    })
    write_new(private / "started.json", {"started_epoch": time.time(),
             "run_id": run_id, "case": item["case"], "group": group,
             "slot": slot_number, "fixed_code_sha": EXPECTED_CODE_SHA,
             "profile_sha256": PROFILE_SHA256})
    host = construct_upstream(slot_dir / "host", memory_profile=profile,
                              research_candidate="pma_predictive_read_context_v1",
                              pma_batch_rounds=4)
    manager = host._memory_agent
    assert isinstance(manager, ReminderToolMemoryAgent)
    assert manager.llm is host._memory_llm and manager.memory is host._memory
    host._memory._knowledge = copy.deepcopy(bank.knowledge)
    host._memory._procedural = copy.deepcopy(bank.procedural)
    manager._task_anchor = native[0]
    manager._completed_phase1 = native[1:]
    manager._seen_call_ids = {call["id"] for row in payload["message_history"]
                              for call in row.get("tool_calls", [])}
    manager.set_phase1_context(task=task, trajectory=trajectory)
    assert manager._format_memory_bank() == bank_text
    manager_module.REMINDER_TOOL_SYSTEM = PROMPTS[group]
    if fake:
        host._memory_llm.call = FakeClient(item["case"], group, "normal", payload, bank_text).call
    current = install_transport_audit(host, archive)
    current["run_id"] = run_id
    sidecar = ResponseSidecar(CAPTURE_ROOT, run_id, private / "provider_capture_status.jsonl")
    install_http_wire_audit(archive, current, sidecar)
    audited_call = host._memory_llm.call
    logical = 0
    start_mono = time.monotonic()

    async def guarded_call(*, prompt, system, tools=None, message_history=None):
        nonlocal logical
        if logical >= MAX_LOGICAL_CALLS:
            raise ReplayBudgetExceeded("logical call cap reached")
        if logical and time.monotonic() - start_mono >= MAX_WAKE_SECONDS_SOFT:
            raise ReplayBudgetExceeded("soft wall cap reached between calls")
        if logical == 0:
            if (prompt != payload["prompt"] or message_history != payload["message_history"]
                    or tools != payload["tools"] or system != PROMPTS[group]):
                raise RuntimeError("first request differs beyond the frozen system")
        elif system not in {PROMPTS[group], PROMPTS[group] + SUFFIX}:
            raise RuntimeError("unexpected later system prompt")
        logical += 1
        return await audited_call(prompt=prompt, system=system, tools=tools,
                                  message_history=message_history)

    host._memory_llm.call = guarded_call
    status, result, error = "completed", None, None
    started = time.time()
    try:
        result = await manager.process(None, step_count=case["wake"])
    except BaseException as exc:
        inner = getattr(exc, "__cause__", None)
        status = "truncated" if isinstance(inner, ReplayBudgetExceeded) else "model_or_tool_error"
        error = {"type": type(exc).__name__, "message": str(exc),
                 "inner_type": type(inner).__name__ if inner else None,
                 "inner_message": str(inner) if inner else None}
    summary = {
        "status": status, "run_id": run_id, "blind_id": item["blind_id"],
        "slot": slot_number, "case": item["case"], "group": group,
        "repeat": item["repeat"], "wake": case["wake"],
        "first_call_sequence_original": case["first_call_sequence"],
        "logical_calls": logical, "elapsed_seconds": time.time() - started,
        "started_epoch": started, "ended_epoch": time.time(),
        "reminders_recorded": copy.deepcopy(manager._recorded_reminders),
        "task_delivery_attempts": 0, "task_delivered": False,
        "operations": [asdict(operation) for operation in manager._phase1_operations],
        "loop_rounds": copy.deepcopy(manager._unified_rounds),
        "result": ({"should_inject": result.should_inject,
                    "context_for_action": result.context_for_action,
                    "termination": result.termination} if result else None),
        "error": error,
        "final_bank": host._memory.to_dict(),
        "capture_status_file": str(private / "provider_capture_status.jsonl"),
    }
    write_new(private / "result.json", summary)
    print(f"WAKE_RESULT slot={slot_number} run_id={run_id} status={status} "
          f"calls={logical} reminders={len(summary['reminders_recorded'])}", flush=True)
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "run", "child"))
    parser.add_argument("--slot", type=int)
    parser.add_argument("--fake", action="store_true")
    args = parser.parse_args()
    if args.command == "prepare":
        prepare()
    elif args.command == "run":
        sys.exit(run_all())
    else:
        if args.slot is None or not 1 <= args.slot <= 24:
            raise ValueError("child requires --slot 1..24")
        sys.exit(asyncio.run(run_child(args.slot, fake=args.fake)))


if __name__ == "__main__":
    main()
