"""No provider calls. Rehydrate four frozen manager wakes and test tool flow."""
import asyncio
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace

WORKTREE = Path("[PRIVATE_HOST_PATH]")
VENDOR = WORKTREE / "method_discovery/curator_supervisor_convergence_v0/pma_full_upstream_ga_v1_20261013/vendor/pma_89e5c0d/src"
sys.path.insert(0, str(VENDOR))
from memory_agent.memory.ga_context_history import provider_history  # noqa: E402
from memory_agent.memory.reminder_tool_memory_agent import ReminderToolMemoryAgent  # noqa: E402
from memory_agent.memory.universal_memory import UniversalMemory, MemoryEntry  # noqa: E402
import memory_agent.memory.reminder_tool_memory_agent as manager_module  # noqa: E402

RUNTIME = WORKTREE / "method_discovery/curator_supervisor_convergence_v0/pma_full_upstream_ga_v1_20261013"
sys.path.insert(0, str(RUNTIME))

ROOT = Path("[PRIVATE_HOST_PATH]")
SOURCE = WORKTREE / "pma_evidence_review/reminder_grounding_ab_22b_20261121"
MANIFEST = json.loads((SOURCE / "manifest.json").read_text(encoding="utf-8"))
RUNS = {
    "01_pma-a7843144b386448e": ROOT / "01-rstan-to-pystan/01-rstan-to-pystan-r1/runs/pma-a7843144b386448e/host_private/archive",
    "02_pma-f3cae5d396794e5f": ROOT / "02-merge-diff-arc-agi-task/01-merge-diff-arc-agi-task-r1/runs/pma-f3cae5d396794e5f/host_private/archive",
    "03_pma-9f5bf04ca57b485f": ROOT / "03-raman-fitting/01-raman-fitting-r1/runs/pma-9f5bf04ca57b485f/host_private/archive",
}
PROMPTS = {name: (SOURCE / f"{name}.txt").read_text(encoding="utf-8") for name in ("A", "B")}
SUFFIX = (SOURCE / "legacy_explanation_suffix.txt").read_text(encoding="utf-8")


def records(path):
    return [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines()]


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def inverse_history(provider_messages):
    """Undo only the known provider_history projection; verify by roundtrip."""
    result = []
    for row in provider_messages:
        role = row["role"]
        if role == "user":
            result.append(copy.deepcopy(row))
        elif role == "tool":
            result.append({"role": "user", "content": [{
                "type": "tool_result", "tool_use_id": row["tool_call_id"], "content": row["content"]}]})
        elif role == "assistant":
            content = row.get("content", [])
            blocks = copy.deepcopy(content if isinstance(content, list) else [{"type": "text", "text": content}])
            for call in row.get("tool_calls", []):
                fn = call["function"]
                blocks.append({"type": "tool_use", "id": call["id"], "name": fn["name"],
                               "input": json.loads(fn["arguments"])})
            msg = {"role": "assistant", "content": blocks}
            for source, target in (("thinking_blocks", "_provider_thinking_blocks"),
                                   ("_openai_output_items", "_openai_output_items")):
                if source in row:
                    msg[target] = copy.deepcopy(row[source])
            result.append(msg)
        else:
            raise AssertionError(f"Unexpected provider history role: {role}")
    assert provider_history(result) == provider_messages
    return result


def bank_at_first_read(root, call):
    receipt = next(row for row in records(root / "memory_tool_results.jsonl") if row["call_sequence"] == call)
    assert len(receipt["tool_results"]) == 1
    bank_text = json.loads(receipt["tool_results"][0]["content"])["content"]
    final = json.loads((root / "memory.json").read_text(encoding="utf-8"))
    matched = []
    for count in range(len(final["knowledge"]) + 1):
        items = final["knowledge"][:count] + final["procedural"]
        formatted = "<memory_bank>\n" + ("\n".join(f"[{x['id']}] {x['content']}" for x in items)
                                            if items else "(empty)") + "\n</memory_bank>"
        if formatted == bank_text:
            matched.append(count)
    assert len(matched) == 1, matched
    memory = UniversalMemory()
    memory._knowledge = [MemoryEntry.from_dict(x) for x in final["knowledge"][:matched[0]]]
    memory._procedural = [MemoryEntry.from_dict(x) for x in final["procedural"]]
    return memory, bank_text, matched[0]


def tool_response(call_id, name, args, content=""):
    return SimpleNamespace(content=content, tool_calls=[{
        "id": call_id, "type": "function", "function": {
            "name": name, "arguments": json.dumps(args, ensure_ascii=False)}}],
        thinking_blocks=None, reasoning_content=None, openai_output_items=None,
        finish_reason=None, stop_reason=None)


def text_response(content):
    return SimpleNamespace(content=content, tool_calls=[], thinking_blocks=None,
                           reasoning_content=None, openai_output_items=None,
                           finish_reason=None, stop_reason=None)


class FakeClient:
    def __init__(self, case, group, mode, payload, initial_bank_text):
        self.case, self.group, self.mode = case, group, mode
        self.payload, self.initial_bank_text = payload, initial_bank_text
        self.calls = []
        self.suffix_seen = False
        self.first_request = None

    async def call(self, *, prompt, system, tools, message_history):
        number = len(self.calls)
        self.calls.append({"system_sha256": sha(system), "history_count": len(message_history)})
        if number == 0:
            assert prompt == self.payload["prompt"]
            assert message_history == self.payload["message_history"]
            assert tools == self.payload["tools"]
            assert system == PROMPTS[self.group]
            self.first_request = {"prompt": prompt, "history": copy.deepcopy(message_history),
                                  "tools": copy.deepcopy(tools), "system": system}
            return tool_response("fake-read-1", "memory_read", {"bank_id": "knowledge"})
        last = message_history[-1]
        if number == 1:
            assert last["role"] == "tool" and last["tool_call_id"] == "fake-read-1"
            assert json.loads(last["content"])["content"] == self.initial_bank_text
            if self.mode == "silence":
                return text_response("No reminder is needed at this frozen wake.")
            if self.mode == "error":
                return tool_response("fake-invalid", "memory_read", {"bank_id": "wrong"})
            return tool_response("fake-add", "memory_add", {"content": "AB_PRECHECK_ONLY"},
                                 content="" if self.mode == "suffix" else "Selected one test entry.")
        if self.mode == "error":
            assert last["role"] == "tool" and json.loads(last["content"])["success"] is False
            return text_response("The invalid read failed; no reminder will be sent.")
        if number == 2:
            assert last["role"] == "tool" and last["tool_call_id"] == "fake-add"
            assert json.loads(last["content"])["success"] is True
            if self.mode == "suffix":
                assert system == PROMPTS[self.group] + SUFFIX
                self.suffix_seen = True
            else:
                assert system == PROMPTS[self.group]
            return tool_response("fake-read-2", "memory_read", {"bank_id": "knowledge"})
        if number == 3:
            assert last["role"] == "tool" and last["tool_call_id"] == "fake-read-2"
            assert "AB_PRECHECK_ONLY" in json.loads(last["content"])["content"]
            return tool_response("fake-reminder", "send_reminder", {"content": "AB_PRECHECK_ONLY reminder"},
                                 content="Reminder is relevant to the current work.")
        if number == 4:
            assert last["role"] == "tool" and last["tool_call_id"] == "fake-reminder"
            receipt = json.loads(last["content"])
            assert receipt["success"] is True and receipt["delivered"] is False
            return text_response("Finished this isolated wake.")
        raise AssertionError("Fake call exceeded its finite script")


async def check_one(case, group, mode):
    root = RUNS[case["archive_run"]]
    call = case["first_call_sequence"]
    payload = next(row for row in records(root / "memory_payload.jsonl") if row["call_sequence"] == call)
    assert payload["cycle_step"] == case["wake"]
    assert sha(canonical(payload["message_history"])) == case["history_canonical_sha256"]
    assert sha(canonical(payload["tools"])) == case["tools_canonical_sha256"]
    memory, bank_text, count = bank_at_first_read(root, call)
    assert sha(bank_text) == case["initial_read_content_sha256"]
    restored = inverse_history(payload["message_history"])
    anchor_text = restored[0]["content"][0]["text"]
    assert anchor_text.startswith("<task_description>\n") and anchor_text.endswith("\n</task_description>")
    task = anchor_text[len("<task_description>\n"):-len("\n</task_description>")]
    assert payload["prompt"].startswith("<task_trajectory>\n")
    assert payload["prompt"].endswith("\n</task_trajectory>")
    trajectory = payload["prompt"][len("<task_trajectory>\n"):-len("\n</task_trajectory>")]
    fake = FakeClient(case["case"], group, mode, payload, bank_text)
    manager = ReminderToolMemoryAgent(llm=fake, memory=memory)
    manager._task_anchor = restored[0]
    manager._completed_phase1 = restored[1:]
    manager._seen_call_ids = {c["id"] for row in payload["message_history"]
                              for c in row.get("tool_calls", [])}
    manager.set_phase1_context(task=task, trajectory=trajectory)
    previous_system = manager_module.REMINDER_TOOL_SYSTEM
    try:
        manager_module.REMINDER_TOOL_SYSTEM = PROMPTS[group]
        result = await manager.process(None, step_count=case["wake"])
    finally:
        manager_module.REMINDER_TOOL_SYSTEM = previous_system
    assert (manager._format_memory_bank() == bank_text) == (mode in {"silence", "error"})
    if mode in {"normal", "suffix"}:
        assert result.should_inject and result.context_for_action == "AB_PRECHECK_ONLY reminder"
        assert manager._recorded_reminders == ["AB_PRECHECK_ONLY reminder"]
        assert len(fake.calls) == 5
    else:
        assert not result.should_inject and result.context_for_action is None
        assert len(fake.calls) == 2 if mode == "silence" else len(fake.calls) == 3
    if mode == "suffix":
        assert fake.suffix_seen
    return {
        "case": case["case"], "group": group, "mode": mode,
        "first_system_sha256": fake.calls[0]["system_sha256"],
        "first_history_canonical_sha256": sha(canonical(fake.first_request["history"])),
        "first_prompt_original_sha256": sha(fake.first_request["prompt"]),
        "initial_bank_entries": count, "calls": len(fake.calls),
        "reminders_recorded": len(manager._recorded_reminders),
        "suffix_seen": fake.suffix_seen,
        "task_delivery_calls": 0,
    }, fake.first_request


async def main():
    from episode import construct_upstream
    profile_path = Path("[PRIVATE_HOST_PATH]")
    profile = json.loads(profile_path.read_text(encoding="utf-8"))["pma_model"]
    assert profile["model"] == "claude-opus-5" and profile["temperature"] == 1
    assert hashlib.sha256(profile_path.read_bytes()).hexdigest() == "42ce7b4bd30a41c612ddefd9249e6bfb33ecb9ff2b989d8cf72a281735b7d39e"
    with tempfile.TemporaryDirectory(prefix="ab_preflight_", dir="[PRIVATE_HOST_PATH]") as temp_dir:
        host = construct_upstream(Path(temp_dir), memory_profile=profile,
                                  research_candidate="pma_predictive_read_context_v1",
                                  pma_batch_rounds=4)
        assert isinstance(host._memory_agent, ReminderToolMemoryAgent)
        assert host._memory_agent.memory is host._memory
        assert host._memory_llm is host._memory_agent.llm
    assert sha(PROMPTS["A"]) == MANIFEST["prompt_sha256"]["A.txt"]
    assert sha(PROMPTS["B"]) == MANIFEST["prompt_sha256"]["B.txt"]
    assert sha(SUFFIX) == MANIFEST["prompt_sha256"]["legacy_explanation_suffix.txt"]
    rows = []
    for case in MANIFEST["cases"]:
        pair = []
        for group in ("A", "B"):
            row, first = await check_one(case, group, "normal")
            rows.append(row)
            pair.append(first)
        a, b = pair
        assert a["prompt"] == b["prompt"]
        assert a["history"] == b["history"]
        assert a["tools"] == b["tools"]
        a_lines, b_lines = a["system"].splitlines(), b["system"].splitlines()
        assert len(b_lines) == len(a_lines) + 1
        assert b_lines[:14] == a_lines[:14] and b_lines[15:] == a_lines[14:]
    for group in ("A", "B"):
        for mode in ("suffix", "silence", "error"):
            row, _ = await check_one(MANIFEST["cases"][0], group, mode)
            rows.append(row)
    for row in rows:
        print(json.dumps(row, ensure_ascii=False))
    print(json.dumps({"preflight": "passed", "cases": 4, "normal_ab_checks": 8,
                      "additional_suffix_silence_error_checks": 6,
                      "actual_profile_constructor_checked": True, "real_model_calls": 0}, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main())
