$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:LITELLM_LOCAL_MODEL_COST_MAP = 'True'

$python = 'E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe'
$codeRoot = 'E:\LongContext\pc_prompt_731dc54_rerun'
$runRoot = 'E:\LongContext\_pma_prompt_731dc54_rerun2_20261116'
$statusLog = Join-Path $runRoot 'serial.status.log'

function Record-Status([string] $message) {
    $line = '{0:o} {1}' -f (Get-Date), $message
    Add-Content -LiteralPath $statusLog -Value $line -Encoding UTF8
    Write-Output $line
}

function Run-Slot([string] $name, [string] $armDirectory) {
    $config = Join-Path $runRoot ('private_configs\' + $name + '.json')
    $output = Join-Path $runRoot ('prepared\' + $name)
    $result = Join-Path $output ($armDirectory + '\batch_result.json')
    if (Test-Path -LiteralPath $result) {
        throw "Existing result prevents duplicate run: $name"
    }
    Record-Status "START $name"
    & $python -B -m experiment_runner run --config $config --output $output `
        1> (Join-Path $runRoot ($name + '.stdout.log')) `
        2> (Join-Path $runRoot ($name + '.stderr.log'))
    $exitCode = $LASTEXITCODE
    Record-Status "PROCESS_EXIT $name $exitCode"
    if (-not (Test-Path -LiteralPath $result)) {
        Record-Status "STOP $name missing_batch_result"
        return $false
    }
    $batch = Get-Content -LiteralPath $result -Raw -Encoding UTF8 | ConvertFrom-Json
    $arm = @($batch.arms)[0]
    $status = $arm.status
    $safe = $exitCode -eq 0 -and
        $null -eq $batch.stop_reason -and
        $arm.disposition -eq 'completed' -and
        $status.native_result.status -eq 'native_recorded' -and
        $status.cleanup_confirmed -eq $true -and
        $status.owned_volume_clearance.status -eq 'clean' -and
        @($status.remaining_containers).Count -eq 0
    if (-not $safe) {
        Record-Status "STOP $name incomplete_or_unsafe"
        return $false
    }
    Record-Status "COMPLETE $name $($arm.run_id)"
    return $true
}

try {
    if ((git -C $codeRoot rev-parse HEAD).Trim() -ne '731dc54ebc77a67321d1ce98de133b07a487ebfe') {
        throw 'Fixed code identity changed'
    }
    if (-not (Run-Slot '01-rstan-to-pystan' '01-rstan-to-pystan-r1')) {
        exit 1
    }
    if (-not (Run-Slot '02-merge-diff-arc-agi-task' '01-merge-diff-arc-agi-task-r1')) {
        exit 1
    }
    Record-Status 'SERIAL_COMPLETE'
    exit 0
} catch {
    Record-Status ('SUPERVISOR_ERROR ' + $_.Exception.GetType().Name)
    exit 1
}
