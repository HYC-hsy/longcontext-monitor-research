# W20/C26 knowledge-bank A/B replay (visible, redacted projection)

Execution code: 1a8a18c9d524f4ac98992dda1494ac53f3d402f1.
Original RStan run: pma-225bffec60684dbf. No Task or evaluator was run.
Eight independent real information-manager wakes used AB/BA/AB/BA order.
The first model request was identical in all trials; only the isolated bank-read
receipt differed. A reproduces the original C26 bank and order. B appends one
W8/C13 original-code excerpt, labeled as implementation visible at W8 rather
than verified W20 state. No C27-or-later model output was provided as input.

Private originals remain on the Windows host. JSON files here are redacted
visible projections, not original HTTP bytes or a restorable production run.
Provider-private thinking/signatures, authentication, private endpoints and
complete private profiles are excluded. The original and public SHA-256 mapping
is in INDEX.json. wire.json is a whitelist of outbound metadata and status.
The blind judgment file was written before the group mapping was read; the
first A trial was nevertheless glimpsed during an earlier engineering check,
so this is not a claim of perfect blinding.

Every trial's result contains its full reminder text (or null), tool operations
and receipts. The calls/history files retain visible request/response structure.
No recorded reminder was delivered to the original Task.
