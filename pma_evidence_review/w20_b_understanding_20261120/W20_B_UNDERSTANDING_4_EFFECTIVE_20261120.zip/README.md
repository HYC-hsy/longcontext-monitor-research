# W20 B post-read directed understanding probe

Execution method commit: 1a8a18c9d524f4ac98992dda1494ac53f3d402f1.
Original RStan run: pma-225bffec60684dbf. No Task or native evaluation was run.
The B bank contains 14 entries: the original C26 read bank plus one W8/C13
historical implementation excerpt. Its time identity remains explicit.
The original C26 tool call and B read receipt form the frozen history; the
Chinese test question is the only new user prompt. No C27 or later model
response, prior A/B replay output, audit judgment or answer entered the model.

The initial trial 01 failed before any service response: one logical call,
18 observed ConnectError attempts. The user then explicitly requested another
try after recharging. The fresh 01_retry_after_recharge directory preserves
that new attempt; trials 02-04 were not repeated. Four effective answers were
received. The unsuccessful original remains in this package.

This ZIP is a redacted visible projection, not original HTTP bytes and not a
restorable runtime archive. Private originals remain on the host. Credentials,
private endpoints, complete profile and provider-private thinking/signatures
are excluded. INDEX.json maps each source file hash to its public projection.
wire.json retains only outbound model/config metadata and response status.
The judgments in ASSESSMENT.md were never included in a model request.
