param(
    [Parameter(Mandatory = $true)] [int] $RunnerPid,
    [Parameter(Mandatory = $true)] [long] $StartTicks
)

$ErrorActionPreference = 'Stop'
$log = 'E:\LongContext\_pma_reminder_tool_3bbe_five_rerun_20261116\serial.status.log'
$seen = 0
Write-Output "Observing real serial runner PID $RunnerPid; status log $log"
while ($true) {
    if (Test-Path -LiteralPath $log) {
        $lines = @(Get-Content -LiteralPath $log -ErrorAction Stop)
        if ($lines.Count -gt $seen) {
            $lines[$seen..($lines.Count - 1)] | ForEach-Object { Write-Output $_ }
            $seen = $lines.Count
        }
    }
    $process = Get-Process -Id $RunnerPid -ErrorAction SilentlyContinue
    if ($null -eq $process -or $process.StartTime.ToUniversalTime().Ticks -ne $StartTicks) {
        if (Test-Path -LiteralPath $log) {
            $lines = @(Get-Content -LiteralPath $log -ErrorAction Stop)
            if ($lines.Count -gt $seen) {
                $lines[$seen..($lines.Count - 1)] | ForEach-Object { Write-Output $_ }
            }
        }
        Write-Output 'Observed runner process has exited; check batch_result and cleanup separately.'
        break
    }
    Start-Sleep -Seconds 5
}
