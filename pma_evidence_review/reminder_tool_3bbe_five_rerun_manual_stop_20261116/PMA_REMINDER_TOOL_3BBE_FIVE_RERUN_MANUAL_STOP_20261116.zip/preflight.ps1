$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:LITELLM_LOCAL_MODEL_COST_MAP = 'True'
$python = 'E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe'
$codeRoot = 'E:\LongContext\pc_reminder_tool_3bbe'
$runRoot = 'E:\LongContext\_pma_reminder_tool_3bbe_five_rerun_20261116'
$slots = @(
    '01-rstan-to-pystan',
    '02-make-mips-interpreter',
    '03-merge-diff-arc-agi-task',
    '04-reshard-c4-data',
    '05-largest-eigenval'
)
if ((git -C $codeRoot rev-parse HEAD).Trim() -ne '3bbe7f2df3c2190a269eaf857b8c0183a350e66f') {
    throw 'Fixed code identity changed.'
}
if ((git -C $codeRoot status --porcelain).Length -ne 0) { throw 'Fixed code worktree is dirty.' }
New-Item -ItemType Directory -Path (Join-Path $runRoot 'prepared') -Force | Out-Null
foreach ($name in $slots) {
    $config = Join-Path $runRoot ('private_configs\' + $name + '.json')
    $planOutput = Join-Path $runRoot ('plan-' + $name + '.json')
    $preparedOutput = Join-Path $runRoot ('prepared\' + $name)
    if ((Test-Path -LiteralPath $planOutput) -or (Test-Path -LiteralPath $preparedOutput)) {
        throw "Plan or prepared output exists: $name"
    }
    foreach ($command in @('plan','prepare')) {
        $output = if ($command -eq 'plan') { $planOutput } else { $preparedOutput }
        $stdout = Join-Path $runRoot ($name + '.' + $command + '.stdout.log')
        $stderr = Join-Path $runRoot ($name + '.' + $command + '.stderr.log')
        & $python -B -m experiment_runner $command --config $config --output $output `
            1> $stdout 2> $stderr
        if ($LASTEXITCODE -ne 0) { throw "$command failed: $name" }
        Write-Output "$command ok: $name"
    }
}
