$ErrorActionPreference = 'Continue'
$env:PYTHONUTF8 = '1'
$env:LITELLM_LOCAL_MODEL_COST_MAP = 'True'
$env:GIT_CONFIG_COUNT = '3'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = 'E:/pma_d1_tb2_source_20261017'
$env:GIT_CONFIG_KEY_1 = 'safe.directory'
$env:GIT_CONFIG_VALUE_1 = 'E:/pma-harbor-459ff6e-clean'
$env:GIT_CONFIG_KEY_2 = 'safe.directory'
$env:GIT_CONFIG_VALUE_2 = 'E:/LongContext/pc_tool_judgment_038_20261117'
$python = 'E:\LongContext\bench_runtime\m4\harbor-env\Scripts\python.exe'
$codeRoot = 'E:\LongContext\pc_tool_judgment_038_20261117'
$runRoot = 'E:\LongContext\_pma_tool_judgment_038_20261117'
$statusLog = Join-Path $runRoot 'serial.status.log'

function Record-Status([string] $message) {
    $line = '{0:o} {1}' -f (Get-Date), $message
    Add-Content -LiteralPath $statusLog -Value $line -Encoding UTF8
    Write-Output $line
}

function Run-Slot([string] $name, [string] $armDirectory, [string] $expectedRunId) {
    $config = Join-Path $runRoot ('private_configs\' + $name + '.json')
    $output = Join-Path $runRoot ('prepared\' + $name)
    $result = Join-Path $output ($armDirectory + '\batch_result.json')
    if (Test-Path -LiteralPath $result) { throw "Existing result prevents duplicate run: $name" }
    Record-Status "START $name $expectedRunId"
    & $python -B -m experiment_runner run --config $config --output $output `
        1> (Join-Path $runRoot ($name + '.stdout.log')) `
        2> (Join-Path $runRoot ($name + '.stderr.log'))
    $exitCode = $LASTEXITCODE
    Record-Status "PROCESS_EXIT $name $exitCode"
    if (-not (Test-Path -LiteralPath $result)) {
        Record-Status "STOP $name missing_batch_result"
        return $false
    }
    $batch = Get-Content -LiteralPath $result -Raw -Encoding UTF8 | ConvertFrom-Json
    $arm = @($batch.arms)[0]
    $status = $arm.status
    $safe = $exitCode -eq 0 -and $null -eq $batch.stop_reason -and
        $arm.run_id -eq $expectedRunId -and
        $arm.disposition -eq 'completed' -and
        $status.native_result.status -eq 'native_recorded' -and
        $status.cleanup_confirmed -eq $true -and
        $status.owned_volume_clearance.status -eq 'clean' -and
        @($status.remaining_containers).Count -eq 0
    if (-not $safe) {
        Record-Status "STOP $name incomplete_or_unsafe"
        return $false
    }
    Record-Status "COMPLETE $name $($arm.run_id)"
    return $true
}

try {
    if ((git -C $codeRoot rev-parse HEAD).Trim() -ne '038fcbc322872d294e3378c877b08149edb36aca') {
        throw 'Fixed code identity changed'
    }
    if ((git -C $codeRoot status --porcelain).Length -ne 0) { throw 'Execution code is dirty' }
    if (-not (Run-Slot '01-rstan-to-pystan' '01-rstan-to-pystan-r1' 'pma-212fce70db714961')) { exit 1 }
    if (-not (Run-Slot '02-merge-diff-arc-agi-task' '01-merge-diff-arc-agi-task-r1' 'pma-7117fcd001d148db')) { exit 1 }
    Record-Status 'SERIAL_COMPLETE'
    exit 0
} catch {
    Record-Status ('SUPERVISOR_ERROR ' + $_.Exception.GetType().Name)
    exit 1
}
