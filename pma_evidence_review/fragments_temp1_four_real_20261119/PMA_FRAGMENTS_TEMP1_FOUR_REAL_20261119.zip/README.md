# Original-fragment temperature-1 four-run archive

Execution c7bb1941222955980539d5290511242dd1800c39; base 607dabe70bd2569c425c6dbb7ede4e4c3ca23a89. Dataset 2fd12b88aafdd04a52c298e3940bcb189f9766d6; Harbor 459ff6ec99417589b7f679d14ddf3b3f0ae4f1dc.

This is a redacted visible projection, not raw HTTP bytes or a restorable private runtime. The four original CTRF and native test stdout files remain local because they may disclose hidden tests. Their paths, sizes and hashes are in the external index. Task final code/CSV files are captured before native evaluation and independently read back after evaluation; the identities matched. Hidden provider thinking/signatures, credentials, endpoints and private profile contents are excluded.
