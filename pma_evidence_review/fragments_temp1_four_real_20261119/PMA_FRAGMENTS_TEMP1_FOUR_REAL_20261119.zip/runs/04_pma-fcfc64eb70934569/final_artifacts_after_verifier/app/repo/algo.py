def map(g):
    num_rows = len(g)
    num_cols = len(g[0])
    
    # Build pattern dictionary by scanning in row-major order
    # Only store non-zero values
    pattern = {}
    for i in range(num_rows):
        for j in range(num_cols):
            value = g[i][j]
            if value != 0:  # Only store non-zero values
                key = (i + j) % 3
                pattern[key] = value  # Last non-zero value wins
    
    # Generate output using the pattern
    result = []
    for i in range(num_rows):
        row = []
        for j in range(num_cols):
            key = (i + j) % 3
            row.append(pattern[key])
        result.append(row)
    
    return result
