def map(g):
    num_rows = len(g)
    num_cols = len(g[0])
    d = {}

    # Collect non-zero values using (i+j)%3
    for i in range(num_rows):
        for j in range(num_cols):
            c = g[i][j]
            if c != 0:  # Only store non-zero values
                key = (i + j) % 3
                d[key] = c

    # Generate output using (i+j)%3
    result = []
    for i in range(num_rows):
        row = []
        for j in range(num_cols):
            value = d.get((i + j) % 3, 0)
            row.append(value)
        result.append(row)

    return result
